# JM/CZ Portfolio — Contact Form & Email Delivery Setup

This document explains how to configure real email delivery for the JM/CZ (`JM MADHU SUDHUON CZ`) Portfolio Contact & Project Request Form.

---

## 1. Environment Variables Required

Add these environment variables to your hosting platform (Netlify, Cloud Run, Vercel, or local `.env`):

| Variable | Description | Default / Example | Required |
|---|---|---|---|
| `EMAIL_API_KEY` | Private API key from your email delivery provider (Resend or SendGrid) | `re_1234567890abcdef...` | **Yes (for live sending)** |
| `EMAIL_TO` | Target inbox where inquiries & project requests will be delivered | `jmmadhusudhuoncz@gmail.com` | No (defaults to `jmmadhusudhuoncz@gmail.com`) |
| `EMAIL_FROM` | Sender email address displayed in delivery | `onboarding@resend.dev` (or your verified domain) | No (defaults to `onboarding@resend.dev`) |

---

## 2. Recommended Email Provider: Resend (Free Tier: 3,000 emails/mo)

1. Sign up for a free account at [https://resend.com](https://resend.com).
2. Go to **API Keys** and generate a new key (starts with `re_`).
3. Set `EMAIL_API_KEY` to your Resend API key.
4. For initial testing without a custom domain, leave `EMAIL_FROM=onboarding@resend.dev`.
5. For a custom domain (e.g. `contact@bmdeveloperagency.netlify.app` or your custom domain), verify your domain in Resend DNS settings and set `EMAIL_FROM` accordingly.

### Alternative Provider: SendGrid
- If using SendGrid, create an API key starting with `SG.` at [https://sendgrid.com](https://sendgrid.com) and set `EMAIL_API_KEY`.

---

## 3. Deployment Environments

### A. Netlify Deployment
1. Go to your Netlify site dashboard: **Site configuration** > **Environment variables**.
2. Add:
   - `EMAIL_API_KEY`: your Resend or SendGrid key
   - `EMAIL_TO`: `jmmadhusudhuoncz@gmail.com`
   - `EMAIL_FROM`: `onboarding@resend.dev` (or verified domain)
3. Deploy! Netlify automatically deploys `netlify/functions/contact.ts` and routes `/api/contact` requests to it via `netlify.toml`.

### B. Local Development / Node Server
1. Create a `.env` file in the project root:
   ```bash
   EMAIL_API_KEY="re_your_api_key_here"
   EMAIL_TO="jmmadhusudhuoncz@gmail.com"
   EMAIL_FROM="onboarding@resend.dev"
   ```
2. Start the dev server: `npm run dev`
3. Test submissions at `http://localhost:3000`.

---

## 4. Security & Privacy
- `EMAIL_API_KEY` is strictly server-side and never bundled or exposed in client-side React code.
- Every submission includes customer `Reply-To` support so you can reply directly from your inbox.
- Anti-spam protection includes hidden honeypot validation and in-memory rate limiting.
- When `EMAIL_API_KEY` is not yet configured, the app provides instant 1-click fallback buttons (Open in Gmail, Send via WhatsApp, Copy Brief Text) so no inquiry is ever lost.
