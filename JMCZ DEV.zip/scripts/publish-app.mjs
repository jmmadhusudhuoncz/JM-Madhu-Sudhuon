#!/usr/bin/env node
/**
 * JM/CZ One-Step App + File Publishing System
 * 
 * Usage:
 *   node scripts/publish-app.mjs [path-to-config.json]
 *   Or pass CLI arguments:
 *   node scripts/publish-app.mjs --name="Score X Pro" --version="1.0.0" --file="ScoreXPro.apk" --desc="..."
 */

import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..');
const downloadsDir = path.join(rootDir, 'public', 'downloads');
const publishedAppsFile = path.join(rootDir, 'src', 'data', 'publishedApps.ts');

function detectFileType(filename) {
  const lower = (filename || '').toLowerCase();
  if (lower.endsWith('.apk')) return { type: 'APK', platform: 'Android', label: 'DOWNLOAD APK ↓' };
  if (lower.endsWith('.aab')) return { type: 'AAB', platform: 'Android', label: 'DOWNLOAD AAB ↓' };
  if (lower.endsWith('.zip')) return { type: 'ZIP', platform: 'Multi-platform', label: 'DOWNLOAD SOURCE ZIP ↓' };
  if (lower.endsWith('.pdf')) return { type: 'PDF', platform: 'Document', label: 'DOWNLOAD PDF ↓' };
  return { type: 'FILE', platform: 'Multi-platform', label: 'DOWNLOAD FILE ↓' };
}

function formatBytes(bytes) {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
}

function parseCliArgs() {
  const args = process.argv.slice(2);
  const config = {};

  if (args.length === 1 && !args[0].startsWith('--') && fs.existsSync(args[0])) {
    const raw = fs.readFileSync(args[0], 'utf-8');
    return JSON.parse(raw);
  }

  for (const arg of args) {
    if (arg.startsWith('--')) {
      const [key, ...values] = arg.slice(2).split('=');
      config[key] = values.join('=');
    }
  }
  return config;
}

async function runPublisher() {
  const input = parseCliArgs();

  // If no input was passed, check if a default publish-input.json exists, or print usage
  let appInput = input;
  const defaultInputFile = path.join(rootDir, 'publish-input.json');

  if (Object.keys(input).length === 0) {
    if (fs.existsSync(defaultInputFile)) {
      appInput = JSON.parse(fs.readFileSync(defaultInputFile, 'utf-8'));
    } else {
      console.log('No input provided. Scanning existing downloads and verifying system...');
      // Validation run
      try {
        execSync('npm run build', { cwd: rootDir, stdio: 'inherit' });
        console.log('Build: PASS');
      } catch (e) {
        console.error('Build: FAIL', e.message);
      }
      return;
    }
  }

  const name = appInput.name || appInput['APP NAME'] || appInput.title;
  const version = appInput.version || appInput['VERSION'] || '1.0.0';
  const description = appInput.description || appInput['SHORT DESCRIPTION'] || appInput['DESCRIPTION'] || '';
  const fullDescription = appInput.fullDescription || appInput['FULL DESCRIPTION'] || description;
  const category = appInput.category || appInput['CATEGORY'] || 'Software / Utility';
  const rawFile = appInput.file || appInput.apk || appInput.zip || appInput['FILE'] || '';
  const features = appInput.features || appInput['FEATURES'] || [];
  const technologies = appInput.technologies || appInput['TECHNOLOGIES'] || [];
  const github = appInput.github || appInput['GITHUB'] || '';
  const liveDemo = appInput.liveDemo || appInput['LIVE DEMO'] || '';
  const screenshots = appInput.screenshots || appInput['SCREENSHOTS'] || [];
  const releaseDate = appInput.releaseDate || appInput['RELEASE DATE'] || String(new Date().getFullYear());
  const requestedStatus = appInput.status || appInput['STATUS'] || 'available';

  const missingInfo = [];
  const errors = [];

  if (!name) missingInfo.push('APP NAME is required');
  if (!version) missingInfo.push('VERSION is required');
  if (!description) missingInfo.push('DESCRIPTION is required');
  if (!rawFile) missingInfo.push('FILE (APK or ZIP) is required');

  if (missingInfo.length > 0) {
    console.error('============================================================');
    console.error('VALIDATION FAILED: MISSING REQUIRED FIELDS');
    console.error('============================================================');
    missingInfo.forEach(m => console.error('- ' + m));
    process.exit(1);
  }

  // Handle single file or multiple files
  const fileList = Array.isArray(rawFile) ? rawFile : [rawFile];
  const registeredFiles = [];
  let detectedPlatform = appInput.platform || appInput['PLATFORM'] || '';

  for (const f of fileList) {
    const filename = path.basename(f);
    const targetFilePath = path.join(downloadsDir, filename);
    const fileExists = fs.existsSync(targetFilePath);
    const detected = detectFileType(filename);

    if (!detectedPlatform) {
      detectedPlatform = detected.platform;
    }

    let realSize = undefined;
    if (fileExists) {
      const stats = fs.statSync(targetFilePath);
      realSize = formatBytes(stats.size);
    } else {
      missingInfo.push(`Physical file "${filename}" is not yet found in public/downloads/. Set to coming-soon.`);
    }

    registeredFiles.push({
      type: detected.type,
      name: filename,
      path: `/downloads/${filename}`,
      exists: fileExists,
      size: realSize,
      label: detected.label
    });
  }

  // Calculate safe ID
  const appId = (appInput.id || name).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');

  const finalStatus = registeredFiles.every(f => f.exists) ? requestedStatus : 'coming-soon';

  const appRecord = {
    id: appId,
    name: name,
    version: version,
    description: description,
    fullDescription: fullDescription,
    category: category,
    platform: detectedPlatform || 'Android',
    fileType: registeredFiles.map(f => f.type).join(' + '),
    files: registeredFiles,
    features: Array.isArray(features) ? features : [],
    technologies: Array.isArray(technologies) ? technologies : [],
    github: github || '',
    liveDemo: liveDemo || '',
    screenshots: Array.isArray(screenshots) ? screenshots : [],
    status: finalStatus,
    releaseDate: releaseDate,
    showInProjects: appInput.showInProjects !== false,
    showInDownloads: true
  };

  // Read current publishedApps.ts
  const currentContent = fs.readFileSync(publishedAppsFile, 'utf-8');

  // Extract existing publishedAppsData array
  const markerStart = 'export const publishedAppsData: PublishedApp[] = [';
  const markerEnd = '];';

  const startIndex = currentContent.indexOf(markerStart);
  if (startIndex === -1) {
    errors.push('Could not locate publishedAppsData array in src/data/publishedApps.ts');
  } else {
    const endIndex = currentContent.indexOf(markerEnd, startIndex);
    const arrayStr = currentContent.slice(startIndex + markerStart.length - 1, endIndex + 1);

    let existingApps = [];
    try {
      // Evaluate or regex parse the array
      // To be safe and clean with TypeScript typing, we can parse or replace in JSON format
      const jsonLike = arrayStr.replace(/\/\/.*$/gm, '').trim();
      existingApps = (new Function(`return ${jsonLike};`))();
    } catch {
      existingApps = [];
    }

    // Check if app already exists -> update it in place
    const existingIndex = existingApps.findIndex(a => a.id === appId || a.name.toLowerCase() === name.toLowerCase());
    let operation = 'Added';
    if (existingIndex >= 0) {
      existingApps[existingIndex] = { ...existingApps[existingIndex], ...appRecord };
      operation = 'Updated';
    } else {
      existingApps.push(appRecord);
    }

    // Format new file content
    const newArrayFormatted = JSON.stringify(existingApps, null, 2);
    const newContent = currentContent.slice(0, startIndex + markerStart.length - 1) +
      newArrayFormatted +
      currentContent.slice(endIndex + 1);

    fs.writeFileSync(publishedAppsFile, newContent, 'utf-8');
    console.log(`[APP PUBLISHER] ${operation} app "${name}" in ${publishedAppsFile}`);
  }

  // Run production build
  let buildResult = 'PASS';
  try {
    execSync('npm run build', { cwd: rootDir, stdio: 'pipe' });
  } catch (err) {
    buildResult = 'FAIL';
    errors.push(err.message || 'Vite build failure');
  }

  // Report in exact specified format
  console.log(`
============================================================
APP PUBLISHED / UPDATE COMPLETED
============================================================

App Name:
${name}

Version:
${version}

File:
${registeredFiles.map(f => f.name).join(', ')}

File Type:
${registeredFiles.map(f => f.type).join(', ')}

Download Path:
${registeredFiles.map(f => f.path).join(', ')}

Website:
Updated

App:
Updated

Details Page:
Updated

Project Section:
Updated

Download Section:
Updated

Search:
Updated

Build:
${buildResult}

Missing Information:
${missingInfo.length > 0 ? missingInfo.join('\n') : 'None'}

Errors:
${errors.length > 0 ? errors.join('\n') : 'None'}
`);
}

runPublisher().catch(e => {
  console.error('Fatal Publisher Error:', e);
  process.exit(1);
});
