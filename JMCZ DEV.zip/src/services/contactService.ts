/**
 * JM/CZ Contact & Project Request Service
 * Handles client-side validation, secure server API dispatch,
 * and reliable fallback mechanisms (mailto / WhatsApp / clipboard).
 */

import { saveContactToFirebase } from './firebase';

export interface ProjectSubmission {
  name: string;
  email: string;
  phone?: string;
  projectType: string;
  budget?: string;
  preferredContact: 'Email' | 'WhatsApp';
  subject: string;
  message: string;
}

export interface ContactResponse {
  success: boolean;
  configured: boolean;
  message: string;
  messageId?: string;
  error?: string;
  timestamp?: string;
}

export const PROJECT_TYPES = [
  'Web Development',
  'Android App',
  'AI / ML',
  'C++',
  'Python',
  'UI/UX',
  '3D / Engineering',
  'Portfolio Website',
  'Digital Product',
  'Project Consultation',
  'Other',
] as const;

export const RECIPIENT_EMAIL = 'jmmadhusudhuoncz@gmail.com';

/**
 * Validates the project request input fields.
 */
export function validateSubmission(data: Partial<ProjectSubmission>): { valid: boolean; errors: Record<string, string> } {
  const errors: Record<string, string> = {};

  if (!data.name || !data.name.trim()) {
    errors.name = 'Full name is required.';
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!data.email || !data.email.trim()) {
    errors.email = 'Email address is required.';
  } else if (!emailRegex.test(data.email.trim())) {
    errors.email = 'Please enter a valid email address.';
  }

  if (!data.subject || !data.subject.trim()) {
    errors.subject = 'Subject is required.';
  }

  if (!data.projectType || !data.projectType.trim()) {
    errors.projectType = 'Please select a project type.';
  }

  if (!data.message || !data.message.trim()) {
    errors.message = 'Please provide details about your project or inquiry.';
  } else if (data.message.trim().length < 10) {
    errors.message = 'Message must be at least 10 characters.';
  }

  return {
    valid: Object.keys(errors).length === 0,
    errors,
  };
}

/**
 * Formats submission text according to the exact project specification.
 */
export function formatEmailBody(data: ProjectSubmission, timestamp: string = new Date().toISOString()): string {
  return [
    '--------------------------------',
    'NEW JM/CZ PROJECT REQUEST',
    '--------------------------------',
    '',
    'Name:',
    data.name.trim(),
    '',
    'Email:',
    data.email.trim(),
    '',
    'Phone / WhatsApp:',
    data.phone && data.phone.trim() ? data.phone.trim() : 'Not provided',
    '',
    'Project Type:',
    data.projectType,
    '',
    'Budget:',
    data.budget && data.budget.trim() ? data.budget.trim() : 'Not specified',
    '',
    'Preferred Contact:',
    data.preferredContact || 'Email',
    '',
    'Subject:',
    data.subject.trim(),
    '',
    'Message:',
    data.message.trim(),
    '',
    'Submitted At:',
    timestamp,
    '',
    'Source:',
    'JM/CZ Portfolio Website',
    '',
    '--------------------------------',
  ].join('\n');
}

/**
 * Dispatches the project request to the secure backend endpoint /api/contact.
 * Does NOT fake a success message.
 */
export async function submitProjectRequest(data: ProjectSubmission): Promise<ContactResponse> {
  const validation = validateSubmission(data);
  if (!validation.valid) {
    const firstError = Object.values(validation.errors)[0];
    return {
      success: false,
      configured: true,
      message: firstError,
      error: firstError,
    };
  }

  // 1. Persist directly to Firebase contacts/ collection for the Admin Panel
  let firebaseSaved = false;
  let firebaseDocId = '';
  try {
    const fbRes = await saveContactToFirebase({
      name: data.name,
      email: data.email,
      phone: data.phone,
      projectType: data.projectType,
      budget: data.budget,
      subject: data.subject,
      message: data.message,
    });
    if (fbRes.success) {
      firebaseSaved = true;
      firebaseDocId = fbRes.id || '';
    }
  } catch {
    // Fallback to email API
  }

  // 2. Also dispatch to /api/contact email endpoint if reachable
  try {
    const response = await fetch('/api/contact', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    });

    const result = await response.json().catch(() => null);

    if (response.ok && result && result.success) {
      return {
        success: true,
        configured: true,
        message: result.message || 'REQUEST RECORDED & SENT SUCCESSFULLY',
        messageId: result.messageId || firebaseDocId,
        timestamp: result.timestamp || new Date().toISOString(),
      };
    }

    // If server responded with unconfigured email but Firebase saved successfully
    if (firebaseSaved) {
      return {
        success: true,
        configured: true,
        message: 'REQUEST SAVED SUCCESSFULLY IN DATABASE',
        messageId: firebaseDocId,
        timestamp: new Date().toISOString(),
      };
    }

    if (result && result.configured === false) {
      return {
        success: false,
        configured: false,
        message: result.error || 'Email service pending configuration. Use direct email client fallback below.',
        error: result.error,
      };
    }

    return {
      success: false,
      configured: result ? result.configured !== false : true,
      message: result?.error || result?.details || `Server responded with status ${response.status}`,
      error: result?.error || `HTTP error ${response.status}`,
    };
  } catch (err: unknown) {
    if (firebaseSaved) {
      return {
        success: true,
        configured: true,
        message: 'REQUEST SAVED SUCCESSFULLY IN DATABASE',
        messageId: firebaseDocId,
        timestamp: new Date().toISOString(),
      };
    }

    const errorMsg = err instanceof Error ? err.message : 'Network request failed';
    return {
      success: false,
      configured: false,
      message: `Network error reaching submission API (${errorMsg}). You can send directly using the mailto button below.`,
      error: errorMsg,
    };
  }
}

/**
 * Generates a pre-filled mailto URL for direct email client opening.
 */
export function generateMailtoUrl(data: ProjectSubmission): string {
  const subject = `[JM/CZ PROJECT REQUEST] ${data.projectType || 'General'}: ${data.subject || 'Inquiry'}`;
  const body = formatEmailBody(data);
  return `mailto:${RECIPIENT_EMAIL}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
}

/**
 * Generates a pre-filled WhatsApp link with the submission content.
 */
export function generateWhatsAppUrl(data: ProjectSubmission): string {
  const text = `*NEW JM/CZ PROJECT REQUEST*\n\n*Name:* ${data.name}\n*Email:* ${data.email}\n*Phone/WA:* ${data.phone || 'N/A'}\n*Project Type:* ${data.projectType}\n*Budget:* ${data.budget || 'N/A'}\n*Subject:* ${data.subject}\n\n*Message:*\n${data.message}`;
  return `https://api.whatsapp.com/send?text=${encodeURIComponent(text)}`;
}

/**
 * Copies the complete formatted request to clipboard.
 */
export async function copySubmissionToClipboard(data: ProjectSubmission): Promise<boolean> {
  try {
    const body = formatEmailBody(data);
    await navigator.clipboard.writeText(body);
    return true;
  } catch {
    return false;
  }
}
