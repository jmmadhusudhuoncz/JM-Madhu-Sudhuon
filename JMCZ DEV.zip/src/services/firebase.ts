import { initializeApp, getApps, getApp, setLogLevel as setFirebaseAppLogLevel } from 'firebase/app';
import { getAnalytics, isSupported, Analytics } from 'firebase/analytics';
import {
  getFirestore,
  collection,
  doc,
  getDocFromServer,
  onSnapshot,
  query,
  addDoc,
  Firestore,
  setLogLevel as setFirestoreLogLevel,
} from 'firebase/firestore';
import {
  getStorage,
  ref as storageRef,
  getDownloadURL,
  FirebaseStorage,
} from 'firebase/storage';
import {
  getDatabase,
  ref as rtdbRef,
  onValue,
  push as rtdbPush,
  Database,
  enableLogging,
} from 'firebase/database';
import firebaseConfigData from '../../firebase-applet-config.json';
import { publishedAppsData, PublishedApp, AppFile, detectFileType, getDownloadButtonLabel } from '../data/publishedApps';
import { projectsData } from '../data/projects';
import { certificatesData } from '../data/certificates';
import { skillsData } from '../data/skills';
import { capabilitiesData } from '../data/capabilities';
import { profile } from '../data/profile';
import { socialsData } from '../data/socials';

// Silence verbose internal Firebase SDK debug/warning logs in console
try {
  setFirebaseAppLogLevel('silent');
  setFirestoreLogLevel('silent');
  enableLogging(false);
} catch {
  // Ignore if already configured
}

// Guard against benign background unhandled rejections from Analytics/Offline/SW in iframe environments
if (typeof window !== 'undefined') {
  window.addEventListener('unhandledrejection', (event) => {
    const reason = event?.reason;
    const msg = reason instanceof Error ? reason.message : String(reason || '');
    if (
      msg.includes('firebase') ||
      msg.includes('Firestore') ||
      msg.includes('Analytics') ||
      msg.includes('offline') ||
      msg.includes('permission') ||
      msg.includes('PERMISSION_DENIED') ||
      msg.includes('ServiceWorker') ||
      msg.includes('Failed to fetch') ||
      msg.includes('NetworkError')
    ) {
      event.preventDefault();
    }
  });
}

// Public project ID and config provided for portfoliodev-84fb2
export const firebaseConfig = {
  apiKey: firebaseConfigData.apiKey || 'AIzaSyDAgVe4e5y9wTje_N2_7Zd38MPydlC3eTo',
  authDomain: firebaseConfigData.authDomain || 'portfoliodev-84fb2.firebaseapp.com',
  databaseURL:
    firebaseConfigData.databaseURL ||
    'https://portfoliodev-84fb2-default-rtdb.asia-southeast1.firebasedatabase.app',
  projectId: firebaseConfigData.projectId || 'portfoliodev-84fb2',
  storageBucket: firebaseConfigData.storageBucket || 'portfoliodev-84fb2.firebasestorage.app',
  messagingSenderId: firebaseConfigData.messagingSenderId || '86836871971',
  appId: firebaseConfigData.appId || '1:86836871971:web:3165959388f712870c0296',
  measurementId: firebaseConfigData.measurementId || 'G-JFF2YRCTJL',
};

// Initialize or reuse Firebase App
export const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();

// Initialize Firebase Analytics safely (browser-safe, no unhandled rejections)
export let analytics: Analytics | null = null;
if (typeof window !== 'undefined') {
  isSupported()
    .then((supported) => {
      if (supported) {
        try {
          analytics = getAnalytics(app);
        } catch {
          // Ignore analytics initialization errors in restricted iframe contexts
        }
      }
    })
    .catch(() => {
      // Ignore analytics support check errors
    });
}

// Initialize Firestore: use named databaseId only if it belongs to the provisioned project,
// otherwise use the (default) database for portfoliodev-84fb2 so it never 404s.
const useNamedDb =
  firebaseConfigData.firestoreDatabaseId &&
  firebaseConfig.projectId !== 'portfoliodev-84fb2';

export const db: Firestore = useNamedDb
  ? getFirestore(app, firebaseConfigData.firestoreDatabaseId)
  : getFirestore(app);

// Initialize Firebase Storage
export const storage: FirebaseStorage = getStorage(app);

// Initialize Realtime Database with explicit database URL
let rtdbInstance: Database | null = null;
try {
  rtdbInstance = getDatabase(app, firebaseConfig.databaseURL);
} catch {
  rtdbInstance = null;
}
export const rtdb = rtdbInstance;

// Validate Firestore connection on boot without emitting noisy warnings
export async function validateFirestoreConnection(): Promise<boolean> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    return true;
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      return false;
    }
    return true;
  }
}

// Kick off validation non-blockingly
validateFirestoreConnection().catch(() => {});

/**
 * Resolves a download URL, automatically handling Firebase Storage refs (gs://, storage paths, or HTTP URLs).
 */
export async function resolveStorageDownloadUrl(filePathOrUrl: string): Promise<string> {
  if (!filePathOrUrl) return '';
  const trimmed = filePathOrUrl.trim();

  // If already an absolute HTTP/HTTPS URL or local path (/downloads/...)
  if (trimmed.startsWith('http://') || trimmed.startsWith('https://') || trimmed.startsWith('/')) {
    return trimmed;
  }

  // Handle Firebase Storage paths or gs:// URLs
  try {
    let cleanPath = trimmed;
    if (cleanPath.startsWith('gs://')) {
      const parts = cleanPath.replace('gs://', '').split('/');
      parts.shift(); // remove bucket
      cleanPath = parts.join('/');
    }
    const fileRef = storageRef(storage, cleanPath);
    return await getDownloadURL(fileRef);
  } catch {
    return '';
  }
}

/**
 * Normalizes raw App data from Firebase into the portfolio's PublishedApp structure.
 */
function normalizeAppFromFirebase(id: string, data: any): PublishedApp {
  const rawFiles = Array.isArray(data.files) ? data.files : [];
  const normalizedFiles: AppFile[] = rawFiles.map((f: any) => {
    const fileName = f.name || f.filename || `${data.name || 'App'}.${(f.type || 'zip').toLowerCase()}`;
    const fileType = (f.type || detectFileType(fileName).type).toUpperCase() as AppFile['type'];
    return {
      type: fileType,
      name: fileName,
      path: f.path || f.url || f.downloadUrl || '',
      exists: Boolean(f.exists !== false && (f.path || f.url || f.downloadUrl)),
      size: f.size || f.fileSize || undefined,
      label: f.label || getDownloadButtonLabel(fileType),
    };
  });

  // If top-level download URL or file fields are used (e.g. apkUrl, zipUrl)
  if (normalizedFiles.length === 0) {
    if (data.apkUrl) {
      normalizedFiles.push({
        type: 'APK',
        name: `${data.name || 'App'}.apk`,
        path: data.apkUrl,
        exists: true,
        label: 'DOWNLOAD APK ↓',
      });
    }
    if (data.zipUrl || data.sourceCodeUrl) {
      normalizedFiles.push({
        type: 'ZIP',
        name: `${data.name || 'App'}.zip`,
        path: data.zipUrl || data.sourceCodeUrl,
        exists: true,
        label: 'DOWNLOAD SOURCE ZIP ↓',
      });
    }
    if (data.aabUrl) {
      normalizedFiles.push({
        type: 'AAB',
        name: `${data.name || 'App'}.aab`,
        path: data.aabUrl,
        exists: true,
        label: 'DOWNLOAD AAB ↓',
      });
    }
  }

  const primaryFileType = normalizedFiles[0]?.type || data.fileType || 'ZIP';

  return {
    id: id || data.id,
    name: data.name || data.title || 'Untitled App',
    version: data.version || '1.0.0',
    description: data.description || '',
    fullDescription: data.fullDescription || data.description || '',
    category: data.category || 'Utility',
    platform: data.platform || (primaryFileType === 'APK' || primaryFileType === 'AAB' ? 'Android' : 'Multi-platform'),
    fileType: primaryFileType,
    files: normalizedFiles,
    features: Array.isArray(data.features) ? data.features : [],
    technologies: Array.isArray(data.technologies) ? data.technologies : [],
    github: data.github || data.repoUrl || '',
    liveDemo: data.liveDemo || data.demoUrl || '',
    screenshots: Array.isArray(data.screenshots) ? data.screenshots : [],
    status: data.status === 'published' ? 'available' : (data.status || 'available'),
    releaseDate: data.releaseDate || (data.createdAt ? String(data.createdAt).substring(0, 4) : '2026'),
    showInProjects: data.showInProjects !== false,
    showInDownloads: data.showInDownloads !== false,
  };
}

/**
 * Normalizes Project data from Firebase.
 */
function normalizeProjectFromFirebase(id: string, data: any, index: number) {
  return {
    id: id || data.id,
    number: data.number || String(index + 1).padStart(2, '0'),
    title: data.title || data.name || 'Untitled Project',
    subtitle: data.subtitle || data.tagline || '',
    status: data.projectStatus || (data.status === 'published' ? 'Completed' : (data.status || 'Completed')),
    category: data.category || 'General',
    role: data.role || 'Developer & Architect',
    problem: data.problem || data.description || '',
    solution: data.solution || '',
    technology: Array.isArray(data.technology)
      ? data.technology
      : Array.isArray(data.technologies)
      ? data.technologies
      : [],
    features: Array.isArray(data.features) ? data.features : [],
    learning: data.learning || '',
    image: data.image || data.imageUrl || data.coverImage || '',
    links: {
      demo: data.links?.demo || data.demoUrl || data.liveDemo || '',
      repo: data.links?.repo || data.repoUrl || data.github || '',
    },
  };
}

// -------------------------------------------------------------
// REALTIME SUBSCRIPTIONS (Firestore & RTDB with silent fallback)
// -------------------------------------------------------------

/**
 * Subscribes to published Apps in realtime.
 */
export function subscribeToPublishedApps(
  onUpdate: (apps: PublishedApp[]) => void
): () => void {
  let unsubscribed = false;

  // 1. Listener on Firestore /apps
  let unsubscribeFirestore = () => {};
  try {
    const q = query(collection(db, 'apps'));
    unsubscribeFirestore = onSnapshot(
      q,
      (snapshot) => {
        if (unsubscribed) return;
        if (!snapshot.empty) {
          const appsList: PublishedApp[] = [];
          snapshot.forEach((docSnap) => {
            const data = docSnap.data();
            if (data.status === 'published' || data.published === true || !('status' in data)) {
              appsList.push(normalizeAppFromFirebase(docSnap.id, data));
            }
          });
          if (appsList.length > 0) {
            onUpdate(appsList);
            return;
          }
        }
        onUpdate(publishedAppsData);
      },
      () => {
        if (!unsubscribed) {
          onUpdate(publishedAppsData);
        }
      }
    );
  } catch {
    onUpdate(publishedAppsData);
  }

  // 2. Listener on Realtime Database apps/
  let unsubscribeRtdb = () => {};
  if (rtdb) {
    try {
      const appsRef = rtdbRef(rtdb, 'apps');
      unsubscribeRtdb = onValue(
        appsRef,
        (snapshot) => {
          if (unsubscribed) return;
          const val = snapshot.val();
          if (val && typeof val === 'object') {
            const rtdbApps: PublishedApp[] = [];
            Object.keys(val).forEach((key) => {
              const item = val[key];
              if (item && (item.status === 'published' || item.published === true || !('status' in item))) {
                rtdbApps.push(normalizeAppFromFirebase(key, item));
              }
            });
            if (rtdbApps.length > 0) {
              onUpdate(rtdbApps);
            }
          }
        },
        () => {
          // Silently fallback to local data if RTDB rules restrict access
        }
      );
    } catch {
      // Ignore RTDB subscription errors
    }
  }

  return () => {
    unsubscribed = true;
    unsubscribeFirestore();
    unsubscribeRtdb();
  };
}

/**
 * Subscribes to published Projects in realtime.
 */
export function subscribeToPublishedProjects(
  onUpdate: (projects: typeof projectsData) => void
): () => void {
  let unsubscribed = false;

  let unsubscribeFirestore = () => {};
  try {
    const q = query(collection(db, 'projects'));
    unsubscribeFirestore = onSnapshot(
      q,
      (snapshot) => {
        if (unsubscribed) return;
        if (!snapshot.empty) {
          const projList: any[] = [];
          let idx = 0;
          snapshot.forEach((docSnap) => {
            const data = docSnap.data();
            if (data.status === 'published' || data.published === true || !('status' in data)) {
              projList.push(normalizeProjectFromFirebase(docSnap.id, data, idx++));
            }
          });
          if (projList.length > 0) {
            onUpdate(projList as typeof projectsData);
            return;
          }
        }
        onUpdate(projectsData);
      },
      () => {
        if (!unsubscribed) {
          onUpdate(projectsData);
        }
      }
    );
  } catch {
    onUpdate(projectsData);
  }

  let unsubscribeRtdb = () => {};
  if (rtdb) {
    try {
      const projRef = rtdbRef(rtdb, 'projects');
      unsubscribeRtdb = onValue(
        projRef,
        (snapshot) => {
          if (unsubscribed) return;
          const val = snapshot.val();
          if (val && typeof val === 'object') {
            const rtdbProjects: any[] = [];
            let idx = 0;
            Object.keys(val).forEach((key) => {
              const item = val[key];
              if (item && (item.status === 'published' || item.published === true || !('status' in item))) {
                rtdbProjects.push(normalizeProjectFromFirebase(key, item, idx++));
              }
            });
            if (rtdbProjects.length > 0) {
              onUpdate(rtdbProjects as typeof projectsData);
            }
          }
        },
        () => {}
      );
    } catch {}
  }

  return () => {
    unsubscribed = true;
    unsubscribeFirestore();
    unsubscribeRtdb();
  };
}

/**
 * Subscribes to published Certificates in realtime.
 */
export function subscribeToCertificates(
  onUpdate: (certs: typeof certificatesData) => void
): () => void {
  let unsubscribed = false;

  let unsubscribeFirestore = () => {};
  try {
    const q = query(collection(db, 'certificates'));
    unsubscribeFirestore = onSnapshot(
      q,
      (snapshot) => {
        if (unsubscribed) return;
        if (!snapshot.empty) {
          const certList: any[] = [];
          snapshot.forEach((docSnap) => {
            const data = docSnap.data();
            if (data.status === 'published' || data.published === true || !('status' in data)) {
              certList.push({
                id: docSnap.id,
                title: data.title || '',
                issuer: data.issuer || '',
                category: data.category || '',
                date: data.date || '',
                credentialId: data.credentialId || '',
                image: data.image || data.imageUrl || '',
                pdf: data.pdf || data.pdfUrl || '',
                verificationUrl: data.verificationUrl || data.url || '',
                description: data.description || '',
              });
            }
          });
          if (certList.length > 0) {
            onUpdate(certList as typeof certificatesData);
            return;
          }
        }
        onUpdate(certificatesData);
      },
      () => {
        if (!unsubscribed) onUpdate(certificatesData);
      }
    );
  } catch {
    onUpdate(certificatesData);
  }

  let unsubscribeRtdb = () => {};
  if (rtdb) {
    try {
      const certRef = rtdbRef(rtdb, 'certificates');
      unsubscribeRtdb = onValue(
        certRef,
        (snapshot) => {
          if (unsubscribed) return;
          const val = snapshot.val();
          if (val && typeof val === 'object') {
            const rtdbCerts: any[] = [];
            Object.keys(val).forEach((key) => {
              const item = val[key];
              if (item && (item.status === 'published' || item.published === true || !('status' in item))) {
                rtdbCerts.push({
                  id: key,
                  title: item.title || '',
                  issuer: item.issuer || '',
                  category: item.category || '',
                  date: item.date || '',
                  credentialId: item.credentialId || '',
                  image: item.image || item.imageUrl || '',
                  pdf: item.pdf || item.pdfUrl || '',
                  verificationUrl: item.verificationUrl || item.url || '',
                  description: item.description || '',
                });
              }
            });
            if (rtdbCerts.length > 0) {
              onUpdate(rtdbCerts as typeof certificatesData);
            }
          }
        },
        () => {}
      );
    } catch {}
  }

  return () => {
    unsubscribed = true;
    unsubscribeFirestore();
    unsubscribeRtdb();
  };
}

/**
 * Subscribes to Skills in realtime.
 */
export function subscribeToSkills(
  onUpdate: (skills: typeof skillsData) => void
): () => void {
  let unsubscribed = false;

  let unsubscribeFirestore = () => {};
  try {
    const q = query(collection(db, 'skills'));
    unsubscribeFirestore = onSnapshot(
      q,
      (snapshot) => {
        if (unsubscribed) return;
        if (!snapshot.empty) {
          const skillList: any[] = [];
          snapshot.forEach((docSnap) => {
            const data = docSnap.data();
            if (data.status === 'published' || data.published === true || !('status' in data)) {
              skillList.push({
                category: data.category || docSnap.id.toUpperCase(),
                skills: Array.isArray(data.skills) ? data.skills : [],
              });
            }
          });
          if (skillList.length > 0) {
            onUpdate(skillList as typeof skillsData);
            return;
          }
        }
        onUpdate(skillsData);
      },
      () => {
        if (!unsubscribed) onUpdate(skillsData);
      }
    );
  } catch {
    onUpdate(skillsData);
  }

  let unsubscribeRtdb = () => {};
  if (rtdb) {
    try {
      const skillsRef = rtdbRef(rtdb, 'skills');
      unsubscribeRtdb = onValue(
        skillsRef,
        (snapshot) => {
          if (unsubscribed) return;
          const val = snapshot.val();
          if (val && typeof val === 'object') {
            const rtdbSkills: any[] = [];
            if (Array.isArray(val)) {
              val.forEach((item, idx) => {
                if (item) {
                  rtdbSkills.push({
                    category: item.category || `CATEGORY ${idx + 1}`,
                    skills: Array.isArray(item.skills) ? item.skills : [],
                  });
                }
              });
            } else {
              Object.keys(val).forEach((key) => {
                const item = val[key];
                if (item) {
                  rtdbSkills.push({
                    category: item.category || key.toUpperCase(),
                    skills: Array.isArray(item.skills) ? item.skills : [],
                  });
                }
              });
            }
            if (rtdbSkills.length > 0) {
              onUpdate(rtdbSkills as typeof skillsData);
            }
          }
        },
        () => {}
      );
    } catch {}
  }

  return () => {
    unsubscribed = true;
    unsubscribeFirestore();
    unsubscribeRtdb();
  };
}

/**
 * Subscribes to Services / Capabilities in realtime.
 */
export function subscribeToServices(
  onUpdate: (services: typeof capabilitiesData) => void
): () => void {
  let unsubscribed = false;

  let unsubscribeFirestore = () => {};
  try {
    const q = query(collection(db, 'services'));
    unsubscribeFirestore = onSnapshot(
      q,
      (snapshot) => {
        if (unsubscribed) return;
        if (!snapshot.empty) {
          const list: any[] = [];
          let idx = 1;
          snapshot.forEach((docSnap) => {
            const data = docSnap.data();
            if (data.status === 'published' || data.published === true || !('status' in data)) {
              list.push({
                id: docSnap.id,
                code: data.code || `CAP_${String(idx++).padStart(2, '0')}`,
                title: data.title || '',
                subtitle: data.subtitle || '',
                description: data.description || '',
                items: Array.isArray(data.items) ? data.items : [],
              });
            }
          });
          if (list.length > 0) {
            onUpdate(list as typeof capabilitiesData);
            return;
          }
        }
        onUpdate(capabilitiesData);
      },
      () => {
        if (!unsubscribed) onUpdate(capabilitiesData);
      }
    );
  } catch {
    onUpdate(capabilitiesData);
  }

  let unsubscribeRtdb = () => {};
  if (rtdb) {
    try {
      const servicesRef = rtdbRef(rtdb, 'services');
      unsubscribeRtdb = onValue(
        servicesRef,
        (snapshot) => {
          if (unsubscribed) return;
          const val = snapshot.val();
          if (val && typeof val === 'object') {
            const list: any[] = [];
            let idx = 1;
            Object.keys(val).forEach((key) => {
              const data = val[key];
              if (data && (data.status === 'published' || data.published === true || !('status' in data))) {
                list.push({
                  id: key,
                  code: data.code || `CAP_${String(idx++).padStart(2, '0')}`,
                  title: data.title || '',
                  subtitle: data.subtitle || '',
                  description: data.description || '',
                  items: Array.isArray(data.items) ? data.items : [],
                });
              }
            });
            if (list.length > 0) {
              onUpdate(list as typeof capabilitiesData);
            }
          }
        },
        () => {}
      );
    } catch {}
  }

  return () => {
    unsubscribed = true;
    unsubscribeFirestore();
    unsubscribeRtdb();
  };
}

/**
 * Subscribes to About info in realtime.
 */
export function subscribeToAbout(
  onUpdate: (about: typeof profile) => void
): () => void {
  let unsubscribed = false;

  let unsubscribeFirestore = () => {};
  try {
    const q = query(collection(db, 'about'));
    unsubscribeFirestore = onSnapshot(
      q,
      (snapshot) => {
        if (unsubscribed) return;
        if (!snapshot.empty) {
          const firstDoc = snapshot.docs[0].data();
          if (firstDoc) {
            onUpdate({
              ...profile,
              ...firstDoc,
            });
            return;
          }
        }
        onUpdate(profile);
      },
      () => {
        if (!unsubscribed) onUpdate(profile);
      }
    );
  } catch {
    onUpdate(profile);
  }

  let unsubscribeRtdb = () => {};
  if (rtdb) {
    try {
      const aboutRef = rtdbRef(rtdb, 'about');
      unsubscribeRtdb = onValue(
        aboutRef,
        (snapshot) => {
          if (unsubscribed) return;
          const val = snapshot.val();
          if (val && typeof val === 'object') {
            onUpdate({
              ...profile,
              ...val,
            });
          }
        },
        () => {}
      );
    } catch {}
  }

  return () => {
    unsubscribed = true;
    unsubscribeFirestore();
    unsubscribeRtdb();
  };
}

/**
 * Subscribes to Social Links in realtime.
 */
export function subscribeToSocials(
  onUpdate: (socials: typeof socialsData) => void
): () => void {
  let unsubscribed = false;

  let unsubscribeFirestore = () => {};
  try {
    const q = query(collection(db, 'socialLinks'));
    unsubscribeFirestore = onSnapshot(
      q,
      (snapshot) => {
        if (unsubscribed) return;
        if (!snapshot.empty) {
          const links: any[] = [];
          snapshot.forEach((docSnap) => {
            const data = docSnap.data();
            if (data.status === 'published' || data.published === true || !('status' in data)) {
              links.push({
                id: docSnap.id,
                label: data.label || '',
                username: data.username || '',
                url: data.url || '',
                isConfigured: Boolean(data.url),
                placeholder: data.url || '',
                description: data.description || '',
              });
            }
          });
          if (links.length > 0) {
            onUpdate(links as typeof socialsData);
            return;
          }
        }
        onUpdate(socialsData);
      },
      () => {
        if (!unsubscribed) onUpdate(socialsData);
      }
    );
  } catch {
    onUpdate(socialsData);
  }

  let unsubscribeRtdb = () => {};
  if (rtdb) {
    try {
      const socialsRef = rtdbRef(rtdb, 'socialLinks');
      unsubscribeRtdb = onValue(
        socialsRef,
        (snapshot) => {
          if (unsubscribed) return;
          const val = snapshot.val();
          if (val && typeof val === 'object') {
            const links: any[] = [];
            Object.keys(val).forEach((key) => {
              const data = val[key];
              if (data && (data.status === 'published' || data.published === true || !('status' in data))) {
                links.push({
                  id: key,
                  label: data.label || '',
                  username: data.username || '',
                  url: data.url || '',
                  isConfigured: Boolean(data.url),
                  placeholder: data.url || '',
                  description: data.description || '',
                });
              }
            });
            if (links.length > 0) {
              onUpdate(links as typeof socialsData);
            }
          }
        },
        () => {}
      );
    } catch {}
  }

  return () => {
    unsubscribed = true;
    unsubscribeFirestore();
    unsubscribeRtdb();
  };
}

/**
 * Submits a contact/project request to Firebase contacts/ collection and RTDB.
 * Conforms strictly to security rules and requirements:
 * Fields: Name, Email, Phone, Project Type, Budget, Message, createdAt, status ('new').
 */
export async function saveContactToFirebase(contact: {
  name: string;
  email: string;
  phone?: string;
  projectType: string;
  budget?: string;
  message: string;
  subject?: string;
}): Promise<{ success: boolean; id?: string; error?: string }> {
  const createdAt = new Date().toISOString();
  const payload = {
    name: contact.name.trim(),
    Name: contact.name.trim(),
    email: contact.email.trim(),
    Email: contact.email.trim(),
    phone: (contact.phone || '').trim(),
    Phone: (contact.phone || '').trim() || 'N/A',
    projectType: contact.projectType,
    'Project Type': contact.projectType,
    budget: (contact.budget || '').trim(),
    Budget: (contact.budget || '').trim() || 'N/A',
    subject: (contact.subject || '').trim(),
    message: contact.message.trim(),
    Message: contact.message.trim(),
    status: 'new',
    createdAt,
  };

  let savedId = '';
  let writeSuccess = false;

  // 1. Write to Realtime Database contacts/
  if (rtdb) {
    try {
      const rtdbContactsRef = rtdbRef(rtdb, 'contacts');
      const rtdbRes = await rtdbPush(rtdbContactsRef, payload);
      if (rtdbRes && rtdbRes.key) {
        savedId = rtdbRes.key;
        writeSuccess = true;
      }
    } catch {
      // Fallback to Firestore/API if RTDB write is restricted
    }
  }

  // 2. Write to Firestore contacts/
  try {
    const docRef = await addDoc(collection(db, 'contacts'), payload);
    if (docRef && docRef.id) {
      savedId = docRef.id;
      writeSuccess = true;
    }
  } catch {
    // Fallback to API if Firestore write is restricted
  }

  if (writeSuccess) {
    return {
      success: true,
      id: savedId,
    };
  }

  return {
    success: false,
    error: 'Database submission could not be completed at this time.',
  };
}
