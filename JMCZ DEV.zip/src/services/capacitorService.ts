import { Capacitor } from '@capacitor/core';
import { App as CapApp } from '@capacitor/app';
import { StatusBar, Style } from '@capacitor/status-bar';
import { SplashScreen } from '@capacitor/splash-screen';
import { Share } from '@capacitor/share';

export interface ShareOptions {
  title: string;
  text: string;
  url?: string;
}

export class CapacitorService {
  private static backButtonHandlers: Array<() => boolean> = [];
  private static isInitialized = false;

  public static isNative(): boolean {
    return Capacitor.isNativePlatform();
  }

  public static async initNativeFeatures(): Promise<void> {
    if (this.isInitialized) return;
    this.isInitialized = true;

    if (this.isNative()) {
      try {
        await StatusBar.setStyle({ style: Style.Dark });
        await StatusBar.setBackgroundColor({ color: '#000000' });
      } catch {
        // Ignore on unsupported native targets
      }

      try {
        await SplashScreen.hide();
      } catch {
        // Ignore on unsupported native targets
      }

      try {
        await CapApp.addListener('backButton', () => {
          // Execute the topmost registered back handler
          for (let i = this.backButtonHandlers.length - 1; i >= 0; i--) {
            const handled = this.backButtonHandlers[i]();
            if (handled) {
              return;
            }
          }
          // Default behavior if nothing handled
          if (window.history.length > 1) {
            window.history.back();
          } else {
            CapApp.exitApp();
          }
        });
      } catch {
        // Ignore on unsupported native targets
      }
    }
  }

  /**
   * Register a back button interceptor.
   * Return true to indicate the event was handled and should not bubble further.
   */
  public static registerBackButtonHandler(handler: () => boolean): () => void {
    this.backButtonHandlers.push(handler);
    return () => {
      this.backButtonHandlers = this.backButtonHandlers.filter((h) => h !== handler);
    };
  }

  /**
   * Native Android share with web fallbacks.
   */
  public static async share(options: ShareOptions): Promise<boolean> {
    if (this.isNative()) {
      try {
        await Share.share({
          title: options.title,
          text: options.text,
          url: options.url,
          dialogTitle: 'Share Project — JM/CZ Portfolio',
        });
        return true;
      } catch {
        // Fallback to Web Share / Clipboard
      }
    }

    // Web Share API fallback
    if (typeof navigator !== 'undefined' && navigator.share) {
      try {
        await navigator.share({
          title: options.title,
          text: options.text,
          url: options.url || window.location.href,
        });
        return true;
      } catch {
        // Fallback to Clipboard
      }
    }

    // Clipboard fallback
    try {
      const shareText = `${options.title}\n${options.text}${options.url ? `\n${options.url}` : ''}`;
      await navigator.clipboard.writeText(shareText);
      return true;
    } catch {
      return false;
    }
  }

  /**
   * Verify and handle CV opening/downloading.
   */
  public static async handleCvDownload(
    cvPath: string,
    onMissing: () => void
  ): Promise<void> {
    try {
      const res = await fetch(cvPath, { method: 'HEAD' });
      if (res.ok) {
        const link = document.createElement('a');
        link.href = cvPath;
        link.download = 'JM-Madhu-Sudhuon-CZ-CV.pdf';
        link.target = '_blank';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      } else {
        onMissing();
      }
    } catch {
      onMissing();
    }
  }
}
