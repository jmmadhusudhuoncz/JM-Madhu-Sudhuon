import React, { useState, useEffect } from 'react';
import { Navigation } from './components/Navigation';
import { Hero } from './components/Hero';
import { Projects, ProjectItem } from './components/Projects';
import { SkillsAndCapabilities } from './components/SkillsAndCapabilities';
import { Certifications, CertificateItem } from './components/Certifications';
import { AboutSection } from './components/AboutSection';
import { Journey } from './components/Journey';
import { AppDownloadSection } from './components/AppDownloadSection';
import { FooterAndTerminal } from './components/FooterAndTerminal';
import {
  ContactModal,
  ProjectModal,
  CertificateModal,
  CvModal,
  AppDetailsModal,
} from './components/Modals';
import { PublishedApp } from './data/publishedApps';
import { OfflineIndicator } from './components/OfflineIndicator';
import { CapacitorService } from './services/capacitorService';
import { useFirebaseData } from './hooks/useFirebaseData';

export default function App() {
  const firebaseData = useFirebaseData();
  const [activeSection, setActiveSection] = useState('home');
  const [isConnectOpen, setIsConnectOpen] = useState(false);
  const [isCvOpen, setIsCvOpen] = useState(false);
  const [selectedProject, setSelectedProject] = useState<ProjectItem | null>(null);
  const [selectedCertificate, setSelectedCertificate] = useState<CertificateItem | null>(null);
  const [selectedApp, setSelectedApp] = useState<PublishedApp | null>(null);

  // Initialize native Capacitor features when running as a native Android app
  useEffect(() => {
    CapacitorService.initNativeFeatures();
  }, []);

  // Native Android back button routing
  useEffect(() => {
    const unregister = CapacitorService.registerBackButtonHandler(() => {
      if (selectedProject || selectedCertificate || selectedApp || isConnectOpen || isCvOpen) {
        return false;
      }
      if (activeSection !== 'home') {
        handleNavigate('home');
        return true;
      }
      return false;
    });

    return () => unregister();
  }, [activeSection, selectedProject, selectedCertificate, selectedApp, isConnectOpen, isCvOpen]);

  // Scroll spy to highlight active section in navigation
  useEffect(() => {
    const handleScroll = () => {
      const sections = [
        'home',
        'projects',
        'skills',
        'capabilities',
        'certifications',
        'about',
        'experience',
        'contact',
        'app-download',
      ];
      const scrollPos = window.scrollY + 140;

      for (let i = sections.length - 1; i >= 0; i--) {
        const el = document.getElementById(sections[i]);
        if (el && el.offsetTop <= scrollPos) {
          setActiveSection(sections[i]);
          break;
        }
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleNavigate = (sectionId: string) => {
    if (sectionId === 'contact') {
      setIsConnectOpen(true);
      return;
    }

    setActiveSection(sectionId);
    const element = document.getElementById(sectionId);
    if (element) {
      const headerOffset = 64;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth',
      });
    }
  };

  const scrollToAppDownload = () => {
    handleNavigate('app-download');
  };

  return (
    <div className="min-h-screen w-full bg-white text-[#0f172a] flex flex-col selection:bg-[#1d4ed8] selection:text-white">
      {/* Full Responsive Application Viewport */}
      <main className="w-full bg-white relative overflow-x-hidden flex-1 flex flex-col">
        {/* Responsive Website Navigation Header */}
        <Navigation
          activeSection={activeSection}
          onNavigate={handleNavigate}
          onOpenConnect={() => setIsConnectOpen(true)}
        />

        {/* 01/ Hero Section */}
        <Hero
          onViewProjects={() => handleNavigate('projects')}
          onDownloadCv={() => setIsCvOpen(true)}
          onOpenConnect={() => setIsConnectOpen(true)}
          onDownloadApp={scrollToAppDownload}
          profileData={firebaseData.profile}
          socials={firebaseData.socials}
        />

        {/* 02/ Projects Section */}
        <Projects
          onSelectProject={(proj) => setSelectedProject(proj)}
          onSelectApp={(app) => setSelectedApp(app)}
          projects={firebaseData.projects}
          apps={firebaseData.apps}
        />

        {/* 03/ Skills & 04/ Capabilities Sections */}
        <SkillsAndCapabilities
          onOpenProjects={() => handleNavigate('projects')}
          onOpenCerts={() => handleNavigate('certifications')}
          skills={firebaseData.skills}
          capabilities={firebaseData.capabilities}
        />

        {/* 05/ Certifications Section */}
        <Certifications
          onViewCertificate={(cert) => setSelectedCertificate(cert)}
          certificates={firebaseData.certificates}
        />

        {/* 06/ About Me Section */}
        <AboutSection
          onOpenConnect={() => setIsConnectOpen(true)}
          onOpenCv={() => setIsCvOpen(true)}
          profileData={firebaseData.profile}
        />

        {/* 07/ Journey Section */}
        <Journey
          onOpenCv={() => setIsCvOpen(true)}
        />

        {/* 08/ App Download Section (Get the JM/CZ App) */}
        <AppDownloadSection
          onOpenDetails={(app) => setSelectedApp(app || null)}
          apps={firebaseData.apps}
        />

        {/* 09/ Contact, Terminal & Dev Bot Footer */}
        <FooterAndTerminal
          onOpenContact={() => setIsConnectOpen(true)}
          onDownloadApp={scrollToAppDownload}
          profileData={firebaseData.profile}
          socials={firebaseData.socials}
        />
      </main>

      {/* PWA Offline Indicator */}
      <OfflineIndicator />

      {/* Modals */}
      <AppDetailsModal
        app={selectedApp}
        onClose={() => setSelectedApp(null)}
      />

      <ContactModal
        isOpen={isConnectOpen}
        onClose={() => setIsConnectOpen(false)}
      />

      <ProjectModal
        project={selectedProject}
        onClose={() => setSelectedProject(null)}
      />

      <CertificateModal
        certificate={selectedCertificate}
        onClose={() => setSelectedCertificate(null)}
      />

      <CvModal
        isOpen={isCvOpen}
        onClose={() => setIsCvOpen(false)}
      />
    </div>
  );
}
