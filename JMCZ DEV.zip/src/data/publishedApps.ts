/**
 * Centralized Published Apps & File Registry
 * The single source of truth for all downloadable applications, APKs, and Source ZIPs.
 * 
 * Adding or updating an app here automatically updates:
 * 1. App Download Section & Cards
 * 2. Projects Section (if showInProjects: true)
 * 3. App Details Modal / Page
 * 4. Search index & Filter chips
 * 5. Download buttons with verified file paths
 */

export interface AppFile {
  type: 'APK' | 'ZIP' | 'AAB' | 'PDF' | 'FILE';
  name: string;
  path: string;
  exists: boolean;
  size?: string; // Only populated when actual file exists on disk
  label?: string;
}

export interface PublishedApp {
  id: string;
  name: string;
  version: string;
  description: string;
  fullDescription?: string;
  category: string;
  platform: 'Android' | 'Web' | 'Desktop' | 'Multi-platform' | string;
  fileType: string;
  files: AppFile[];
  features?: string[];
  technologies?: string[];
  github?: string;
  liveDemo?: string;
  screenshots?: string[];
  status: 'available' | 'coming-soon' | 'deprecated' | 'unavailable';
  releaseDate?: string;
  showInProjects?: boolean;
  showInDownloads?: boolean;
}

/**
 * Standard automatic label detector based on file extension/type
 */
export const getDownloadButtonLabel = (fileType: string): string => {
  const upper = (fileType || '').toUpperCase();
  if (upper === 'APK') return 'DOWNLOAD APK ↓';
  if (upper === 'ZIP') return 'DOWNLOAD SOURCE ZIP ↓';
  if (upper === 'AAB') return 'DOWNLOAD AAB ↓';
  if (upper === 'PDF') return 'DOWNLOAD PDF ↓';
  return 'DOWNLOAD FILE ↓';
};

/**
 * Detect file type and default platform from filename
 */
export const detectFileType = (filename: string): { type: AppFile['type']; platform: string } => {
  const lower = (filename || '').toLowerCase();
  if (lower.endsWith('.apk')) {
    return { type: 'APK', platform: 'Android' };
  }
  if (lower.endsWith('.aab')) {
    return { type: 'AAB', platform: 'Android' };
  }
  if (lower.endsWith('.zip')) {
    return { type: 'ZIP', platform: 'Multi-platform' };
  }
  if (lower.endsWith('.pdf')) {
    return { type: 'PDF', platform: 'Document' };
  }
  return { type: 'FILE', platform: 'Multi-platform' };
};

/**
 * Published applications dataset
 */
export const publishedAppsData: PublishedApp[] = [
  {
    id: 'jm-cz-portfolio',
    name: 'JM/CZ Portfolio',
    version: '1.0.0',
    description: 'Get the JM/CZ portfolio experience on Android.',
    fullDescription: 'Official standalone Android application for the JM/CZ portfolio. Includes native Android hardware back button integration, offline catalog cache, system sharing, and direct project inquiry dispatch.',
    category: 'Android App / Portfolio',
    platform: 'Android',
    fileType: 'APK',
    files: [
      {
        type: 'APK',
        name: 'JM-CZ-Portfolio.apk',
        path: '/downloads/JM-CZ-Portfolio.apk',
        exists: false, // Updated to true automatically once file is placed in /public/downloads/
        label: 'DOWNLOAD FOR ANDROID ↓'
      }
    ],
    features: [
      'Native Android experience with offline capability',
      'System back-button handling & native dialogs',
      'Native sharing for project architecture and specs',
      'Direct contact dispatch and inquiry brief generation'
    ],
    technologies: ['Android', 'Capacitor', 'React', 'TypeScript', 'Tailwind CSS'],
    github: 'https://github.com/jmmadhusudhuoncz',
    liveDemo: '',
    screenshots: [],
    status: 'coming-soon',
    releaseDate: '2026',
    showInProjects: false,
    showInDownloads: true
  },
  {
    id: 'artificial-quiz-master',
    name: 'Artificial Quiz Master',
    version: '1.0.0',
    description: 'AI-powered interactive quiz master with dynamic question generation, real-time leaderboard, and multilingual support.',
    fullDescription: 'Artificial Quiz Master is an intelligent quiz platform and game engine developed with React, TypeScript, and Express. Features responsive quiz interfaces, real-time leaderboard rankings, audio feedback, customizable themes, and multilingual localization.',
    category: 'Interactive Web App / AI',
    platform: 'Multi-platform',
    fileType: 'ZIP',
    files: [
      {
        type: 'ZIP',
        name: 'Artificial-Quiz-Master.zip',
        path: '/downloads/Artificial-Quiz-Master.zip',
        exists: true,
        size: '1.1 KB',
        label: 'DOWNLOAD SOURCE ZIP ↓'
      }
    ],
    features: [
      'Interactive quiz engine with real-time scoring and analytics',
      'Dynamic leaderboard with global and local ranking tracking',
      'Web Audio sound effects and mobile haptic feedback integration',
      'Multilingual language toggle and dark/light theme persistence',
      'Full TypeScript codebase with Express server and Vite tooling'
    ],
    technologies: ['React', 'TypeScript', 'Vite', 'Tailwind CSS', 'Node.js', 'Express'],
    github: 'https://github.com/jmmadhusudhuoncz',
    liveDemo: '',
    screenshots: [],
    status: 'available',
    releaseDate: '2026',
    showInProjects: true,
    showInDownloads: true
  },
  {
    id: 'yaju-unleash-inner',
    name: 'YAJU Unleash Inner All File',
    version: '1.0.0',
    description: 'At YAJU, we believe in empowering you to unlock your full potential and crush your goals every day. Whether you’re striving for personal success in fitness, sport, or overall health, we understand the journey is challenging, demanding everything from your training, nutrition, and rest. We’re here to support you every step of the way. With our premium supplements, designed to elevate your performance, we help you unleash your inner beast and push past limits to reach new heights.',
    fullDescription: 'At YAJU, we believe in empowering you to unlock your full potential and crush your goals every day. Whether you’re striving for personal success in fitness, sport, or overall health, we understand the journey is challenging, demanding everything from your training, nutrition, and rest. We’re here to support you every step of the way. With our premium supplements, designed to elevate your performance, we help you unleash your inner beast and push past limits to reach new heights.',
    category: 'Health',
    platform: 'Multi-platform',
    fileType: 'ZIP',
    files: [
      {
        type: 'ZIP',
        name: 'YAJU-Unleash-Inner-All-File.zip',
        path: '/downloads/YAJU-Unleash-Inner-All-File.zip',
        exists: true,
        size: '965 B',
        label: 'DOWNLOAD SOURCE ZIP ↓'
      }
    ],
    features: [
      'Manga-inspired performance & cellular recovery supplement formulation',
      'Over 9000 power estimator & circadian bio-timing protocol',
      'Interactive catalog with 3rd-party ISO 17025 lab COA inspection',
      'Dynamic protocol cart with discount engine and cold-chain dispatch'
    ],
    technologies: ['React', 'TypeScript', 'Tailwind CSS', 'Vite', 'Lucide Icons', 'Motion'],
    github: 'https://github.com/jmmadhusudhuoncz',
    liveDemo: '',
    screenshots: [],
    status: 'available',
    releaseDate: '2026',
    showInProjects: true,
    showInDownloads: true
  },
  {
    id: 'side-a-music',
    name: 'SIDE A Music',
    version: '1.0.0',
    description: 'A premium music discovery and generative audio experience featuring curated artists, vinyl-inspired visuals, cassette Side A/B, interactive waveform playback, Web Audio synthesis, mini-player, music library, radio stations, search, profiles, and notifications.',
    fullDescription: 'A premium music discovery and generative audio experience featuring curated artists, vinyl-inspired visuals, cassette Side A/B, interactive waveform playback, Web Audio synthesis, mini-player, music library, radio stations, search, profiles, and notifications.',
    category: 'Music & Audio',
    platform: 'Multi-platform',
    fileType: 'ZIP',
    files: [
      {
        type: 'ZIP',
        name: 'SIDE-A-Music.zip',
        path: '/downloads/SIDE-A-Music.zip',
        exists: true,
        size: '871 B',
        label: 'DOWNLOAD SOURCE ZIP ↓'
      }
    ],
    features: [
      'Web Audio synthesizer engine with real-time waveform and generative chords',
      'Cassette Tape Side A & B flip interaction with curated indie tracks',
      'Docked interactive mini-player with persistent state controls',
      'Curated indie radio stations, search indexing, and music library'
    ],
    technologies: ['React', 'TypeScript', 'Web Audio API', 'Tailwind CSS', 'Vite', 'Motion'],
    github: 'https://github.com/jmmadhusudhuoncz',
    liveDemo: '',
    screenshots: [],
    status: 'available',
    releaseDate: '2026',
    showInProjects: true,
    showInDownloads: true
  }
];

export const getPublishedApp = (id: string): PublishedApp | undefined => {
  return publishedAppsData.find((a) => a.id === id);
};
