/**
 * Technical Skills data for JM Madhu Sudhuon CZ
 * Categorized across 5 core focus areas with qualitative status indicators.
 * Strictly no fabricated percentage bars or fake metrics.
 */

export const skillsData = [
  {
    category: "PROGRAMMING",
    skills: [
      { name: "HTML", status: "WORKING WITH" },
      { name: "CSS", status: "WORKING WITH" },
      { name: "JavaScript", status: "WORKING WITH" },
      { name: "Python", status: "WORKING WITH" },
      { name: "C++", status: "LEARNING" }
    ]
  },
  {
    category: "AI / ML",
    skills: [
      { name: "Machine Learning", status: "LEARNING" },
      { name: "AI Fundamentals", status: "LEARNING" },
      { name: "Data / Model Experimentation", status: "EXPLORING" }
    ]
  },
  {
    category: "DEVELOPMENT",
    skills: [
      { name: "Android", status: "WORKING WITH" },
      { name: "Firebase", status: "WORKING WITH" },
      { name: "UI/UX", status: "WORKING WITH" },
      { name: "Web Development", status: "WORKING WITH" }
    ]
  },
  {
    category: "3D / ENGINEERING",
    skills: [
      { name: "3D Development", status: "EXPLORING" },
      { name: "Robotics", status: "EXPLORING" },
      { name: "Space Engineering", status: "EXPLORING" },
      { name: "Simulation", status: "EXPLORING" },
      { name: "CAD", status: "EXPLORING" }
    ]
  },
  {
    category: "TOOLS",
    skills: [
      { name: "Git", status: "WORKING WITH" },
      { name: "GitHub", status: "WORKING WITH" },
      { name: "VS Code", status: "WORKING WITH" },
      { name: "Android Studio", status: "WORKING WITH" },
      { name: "Blender", status: "LEARNING" },
      { name: "SolidWorks", status: "EXPLORING" },
      { name: "Figma", status: "WORKING WITH" }
    ]
  }
];

export const allTechnologies = [
  "HTML",
  "CSS",
  "JavaScript",
  "Python",
  "C++",
  "Machine Learning",
  "Android",
  "Firebase",
  "UI/UX",
  "3D Development",
  "Robotics",
  "Space Engineering",
  "Simulation",
  "CAD",
  "Git",
  "GitHub",
  "VS Code",
  "Android Studio",
  "Blender",
  "SolidWorks",
  "Figma"
];
