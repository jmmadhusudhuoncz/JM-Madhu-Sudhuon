/**
 * Professional Journey data for JM Madhu Sudhuon CZ
 * Focuses on authentic developmental progression across:
 * - Learning
 * - Certifications
 * - Projects
 * - Experiments
 * - Product Development
 * - Engineering Exploration
 */

export const journeyData = [
  {
    id: "journey-learning-core",
    phase: "LEARNING",
    title: "Foundations in Programming & Computational Logic",
    focus: "C++, Python, Web Standards (HTML, CSS, JavaScript)",
    description: "Deep dive into algorithmic thinking, structured programming paradigms, data structures, and computer science fundamentals. Built a disciplined base across both compiled and scripting languages.",
    tags: ["C++", "Python", "Algorithms", "Core CS"],
    category: "Learning"
  },
  {
    id: "journey-certifications-verified",
    phase: "CERTIFICATIONS",
    title: "Accredited Technical Certification Milestones",
    focus: "Google & FABEVY Credential Programs",
    description: "Completed rigorous coursework and technical evaluations in Machine Learning with Google, alongside comprehensive certificates in C++, Python, JavaScript, CSS, and HTML with FABEVY.",
    tags: ["Google ML", "FABEVY C++", "Python", "Web Standards"],
    category: "Certifications"
  },
  {
    id: "journey-projects-development",
    phase: "PROJECTS",
    title: "Digital Products & Analytical Systems Architecture",
    focus: "Score X Pro, RealityLens, Brothers Studios, Learning For Education",
    description: "Conceptualized and actively engineering software applications addressing specific problem spaces in sports analytics, computer vision, digital creative portals, and STEM learning.",
    tags: ["Product Concept", "System Architecture", "UI/UX", "Code"],
    category: "Projects"
  },
  {
    id: "journey-experiments-future",
    phase: "EXPERIMENTS",
    title: "Scientific Computing & Symbolic Equation Engines",
    focus: "Universal Formula Engine & Scientific Math",
    description: "Investigating computational mathematics, symbolic equation solving, AST expression parsing, and unit consistency models.",
    tags: ["Computational Math", "AST Parsing", "Precision"],
    category: "Experiments"
  },
  {
    id: "journey-product-development",
    phase: "PRODUCT DEVELOPMENT",
    title: "Modular App Engineering & End-to-End Implementation",
    focus: "Web Apps, Android Applications, API Pipelines",
    description: "Translating verified functional requirements into deployable cross-platform software with responsive mobile-first UI and secure backend integration.",
    tags: ["Mobile First", "Android", "PWA", "API Architecture"],
    category: "Product Development"
  },
  {
    id: "journey-engineering-exploration",
    phase: "ENGINEERING EXPLORATION",
    title: "Aerospace Trajectory & 3D Simulation Concepts",
    focus: "Space Engineering Projects & Orbital Dynamics",
    description: "Studying orbital mechanics, delta-v computations, n-body gravitational models, and 3D simulation concepts to explore the intersection of physics and code.",
    tags: ["Orbital Mechanics", "Simulation", "CAD", "Aerospace"],
    category: "Engineering Exploration"
  }
];
