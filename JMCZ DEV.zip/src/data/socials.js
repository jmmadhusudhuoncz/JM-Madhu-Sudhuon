/**
 * Social Links & Contact Channels for JM Madhu Sudhuon CZ
 * Source of truth for all verified personal profiles and channels.
 * 
 * Supplied links:
 * - GitHub: https://github.com/jmmadhusudhuoncz
 * - Agency: https://bmdeveloperagency.netlify.app/
 * - TikTok: https://www.tiktok.com/@jmmadhusudhuoncz
 * - Facebook: https://www.facebook.com/share/1D8RYTrnk4/
 * - Instagram: https://www.instagram.com/jm_madhusudhuon_cz
 * - WhatsApp: https://wa.me/8801866075871
 * - X / Twitter: https://x.com/jmmadhusudhuonc
 * - Email: mailto:jmmadhusudhuoncz@gmail.com
 */

export const socialsData = [
  {
    id: 'github',
    label: 'GitHub',
    username: 'jmmadhusudhuoncz',
    url: 'https://github.com/jmmadhusudhuoncz',
    isConfigured: true,
    placeholder: 'https://github.com/jmmadhusudhuoncz',
    description: 'Code repositories & open source projects'
  },
  {
    id: 'agency',
    label: 'BM Developer Agency',
    username: 'BM Developer Agency',
    url: 'https://bmdeveloperagency.netlify.app/',
    isConfigured: true,
    placeholder: 'https://bmdeveloperagency.netlify.app/',
    description: 'Digital Development & Technology'
  },
  {
    id: 'whatsapp',
    label: 'WhatsApp',
    username: '+880 1866-075871',
    url: 'https://wa.me/8801866075871',
    isConfigured: true,
    placeholder: 'https://wa.me/8801866075871',
    description: 'Direct WhatsApp communication'
  },
  {
    id: 'instagram',
    label: 'Instagram',
    username: '@jm_madhusudhuon_cz',
    url: 'https://www.instagram.com/jm_madhusudhuon_cz',
    isConfigured: true,
    placeholder: 'https://www.instagram.com/jm_madhusudhuon_cz',
    description: 'Updates & behind the scenes'
  },
  {
    id: 'facebook',
    label: 'Facebook',
    username: 'JM Madhu Sudhuon CZ',
    url: 'https://www.facebook.com/share/1D8RYTrnk4/',
    isConfigured: true,
    placeholder: 'https://www.facebook.com/share/1D8RYTrnk4/',
    description: 'Social networking & updates'
  },
  {
    id: 'tiktok',
    label: 'TikTok',
    username: '@jmmadhusudhuoncz',
    url: 'https://www.tiktok.com/@jmmadhusudhuoncz',
    isConfigured: true,
    placeholder: 'https://www.tiktok.com/@jmmadhusudhuoncz',
    description: 'Tech shorts & updates'
  },
  {
    id: 'twitter',
    label: 'X / Twitter',
    username: '@jmmadhusudhuonc',
    url: 'https://x.com/jmmadhusudhuonc',
    isConfigured: true,
    placeholder: 'https://x.com/jmmadhusudhuonc',
    description: 'Tech thoughts & project updates'
  },
  {
    id: 'email',
    label: 'Email',
    username: 'jmmadhusudhuoncz@gmail.com',
    url: 'mailto:jmmadhusudhuoncz@gmail.com',
    isConfigured: true,
    placeholder: 'jmmadhusudhuoncz@gmail.com',
    description: 'Direct inquiries & project requests'
  }
];

// Helper to look up by ID
export const getSocial = (id) => socialsData.find((s) => s.id === id);
