/**
 * Personal profile data for JM Madhu Sudhuon CZ
 * Source of truth for personal brand and portfolio identity.
 */

export const profile = {
  name: "JM MADHU SUDHUON CZ",
  nameLine1: "JM MADHU",
  nameLine2: "SUDHUON CZ",
  shortName: "JM Madhu Sudhuon CZ",
  brand: "JM/CZ",
  brandFull: "JM/CZ — PORTFOLIO",
  smallLabel: "JM/CZ — PERSONAL PORTFOLIO",
  role: "DEVELOPER • PROGRAMMER • CREATOR",
  heroCaption: "Clean logic, continuous learning, modern technologies",
  description: "I build software, explore AI/ML, analyze projects and turn ideas into real digital products.",
  cvPath: "/assets/JM-Madhu-Sudhuon-CZ-CV.pdf",
  technicalStatus: "BUILD • LEARN • EXPERIMENT",
  kicker: "DEVELOPER • PROGRAMMER • CREATOR",
  identityTitles: [
    "Developer",
    "Programmer",
    "AI/ML Learner",
    "Project Analyst",
    "Team Management",
    "Idea Expert",
    "Creator"
  ],
  aboutHeadline: "ABOUT ME",
  aboutText: `I'm JM Madhu Sudhuon CZ.

I'm a developer and technology-focused creator interested in programming, software development, AI/ML, Android, engineering and digital product development.

I enjoy turning ideas into practical digital projects and continuously exploring new technologies.`,
  whoAmI: "I am a dedicated software developer, programmer, and creator focused on crafting dependable web and mobile applications, mastering computational algorithms, and translating complex concepts into structured digital products.",
  focus: "Full-stack software engineering, AI/ML experimentation, mobile development, computational physics, and analytical system architecture.",
  technology: "HTML, CSS, JavaScript, Python, C++, Android, Firebase, UI/UX Architecture, Git, Machine Learning fundamentals, and 3D Simulation.",
  currentStatus: "Building the next generation of software products, deepening machine learning applications, and available for engineering collaborations.",
  email: "jmmadhusudhuoncz@gmail.com",
  agencyUrl: "https://bmdeveloperagency.netlify.app/",
  agencyName: "BM Developer Agency",
  location: "Available Globally / Remote",
  education: "Continuous Self-Directed Learning & Technical Certifications (Google, FABEVY)",
  interests: [
    "Software Development & Architecture",
    "Artificial Intelligence & Machine Learning",
    "Android Application Ecosystem",
    "Computational Systems & Scientific Engines",
    "Space & Aerospace Engineering Concepts"
  ],
  status: "BUILD • LEARN • EXPERIMENT",
  focusAreas: [
    "Software & Programming",
    "AI / ML Learning",
    "Project Analysis & Planning",
    "Team Coordination",
    "Space & Technical Exploration"
  ],
  copyrightYear: 2026,
  appConfig: {
    appName: "JM/CZ Portfolio",
    displayName: "JM/CZ",
    appId: "com.jmcz.portfolio",
    version: "1.0.0"
  }
};
