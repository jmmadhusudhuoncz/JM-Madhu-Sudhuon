import { publishedAppsData } from './publishedApps';

const primary = publishedAppsData[0] || {
  name: "JM/CZ Portfolio",
  version: "1.0.0",
  platform: "Android",
  description: "Get the JM/CZ portfolio experience on Android.",
  files: [{ path: "/downloads/JM-CZ-Portfolio.apk", exists: false }]
};

export const appConfig = {
  name: primary.name,
  displayName: "JM/CZ",
  platform: primary.platform,
  version: primary.version,
  packageId: "com.jmcz.portfolio",
  apkPath: primary.files?.[0]?.path || "/downloads/JM-CZ-Portfolio.apk",
  downloadEnabled: primary.status === 'available' && primary.files?.[0]?.exists === true,
  releaseDate: primary.releaseDate || "2026",
  description: primary.description,
  minAndroidVersion: "Android 8.0 (API 26)+",
  features: primary.features || [
    "Native Android experience with offline capability",
    "System back-button handling & native dialogs",
    "Native sharing for project architecture and specs",
    "Direct contact dispatch and inquiry brief generation"
  ]
};
