/**
 * Projects data for JM Madhu Sudhuon CZ
 * Detailed project analysis structure showcasing problem-solving and architectural planning:
 * - PROBLEM
 * - SOLUTION
 * - TECHNOLOGY
 * - MY ROLE
 * - STATUS (Concept | In Development | Completed | Experimental)
 * - FEATURES
 * - LEARNING
 * - LINKS
 */

export const projectsData = [
  {
    id: "reality-lens",
    number: "01",
    title: "RealityLens",
    subtitle: "Augmented Reality & Visual Intelligence Utility",
    status: "In Development",
    category: "AI / AR & Vision",
    role: "Project Lead, Architecture & Core Logic",
    problem: "Real-world visual data and complex physical objects often lack immediate contextual digital overlays, making spatial learning and technical inspection fragmented across separate references.",
    solution: "Developing a lightweight spatial perception interface that detects objects, interprets spatial parameters, and presents contextual insights directly over real-time camera views.",
    technology: ["Python", "Computer Vision", "AI/ML", "Android / Web"],
    features: [
      "Real-time visual object and environmental edge recognition",
      "Contextual informational HUD overlay with technical telemetry",
      "Low-latency on-device machine learning inference pipeline",
      "Intuitive spatial interaction and annotation toolkit"
    ],
    learning: "Understanding latency constraints of mobile computer vision models and balancing model size against frame rate accuracy.",
    image: "/src/assets/images/project_taskflow_1790611825562.jpg",
    links: {
      demo: "",
      repo: ""
    }
  },
  {
    id: "brothers-studios",
    number: "02",
    title: "Brothers Studios",
    subtitle: "Creative Media & Digital Production Portal",
    status: "In Development",
    category: "Creative Media & Web",
    role: "Lead Developer & Concept Designer",
    problem: "Independent creative production teams struggle with scattered portfolios, disjointed client deliverables, and lack of unified brand storytelling across diverse creative mediums.",
    solution: "Architecting a high-impact, neo-brutalist digital presence and asset showcase system tailored for creative productions, video storytelling, and collaborative client reviews.",
    technology: ["HTML", "CSS", "JavaScript", "UI/UX Architecture"],
    features: [
      "Modular media showcase with responsive masonry portfolio grid",
      "Project deliverable tracking and client preview workspaces",
      "High-contrast editorial typography and bespoke visual identity",
      "Integrated inquiry pipeline for creative commissions"
    ],
    learning: "Structuring asset-heavy web applications with optimized rendering budgets, avoiding visual clutter while preserving bold creative identity.",
    image: "/src/assets/images/project_analytix_1790611844205.jpg",
    links: {
      demo: "",
      repo: ""
    }
  },
  {
    id: "learning-for-education",
    number: "03",
    title: "Learning For Education",
    subtitle: "Accessible STEM & Technical Knowledge Platform",
    status: "Concept",
    category: "EdTech & Learning",
    role: "Project Analyst & Curriculum Architect",
    problem: "Standard educational platforms often overwhelm students with disjointed theory without structured conceptual maps, interactive problem breakdowns, or visual logic flows.",
    solution: "Designing an intuitive, modular learning system structured around interactive concept trees, practical code simulations, and progressive knowledge milestones for aspiring developers.",
    technology: ["JavaScript", "HTML", "CSS", "Python", "UI/UX"],
    features: [
      "Visual concept dependency graph for programming topics",
      "Interactive code exercises with instant feedback loops",
      "Progress tracking and self-paced milestone checkpoints",
      "Zero-fluff technical explanations designed for clarity"
    ],
    learning: "Analyzing pedagogical workflows to transform complex technical abstractions (e.g. data structures, algorithms) into accessible interactive modules.",
    image: "/src/assets/images/project_shopco_1790611857393.jpg",
    links: {
      demo: "",
      repo: ""
    }
  },
  {
    id: "score-x-pro",
    number: "04",
    title: "Score X Pro",
    subtitle: "Performance Analytics & Sports Metrics Engine",
    status: "In Development",
    category: "Analytics & Software",
    role: "Full-Stack Developer & Data Analyst",
    problem: "Amateur and competitive sports organizers frequently rely on messy spreadsheets and manual calculations to track scores, tournament ladders, and player statistics.",
    solution: "Building a streamlined scoring and statistical analysis web application providing instant tournament brackets, live scoring inputs, and comparative player performance metrics.",
    technology: ["JavaScript", "Python", "Web Development", "Algorithms"],
    features: [
      "Real-time scoreboard management with automated tiebreaker logic",
      "Dynamic bracket generator supporting single and double elimination",
      "Player performance metric tracking and comparative stat sheets",
      "Exportable summary cards and tournament reports"
    ],
    learning: "Implementing deterministic state logic for tournament brackets and optimizing reactive DOM updates during live fast-paced score inputs.",
    image: "/src/assets/images/project_devhub_1790611874765.jpg",
    links: {
      demo: "",
      repo: ""
    }
  },
  {
    id: "universal-formula-engine",
    number: "05",
    title: "Universal Formula Engine",
    subtitle: "Mathematical & Scientific Computation System",
    status: "Experimental",
    category: "Scientific Computing",
    role: "Algorithm Designer & Programmer",
    problem: "Cross-disciplinary engineering and scientific formulas (physics, electrical, mechanics) are siloed across disconnected calculators that do not show derivation steps or unit consistency.",
    solution: "Creating a unified calculation engine capable of parsing symbolic formulas, managing unit dimensional analysis, and visualizing variable relationships interactively.",
    technology: ["Python", "C++", "JavaScript", "Mathematical Modeling"],
    features: [
      "Multi-domain scientific formula solver with dimensional unit validation",
      "Step-by-step intermediate equation evaluation and derivation display",
      "Interactive sensitivity analysis curves for changing parameters",
      "Modular library architecture for adding custom formulas"
    ],
    learning: "Exploring AST (Abstract Syntax Tree) expression parsing and precision arithmetic across floating-point limitations in computing.",
    image: "/src/assets/images/project_taskflow_1790611825562.jpg",
    links: {
      demo: "",
      repo: ""
    }
  },
  {
    id: "space-engineering-projects",
    number: "06",
    title: "Space Engineering Projects",
    subtitle: "Orbital Mechanics & Aerospace Simulation Concepts",
    status: "Concept",
    category: "Aerospace & 3D Simulation",
    role: "Research & Systems Analyst",
    problem: "Understanding orbital dynamics and propulsion parameters requires complex mathematical modeling that is difficult to visualize without custom 3D simulation tools.",
    solution: "Investigating computational physics simulations for trajectory planning, delta-v calculations, and celestial orbit mechanics through interactive digital models.",
    technology: ["Python", "C++", "3D / Digital Projects", "Physics Modeling"],
    features: [
      "Gravitational n-body orbital trajectory simulation models",
      "Delta-v budget calculator for multi-stage propulsion profiles",
      "3D celestial visualizer for orbital transfers and transfer windows",
      "Modular aerospace physics telemetry logging"
    ],
    learning: "Bridging theoretical physics with discrete numerical integration techniques (Runge-Kutta) and optimizing algorithmic performance.",
    image: "/src/assets/images/project_analytix_1790611844205.jpg",
    links: {
      demo: "",
      repo: ""
    }
  }
];
