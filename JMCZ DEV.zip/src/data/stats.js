/**
 * Centralized Stats System for JM Madhu Sudhuon CZ
 * Source of truth for factual portfolio statistics.
 * 
 * RULE: Only factual, verifiable values are used.
 * If a value is unknown, unverified, or not yet provided, set to null.
 * When null, the UI gracefully displays "—" rather than a fake or inflated number.
 */

import { projectsData } from './projects';
import { certificatesData } from './certificates';
import { allTechnologies } from './skills';

// Configurable factual base statistics
// Set to null if you prefer "—" until officially documented.
export const stats = {
  // Real count of documented project initiatives in portfolio
  projects: projectsData ? projectsData.length : null,
  
  // Real accredited certificates (Google & FABEVY)
  certificates: certificatesData ? certificatesData.length : null,
  
  // Real cataloged technologies in active skill set
  technologies: allTechnologies ? allTechnologies.length : null,
  
  // Currently active initiatives in development
  currentProjects: projectsData ? projectsData.filter((p) => p.status === 'In Development' || p.status === 'Experimental').length : null,
  
  // Completed projects (null displays "—" until officially marked complete)
  completedProjects: null,

  // Concept initiatives
  conceptRoadmaps: projectsData ? projectsData.filter((p) => p.status === 'Concept').length : null,
};

/**
 * Format helper for UI rendering: returns formatted string or "—"
 * @param {number | null | undefined} val
 * @returns {string}
 */
export const formatStatValue = (val) => {
  if (val === null || val === undefined) {
    return '—';
  }
  return val.toString();
};
