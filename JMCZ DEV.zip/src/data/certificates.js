/**
 * Certifications data for JM Madhu Sudhuon CZ
 * Source of truth for all verified and earned course credentials from Google and FABEVY.
 * 
 * IMPORTANT: No fake IDs, fake dates, or fake verification links are fabricated.
 * Fill in `date`, `credentialId`, `image`, `pdf`, and `verificationUrl` with your real documents as available.
 */

export const certificatesData = [
  {
    id: "cert-google-ml",
    title: "Machine Learning",
    issuer: "Google",
    category: "Machine Learning / AI",
    date: "",
    credentialId: "",
    image: "",
    pdf: "",
    verificationUrl: "",
    description: "Foundational and applied Machine Learning principles, algorithms, model experimentation, and AI paradigms."
  },
  {
    id: "cert-fabevy-cpp",
    title: "C++",
    issuer: "FABEVY",
    category: "Programming / Systems",
    date: "",
    credentialId: "",
    image: "",
    pdf: "",
    verificationUrl: "",
    description: "Core syntax, data types, object-oriented concepts, memory models, and algorithmic problem-solving in C++."
  },
  {
    id: "cert-fabevy-python",
    title: "Python",
    issuer: "FABEVY",
    category: "Programming / Scripting",
    date: "",
    credentialId: "",
    image: "",
    pdf: "",
    verificationUrl: "",
    description: "Python language fundamentals, data structures, automation logic, modular programming, and data manipulation."
  },
  {
    id: "cert-fabevy-javascript",
    title: "JavaScript",
    issuer: "FABEVY",
    category: "Web Development",
    date: "",
    credentialId: "",
    image: "",
    pdf: "",
    verificationUrl: "",
    description: "Dynamic client-side programming, asynchronous operations, event handling, DOM manipulation, and modern ES6+ standards."
  },
  {
    id: "cert-fabevy-css",
    title: "CSS",
    issuer: "FABEVY",
    category: "Web Styling & UI",
    date: "",
    credentialId: "",
    image: "",
    pdf: "",
    verificationUrl: "",
    description: "Responsive layouts, Flexbox, Grid systems, typography hierarchy, visual aesthetics, and modern styling architectures."
  },
  {
    id: "cert-fabevy-html",
    title: "HTML",
    issuer: "FABEVY",
    category: "Web Standards & Markup",
    date: "",
    credentialId: "",
    image: "",
    pdf: "",
    verificationUrl: "",
    description: "Semantic document structuring, accessibility conventions, modern HTML5 elements, and web standard best practices."
  }
];
