/**
 * Professional Capabilities data for JM Madhu Sudhuon CZ
 * Focus areas presented honestly as analytical and organizational strengths.
 */

export const capabilitiesData = [
  {
    id: "project-analyst",
    code: "CAP_01",
    title: "PROJECT ANALYST",
    subtitle: "Analytical Systems & Requirement Architecture",
    description: "Systematic breakdown of project specifications, architectural dependencies, and delivery risk vectors before writing code.",
    items: [
      "Project analysis",
      "Requirement analysis",
      "Problem identification",
      "Project planning"
    ]
  },
  {
    id: "team-management",
    code: "CAP_02",
    title: "TEAM MANAGEMENT",
    subtitle: "Operational Alignment & Execution Discipline",
    description: "Structuring collaborative momentum, sprint alignment, milestone distribution, and transparent communication across contributors.",
    items: [
      "Team coordination",
      "Task organization",
      "Collaboration",
      "Project workflow"
    ]
  },
  {
    id: "idea-expert",
    code: "CAP_03",
    title: "IDEA EXPERT",
    subtitle: "Concept Formulation & Feature Roadmapping",
    description: "Transforming abstract visions and raw challenges into structured technical roadmaps, viable prototypes, and tangible digital solutions.",
    items: [
      "Idea generation",
      "Product concepts",
      "Problem solving",
      "Feature planning",
      "Turning ideas into project concepts"
    ]
  },
  {
    id: "product-development",
    code: "CAP_04",
    title: "PRODUCT DEVELOPMENT",
    subtitle: "End-to-End Execution & Prototyping",
    description: "Translating verified functional requirements into functional, maintainable mobile and web applications with modular architecture.",
    items: [
      "Full-cycle development",
      "UI/UX prototyping",
      "Interactive interfaces",
      "Production deployment",
      "Quality assurance & testing"
    ]
  }
];
