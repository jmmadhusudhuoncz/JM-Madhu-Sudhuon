import React from 'react';
import { ArrowUpRight, Compass, GraduationCap, Code, Rocket, FlaskConical } from 'lucide-react';
import { journeyData } from '../data/journey';
import { ExperienceIsometricCluster } from './IsometricGraphics';

interface JourneyProps {
  onOpenCv: () => void;
}

export const Journey: React.FC<JourneyProps> = ({ onOpenCv }) => {
  const getIcon = (type: string) => {
    switch (type) {
      case 'Learning':
        return <GraduationCap className="w-3.5 h-3.5 text-white" />;
      case 'Certifications':
        return <Code className="w-3.5 h-3.5 text-black" />;
      case 'Projects':
        return <Rocket className="w-3.5 h-3.5 text-white" />;
      case 'Experiments':
        return <FlaskConical className="w-3.5 h-3.5 text-black" />;
      default:
        return <Compass className="w-3.5 h-3.5 text-white" />;
    }
  };

  const getBadgeStyle = (phase: string) => {
    switch (phase) {
      case 'LEARNING':
        return 'bg-[#1d4ed8] text-white';
      case 'CERTIFICATIONS':
        return 'bg-[#d4fc35] text-black';
      case 'PROJECTS':
        return 'bg-black text-white';
      case 'EXPERIMENTS':
        return 'bg-purple-600 text-white';
      default:
        return 'bg-slate-800 text-white';
    }
  };

  return (
    <section id="experience" className="w-full bg-white border-b-2 border-black">
      <div className="grid grid-cols-1 lg:grid-cols-12 divide-y-2 lg:divide-y-0 lg:divide-x-2 divide-black">
        {/* Left Column: Timeline */}
        <div className="lg:col-span-8 p-6 sm:p-8 md:p-10 flex flex-col justify-between bg-white relative">
          <div>
            {/* Header with Blue Tab */}
            <div className="flex items-center gap-3 mb-6">
              <div className="w-2 h-7 bg-[#1d4ed8]" />
              <h2 className="text-xl sm:text-2xl font-mono font-extrabold tracking-tight text-black">
                06/ MY JOURNEY &amp; PROGRESSION
              </h2>
            </div>

            <p className="font-mono text-xs text-slate-700 max-w-xl mb-8 leading-relaxed">
              Authentic progression across foundational learning, accredited credentials, digital initiatives, and ongoing scientific experiments.
            </p>

            {/* Vertical timeline */}
            <div className="relative pl-6 sm:pl-8 space-y-8 before:absolute before:left-2 before:top-2 before:bottom-2 before:w-0.5 before:bg-black">
              {journeyData.map((item, idx) => (
                <div key={item.id} className="relative group">
                  {/* Square timeline node */}
                  <div
                    className={`absolute -left-[27px] sm:-left-[35px] top-1 w-4 h-4 border-2 border-black flex items-center justify-center ${
                      idx === 0 ? 'bg-[#d4fc35]' : 'bg-white'
                    }`}
                  >
                    <div className="w-1.5 h-1.5 bg-black" />
                  </div>

                  {/* Phase badge */}
                  <div className="flex items-center gap-2 mb-1.5">
                    <span
                      className={`px-2 py-0.5 font-mono text-[9px] font-black border border-black uppercase tracking-wider ${getBadgeStyle(
                        item.phase
                      )}`}
                    >
                      {item.phase}
                    </span>
                    <span className="font-mono text-[11px] font-bold text-slate-500">
                      {item.focus}
                    </span>
                  </div>

                  {/* Title */}
                  <h3 className="font-mono text-sm sm:text-base font-extrabold text-black tracking-tight uppercase mb-2">
                    {item.title}
                  </h3>

                  {/* Description */}
                  <p className="font-mono text-xs text-slate-600 mb-3 max-w-2xl leading-relaxed">
                    {item.description}
                  </p>

                  {/* Tags */}
                  <div className="flex flex-wrap items-center gap-1.5">
                    {item.tags.map((t) => (
                      <span
                        key={t}
                        className="px-2 py-0.5 border border-slate-300 bg-slate-50 text-[10px] font-mono text-slate-800"
                      >
                        {t}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Bottom Action */}
          <div className="pt-8 mt-6 border-t border-slate-200 flex flex-wrap items-center justify-between gap-4">
            <span className="font-mono text-xs text-slate-500">
              Future professional roles and engineering milestones can be appended to this record.
            </span>

            <button
              onClick={onOpenCv}
              className="inline-flex items-center gap-2 px-4 py-2 text-xs font-mono font-bold text-black border-2 border-black hover:bg-[#d4fc35] transition-colors cursor-pointer select-none group shadow-[2px_2px_0px_#000000]"
            >
              <span>VIEW FULL PROFILE CV</span>
              <ArrowUpRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </button>
          </div>
        </div>

        {/* Right Column: Isometric Graphic + Manifesto */}
        <div className="lg:col-span-4 p-6 sm:p-8 flex flex-col justify-between bg-[#fafbfc]">
          <div>
            <div className="flex items-center justify-center py-6">
              <ExperienceIsometricCluster />
            </div>

            <div className="p-4 bg-white border-2 border-black space-y-3 font-mono text-xs">
              <div className="flex items-center gap-2 border-b border-black pb-2">
                <span className="w-2 h-2 bg-[#1d4ed8]" />
                <h4 className="font-extrabold text-black uppercase">CORE MINDSET</h4>
              </div>
              <p className="text-slate-700 leading-relaxed">
                "Disciplined execution begins with clear problem framing. Whether writing code in C++ or structuring an AI pipeline, the goal is always robust, maintainable value."
              </p>
              <div className="pt-2 text-[10px] text-slate-500 font-bold">
                — JM MADHU SUDHUON CZ
              </div>
            </div>
          </div>

          <div className="pt-6 border-t border-slate-200">
            <div className="font-mono text-[11px] text-slate-600">
              <strong className="text-black">Open to:</strong> Software collaborations, research projects, technical initiatives, and analytical advisory.
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
