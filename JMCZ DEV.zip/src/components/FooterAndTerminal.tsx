import React, { useState } from 'react';
import { ChevronRight, Github, Twitter, Mail, Send, Terminal as TerminalIcon, Instagram, Facebook, ArrowUpRight, Smartphone, Download } from 'lucide-react';
import { FooterIsometricCluster } from './IsometricGraphics';
import { AgencyCard } from './AgencyCard';
import { profile } from '../data/profile';
import { socialsData } from '../data/socials';
import { appConfig } from '../data/app';

interface FooterAndTerminalProps {
  onOpenContact: () => void;
  onDownloadApp?: () => void;
  profileData?: typeof profile;
  socials?: typeof socialsData;
}

export const FooterAndTerminal: React.FC<FooterAndTerminalProps> = ({
  onOpenContact,
  onDownloadApp,
  profileData = profile,
  socials = socialsData,
}) => {
  // Terminal state
  const [terminalHistory, setTerminalHistory] = useState<Array<{ cmd: string; output: string[] }>>([]);
  const [currentInput, setCurrentInput] = useState('');

  // Dev Bot state
  const [chatMessages, setChatMessages] = useState<Array<{ sender: 'bot' | 'user'; text: string }>>([
    { sender: 'bot', text: `Hi! I'm the JM/CZ Assistant. How can I help you explore Madhu's projects or skills today?` },
  ]);
  const [chatInput, setChatInput] = useState('');
  const [isBotTyping, setIsBotTyping] = useState(false);
  const [socialNotice, setSocialNotice] = useState<string | null>(null);

  // Terminal command handler
  const handleTerminalSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cmd = currentInput.trim().toLowerCase();
    if (!cmd) return;

    let output: string[] = [];
    switch (cmd) {
      case 'help':
        output = [
          'Available commands:',
          '  whoami     - Identity and profile info',
          '  skills     - Technical programming and AI stack',
          '  focus      - Core disciplines and focus areas',
          '  status     - Current availability and active build',
          '  projects   - Active software and concept portfolio',
          '  certs      - Accredited certificates from Google & FABEVY',
          '  agency     - BM Developer Agency profile & portal',
          '  app        - Android portfolio app release specifications',
          '  contact    - Open direct message dialog',
          '  clear      - Clear the terminal screen'
        ];
        break;
      case 'app':
        output = [
          `> ${appConfig.name.toUpperCase()} (ANDROID)`,
          `> Version: ${appConfig.version}`,
          `> Package ID: ${appConfig.packageId}`,
          `> APK Path: ${appConfig.apkPath}`,
          `> Status: ${appConfig.downloadEnabled ? 'APK Download Ready' : 'Coming Soon'}`
        ];
        if (onDownloadApp) {
          onDownloadApp();
        }
        break;
      case 'agency':
        output = [
          '> BM DEVELOPER AGENCY',
          '> Digital Development & Technology',
          `> URL: ${profile.agencyUrl}`
        ];
        break;
      case 'whoami':
        output = ['> JM Madhu Sudhuon CZ'];
        break;
      case 'skills':
        output = [
          '> HTML',
          '> CSS',
          '> JavaScript',
          '> Python',
          '> C++',
          '> Machine Learning'
        ];
        break;
      case 'focus':
        output = [
          '> Software',
          '> AI/ML',
          '> Projects',
          '> Engineering',
          '> Product Ideas'
        ];
        break;
      case 'status':
        output = ['> Building the next project...'];
        break;
      case 'projects':
        output = [
          '> RealityLens (In Development)',
          '> Brothers Studios (In Development)',
          '> Learning For Education (Concept)',
          '> Score X Pro (In Development)',
          '> Universal Formula Engine (Experimental)',
          '> Space Engineering Projects (Concept)'
        ];
        break;
      case 'certs':
        output = [
          '> Google: Machine Learning',
          '> FABEVY: C++, Python, JavaScript, CSS, HTML'
        ];
        break;
      case 'contact':
        output = [`> Opening contact interface... Direct email: ${profile.email}`];
        onOpenContact();
        break;
      case 'clear':
        setTerminalHistory([]);
        setCurrentInput('');
        return;
      default:
        output = [`Command not found: "${cmd}". Type "help" for a list of available commands.`];
    }

    setTerminalHistory((prev) => [...prev, { cmd: currentInput, output }]);
    setCurrentInput('');
  };

  // Bot chat handler
  const handleBotSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const query = chatInput.trim();
    if (!query) return;

    const userMsg = query;
    setChatMessages((prev) => [...prev, { sender: 'user', text: userMsg }]);
    setChatInput('');
    setIsBotTyping(true);

    setTimeout(() => {
      const q = userMsg.toLowerCase();
      let botReply = `Thanks for asking! JM Madhu Sudhuon CZ is a developer, programmer, and AI/ML learner focusing on building practical software.`;

      if (q.includes('skills') || q.includes('stack') || q.includes('code') || q.includes('python')) {
        botReply = "Madhu works with HTML, CSS, JavaScript, Python, and C++, alongside Machine Learning fundamentals and web/Android development.";
      } else if (q.includes('projects') || q.includes('work') || q.includes('portfolio')) {
        botReply = "Active initiatives include RealityLens, Brothers Studios, Score X Pro, Universal Formula Engine, and Learning For Education. You can check the detailed analytical breakdown in Section 02!";
      } else if (q.includes('cert') || q.includes('google') || q.includes('fabevy')) {
        botReply = "Madhu holds certifications from Google (Machine Learning) and FABEVY (C++, Python, JavaScript, CSS, HTML). View them in Section 05!";
      } else if (q.includes('contact') || q.includes('hire') || q.includes('email') || q.includes('reach')) {
        botReply = `You can email directly at ${profile.email} or click 'LET'S CONNECT' to send a project inquiry!`;
      } else if (q.includes('capabilities') || q.includes('analyst') || q.includes('team') || q.includes('idea')) {
        botReply = "Madhu specializes as a Project Analyst (requirements, planning), Team Manager (workflow, coordination), and Idea Expert (concept formulation).";
      }

      setChatMessages((prev) => [...prev, { sender: 'bot', text: botReply }]);
      setIsBotTyping(false);
    }, 500);
  };

  const getSocialIcon = (id: string) => {
    switch (id) {
      case 'github':
        return <Github className="w-3.5 h-3.5" />;
      case 'twitter':
        return <Twitter className="w-3.5 h-3.5" />;
      case 'instagram':
        return <Instagram className="w-3.5 h-3.5" />;
      case 'facebook':
        return <Facebook className="w-3.5 h-3.5" />;
      case 'agency':
        return <ArrowUpRight className="w-3.5 h-3.5" />;
      case 'email':
      default:
        return <Mail className="w-3.5 h-3.5" />;
    }
  };

  return (
    <footer id="contact" className="w-full bg-white border-b-2 border-black">
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-12 divide-y-2 md:divide-y-0 md:divide-x-2 divide-black">
        {/* Module 1: LET'S BUILD SOMETHING GREAT */}
        <div className="xl:col-span-3 p-6 sm:p-8 bg-[#d4fc35] flex flex-col justify-between relative overflow-hidden select-none">
          <div className="z-10">
            <h2 className="text-xl sm:text-2xl font-mono font-extrabold tracking-tight text-black leading-snug mb-3">
              LET'S BUILD
              <br />
              SOMETHING GREAT.
            </h2>

            <p className="font-mono text-xs text-slate-900 leading-relaxed mb-6 max-w-[220px]">
              Available for software engineering, AI/ML initiatives, and analytical project development.
            </p>

            <button
              onClick={onOpenContact}
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-black hover:bg-slate-800 text-white font-mono text-xs font-bold tracking-wider transition-colors cursor-pointer group shadow-[3px_3px_0px_rgba(0,0,0,0.2)]"
            >
              <span>CONTACT ME</span>
              <ChevronRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
            </button>
          </div>

          {/* Caution Stripes Block on bottom-right corner */}
          <div className="absolute right-0 bottom-0 w-24 h-12 caution-stripes border-t-2 border-l-2 border-black" />
        </div>

        {/* Module 2: Isometric 3D Graphic Cluster */}
        <div className="xl:col-span-3 p-6 flex items-center justify-center bg-white border-t-2 md:border-t-0 border-black">
          <FooterIsometricCluster />
        </div>

        {/* Module 3: terminal.sh with JM@PORTFOLIO:~$ */}
        <div className="xl:col-span-3 flex flex-col bg-white border-t-2 xl:border-t-0 border-black">
          {/* Blue Title Bar */}
          <div className="h-8 px-3 bg-[#1d4ed8] text-white flex items-center justify-between border-b-2 border-black select-none">
            <div className="flex items-center gap-1.5 font-mono text-xs font-bold">
              <TerminalIcon className="w-3.5 h-3.5" />
              <span>terminal.sh — JM@PORTFOLIO</span>
            </div>
            <div className="flex items-center gap-1.5 text-xs font-mono">
              <span>_</span>
              <span>◻</span>
              <span>✕</span>
            </div>
          </div>

          {/* Shell Output & Input */}
          <div className="p-4 flex-1 flex flex-col justify-between font-mono text-xs bg-[#fdfdfd] space-y-2 min-h-[190px]">
            <div className="space-y-2 overflow-y-auto max-h-44 pr-1">
              <div className="text-slate-800">
                <span className="text-emerald-700 font-bold">JM@PORTFOLIO:~$ whoami</span>
                <div className="text-slate-700 pl-3 font-semibold">&gt; JM Madhu Sudhuon CZ</div>
              </div>

              <div className="text-slate-800">
                <span className="text-emerald-700 font-bold">JM@PORTFOLIO:~$ skills</span>
                <div className="text-slate-600 pl-3">
                  <div>&gt; HTML</div>
                  <div>&gt; CSS</div>
                  <div>&gt; JavaScript</div>
                  <div>&gt; Python</div>
                  <div>&gt; C++</div>
                  <div>&gt; Machine Learning</div>
                </div>
              </div>

              <div className="text-slate-800">
                <span className="text-emerald-700 font-bold">JM@PORTFOLIO:~$ focus</span>
                <div className="text-slate-600 pl-3">
                  <div>&gt; Software</div>
                  <div>&gt; AI/ML</div>
                  <div>&gt; Projects</div>
                  <div>&gt; Engineering</div>
                  <div>&gt; Product Ideas</div>
                </div>
              </div>

              <div className="text-slate-800">
                <span className="text-emerald-700 font-bold">JM@PORTFOLIO:~$ status</span>
                <div className="text-[#1d4ed8] font-bold pl-3">&gt; Building the next project...</div>
              </div>

              {/* Dynamic commands history */}
              {terminalHistory.map((item, idx) => (
                <div key={idx} className="pt-1">
                  <div className="text-emerald-700 font-bold">JM@PORTFOLIO:~$ {item.cmd}</div>
                  <div className="text-slate-700 pl-3 space-y-0.5">
                    {item.output.map((line, lIdx) => (
                      <div key={lIdx}>{line}</div>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            {/* Interactive Prompt Input */}
            <form onSubmit={handleTerminalSubmit} className="pt-2 border-t border-slate-200 flex items-center gap-1">
              <span className="text-emerald-700 font-bold text-[11px] whitespace-nowrap">JM@PORTFOLIO:~$</span>
              <input
                type="text"
                value={currentInput}
                onChange={(e) => setCurrentInput(e.target.value)}
                placeholder="type 'help' or command..."
                className="w-full bg-transparent text-xs font-mono text-black outline-none placeholder:text-slate-400"
              />
            </form>
          </div>
        </div>

        {/* Module 4: THANKS FOR VISITING & Social Directory */}
        <div className="xl:col-span-3 p-5 sm:p-6 flex flex-col justify-between bg-white border-t-2 xl:border-t-0 border-black">
          <div>
            <h2 className="text-base font-mono font-extrabold tracking-tight text-black uppercase mb-1">
              THANKS FOR
              <br />
              VISITING!
            </h2>
            <div className="w-8 h-0.5 bg-black my-2" />
            <p className="font-mono text-[11px] text-slate-500 mb-3">
              © {new Date().getFullYear()} {profile.brand} · {profile.name}
              <br />
              All rights reserved.
            </p>

            {/* Dedicated Agency Card in Footer */}
            <div className="mb-3">
              <AgencyCard compact />
            </div>

            {/* Dedicated Android App Download Card */}
            <div className="mb-4 p-3 bg-slate-50 border border-black shadow-[2px_2px_0px_#000000] flex items-center justify-between gap-2 font-mono">
              <div className="flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-[#1d4ed8]" />
                <div>
                  <div className="text-[11px] font-extrabold text-black">JM/CZ APP</div>
                  <div className="text-[9px] text-slate-500 font-bold">Android v{appConfig.version}</div>
                </div>
              </div>
              <button
                onClick={onDownloadApp}
                className="px-2.5 py-1.5 bg-[#1d4ed8] hover:bg-[#1e40af] text-white font-bold text-[10px] border border-black shadow-[1px_1px_0px_#000000] flex items-center gap-1 cursor-pointer active:scale-95"
                title="Download JM/CZ Android App"
              >
                <Download className="w-3 h-3" />
                <span>DOWNLOAD APP</span>
              </button>
            </div>

            {/* Assistant Widget */}
            <div className="border border-slate-300 bg-slate-50 p-2.5 mb-4 shadow-sm">
              <div className="flex items-center gap-1.5 mb-1.5 pb-1 border-b border-slate-200">
                <div className="w-4 h-4 bg-[#1d4ed8] text-white flex items-center justify-center text-[9px] font-mono font-bold">
                  CZ
                </div>
                <span className="font-mono text-[10px] font-extrabold text-black">JM/CZ BOT</span>
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse ml-auto" />
              </div>

              {/* Bot stream */}
              <div className="space-y-1.5 max-h-24 overflow-y-auto mb-2 text-[10px] font-mono pr-1">
                {chatMessages.map((msg, i) => (
                  <div
                    key={i}
                    className={`p-1.5 leading-snug rounded-none ${
                      msg.sender === 'bot'
                        ? 'bg-white border border-slate-200 text-slate-800'
                        : 'bg-[#1d4ed8] text-white ml-2 text-right'
                    }`}
                  >
                    {msg.text}
                  </div>
                ))}
                {isBotTyping && (
                  <div className="text-[10px] font-mono text-slate-400 italic">
                    typing response...
                  </div>
                )}
              </div>

              {/* Chat Form */}
              <form onSubmit={handleBotSubmit} className="flex items-center gap-1">
                <input
                  type="text"
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  placeholder="Ask about projects, skills..."
                  className="flex-1 bg-white border border-slate-300 px-2 py-1 text-[10px] font-mono outline-none"
                />
                <button
                  type="submit"
                  aria-label="Send message to bot"
                  className="w-6 h-6 bg-[#1d4ed8] hover:bg-[#1e40af] text-white flex items-center justify-center cursor-pointer"
                >
                  <Send className="w-3 h-3" />
                </button>
              </form>
            </div>
          </div>

          {/* Social Icons row (from socials prop) */}
          <div className="pt-2 space-y-2">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex flex-wrap items-center gap-1.5">
                {socials.map((s) => {
                  const hasUrl = !!s.url;
                  return (
                    <a
                      key={s.id}
                      href={hasUrl ? s.url : '#'}
                      onClick={(e) => {
                        if (!hasUrl) {
                          e.preventDefault();
                          setSocialNotice(`Configure ${s.label} in src/data/socials.js (${s.placeholder})`);
                          setTimeout(() => setSocialNotice(null), 3500);
                        }
                      }}
                      target={hasUrl && s.id !== 'email' ? '_blank' : undefined}
                      rel={hasUrl && s.id !== 'email' ? 'noopener noreferrer' : undefined}
                      aria-label={s.label}
                      className={`w-7 h-7 border border-black flex items-center justify-center transition-colors shadow-[1px_1px_0px_#000000] ${
                        hasUrl ? 'bg-white hover:bg-[#d4fc35] text-black' : 'bg-slate-100 text-slate-400 hover:bg-slate-200'
                      }`}
                      title={hasUrl ? s.label : `Configure ${s.label} in src/data/socials.js`}
                    >
                      {getSocialIcon(s.id)}
                    </a>
                  );
                })}
              </div>

              <button
                onClick={onOpenContact}
                className="w-8 h-8 rounded-full bg-[#1d4ed8] text-white flex items-center justify-center shadow-md hover:scale-105 active:scale-95 transition-transform cursor-pointer"
                title="Quick Message"
              >
                <Mail className="w-4 h-4" />
              </button>
            </div>

            {socialNotice && (
              <div className="font-mono text-[10px] text-blue-900 font-bold animate-fade-in bg-blue-50 p-1.5 border border-blue-300">
                {socialNotice}
              </div>
            )}
          </div>
        </div>
      </div>
    </footer>
  );
};
