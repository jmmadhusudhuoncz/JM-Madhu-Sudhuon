import React, { useState } from 'react';
import { Minus, Square, X, Brain, Code2, Layers, Lightbulb, Users, FileText, CheckCircle2 } from 'lucide-react';
import { skillsData, allTechnologies } from '../data/skills';
import { capabilitiesData } from '../data/capabilities';
import { certificatesData } from '../data/certificates';
import { projectsData } from '../data/projects';
import { stats, formatStatValue } from '../data/stats';

interface SkillsAndCapabilitiesProps {
  onOpenProjects: () => void;
  onOpenCerts: () => void;
  skills?: typeof skillsData;
  capabilities?: typeof capabilitiesData;
}

export const SkillsAndCapabilities: React.FC<SkillsAndCapabilitiesProps> = ({
  onOpenProjects,
  onOpenCerts,
  skills = skillsData,
  capabilities = capabilitiesData,
}) => {
  const [selectedCapability, setSelectedCapability] = useState<string | null>(null);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'WORKING WITH':
        return 'bg-[#1d4ed8] text-white border-black';
      case 'LEARNING':
        return 'bg-[#d4fc35] text-black border-black';
      case 'EXPLORING':
        return 'bg-purple-100 text-purple-900 border-purple-400';
      default:
        return 'bg-slate-100 text-slate-800 border-slate-300';
    }
  };

  return (
    <section id="skills" className="w-full bg-white border-b-2 border-black">
      {/* 2-Column Split: SKILLS.EXE and CAPABILITIES.EXE */}
      <div className="grid grid-cols-1 lg:grid-cols-12 divide-y-2 lg:divide-y-0 lg:divide-x-2 divide-black">
        {/* Left Column: SKILLS.EXE */}
        <div className="lg:col-span-6 flex flex-col bg-white">
          {/* Blue Retro OS Window Header */}
          <div className="h-10 px-4 bg-[#1d4ed8] text-white flex items-center justify-between border-b-2 border-black select-none">
            <div className="flex items-center gap-2">
              <Code2 className="w-4 h-4 text-[#d4fc35]" />
              <span className="font-mono text-xs font-extrabold tracking-wider">
                03/ SKILLS.EXE
              </span>
            </div>
            <div className="flex items-center gap-2 font-mono text-xs">
              <Minus className="w-3.5 h-3.5 hover:opacity-75 cursor-pointer" />
              <Square className="w-3 h-3 hover:opacity-75 cursor-pointer" />
              <X className="w-3.5 h-3.5 hover:opacity-75 cursor-pointer" />
            </div>
          </div>

          {/* Window Body: Real technical skills grouped by category */}
          <div className="p-5 sm:p-7 space-y-6 flex-1">
            <div className="flex items-center justify-between border-b border-slate-200 pb-2">
              <span className="font-mono text-xs font-extrabold text-black uppercase tracking-wider">
                TECHNICAL PROFICIENCY DIRECTORY
              </span>
              <div className="flex items-center gap-2 font-mono text-[10px]">
                <span className="flex items-center gap-1">
                  <span className="w-2 h-2 bg-[#1d4ed8] inline-block" /> WORKING WITH
                </span>
                <span className="flex items-center gap-1">
                  <span className="w-2 h-2 bg-[#d4fc35] border border-black inline-block" /> LEARNING
                </span>
                <span className="flex items-center gap-1">
                  <span className="w-2 h-2 bg-purple-600 inline-block" /> EXPLORING
                </span>
              </div>
            </div>

            {skills.map((group) => (
              <div key={group.category} className="space-y-3">
                <div className="flex items-center gap-2 font-mono text-xs font-extrabold text-[#1d4ed8] uppercase tracking-wider">
                  <span>// {group.category}</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {group.skills.map((skill) => (
                    <div
                      key={skill.name}
                      className="p-2.5 bg-slate-50 border border-slate-300 hover:border-black transition-colors flex items-center justify-between"
                    >
                      <span className="font-mono text-xs font-bold text-black">
                        {skill.name}
                      </span>
                      <span
                        className={`font-mono text-[9px] font-extrabold px-1.5 py-0.5 border ${getStatusColor(
                          skill.status
                        )}`}
                      >
                        {skill.status}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right Column: CAPABILITIES.EXE */}
        <div id="capabilities" className="lg:col-span-6 flex flex-col bg-white border-t-2 lg:border-t-0 border-black">
          {/* Lime Green Retro OS Window Header */}
          <div className="h-10 px-4 bg-[#d4fc35] text-black flex items-center justify-between border-b-2 border-black select-none">
            <div className="flex items-center gap-2">
              <Brain className="w-4 h-4 text-black" />
              <span className="font-mono text-xs font-extrabold tracking-wider">
                04/ CAPABILITIES.EXE
              </span>
            </div>
            <div className="flex items-center gap-2 font-mono text-xs">
              <Minus className="w-3.5 h-3.5 hover:opacity-75 cursor-pointer" />
              <Square className="w-3 h-3 hover:opacity-75 cursor-pointer" />
              <X className="w-3.5 h-3.5 hover:opacity-75 cursor-pointer" />
            </div>
          </div>

          {/* Window Body: Capabilities & Areas of Expertise */}
          <div className="p-5 sm:p-7 space-y-5 flex-1">
            <p className="font-mono text-xs text-slate-700 leading-relaxed border-b border-slate-200 pb-3">
              Analytical strengths and structured execution methodologies without exaggerated corporate claims.
            </p>

            <div className="space-y-4">
              {capabilities.map((cap) => {
                const isSelected = selectedCapability === cap.id;
                return (
                  <div
                    key={cap.id}
                    onClick={() => setSelectedCapability(isSelected ? null : cap.id)}
                    className={`p-4 border-2 transition-all cursor-pointer ${
                      isSelected
                        ? 'border-black bg-slate-50 shadow-[3px_3px_0px_#000000]'
                        : 'border-slate-300 hover:border-black bg-white'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <span className="px-1.5 py-0.5 bg-[#1d4ed8] text-white font-mono text-[10px] font-bold">
                          {cap.code}
                        </span>
                        <h3 className="font-mono text-sm font-extrabold text-black uppercase">
                          {cap.title}
                        </h3>
                      </div>
                      <span className="font-mono text-[10px] text-slate-500 font-bold">
                        {cap.items.length} FOCUS POINTS
                      </span>
                    </div>

                    <p className="font-mono text-xs text-slate-600 mb-3 leading-relaxed">
                      {cap.description}
                    </p>

                    {/* Bullet list */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 pt-2 border-t border-slate-200">
                      {cap.items.map((item) => (
                        <div key={item} className="flex items-center gap-1.5 font-mono text-[11px] text-black">
                          <CheckCircle2 className="w-3 h-3 text-[#1d4ed8] shrink-0" />
                          <span>{item}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* Full-Width Bottom Bar: STATS.JSON (Verified real data) */}
      <div className="border-t-2 border-black bg-slate-50">
        <div className="h-8 px-4 bg-black text-white flex items-center justify-between border-b border-black font-mono text-xs select-none">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 bg-[#d4fc35]" />
            <span className="font-bold tracking-wider">STATS.JSON — VERIFIABLE RECORD</span>
          </div>
          <span className="text-[10px] text-slate-400">STATUS: ACCURATE / NON-FABRICATED</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-5 divide-y sm:divide-y-0 sm:divide-x-2 divide-black bg-white">
          <div
            onClick={onOpenProjects}
            className="p-4 sm:p-5 hover:bg-slate-50 transition-colors cursor-pointer select-none"
          >
            <span className="font-mono text-2xl sm:text-3xl font-black text-black block mb-0.5">
              {formatStatValue(stats.projects)}
            </span>
            <span className="font-mono text-[11px] font-bold text-slate-700 tracking-wider block uppercase">
              PROJECTS TRACKED
            </span>
            <span className="font-mono text-[10px] text-slate-500">Documented specs</span>
          </div>

          <div
            onClick={onOpenCerts}
            className="p-4 sm:p-5 hover:bg-slate-50 transition-colors cursor-pointer select-none"
          >
            <span className="font-mono text-2xl sm:text-3xl font-black text-[#1d4ed8] block mb-0.5">
              {formatStatValue(stats.certificates)}
            </span>
            <span className="font-mono text-[11px] font-bold text-slate-700 tracking-wider block uppercase">
              CERTIFICATES
            </span>
            <span className="font-mono text-[10px] text-slate-500">Google &amp; FABEVY</span>
          </div>

          <div className="p-4 sm:p-5 bg-white">
            <span className="font-mono text-2xl sm:text-3xl font-black text-black block mb-0.5">
              {formatStatValue(stats.technologies)}
            </span>
            <span className="font-mono text-[11px] font-bold text-slate-700 tracking-wider block uppercase">
              CORE TECHNOLOGIES
            </span>
            <span className="font-mono text-[10px] text-slate-500">Active skill set</span>
          </div>

          <div className="p-4 sm:p-5 bg-white">
            <span className="font-mono text-2xl sm:text-3xl font-black text-black block mb-0.5">
              {formatStatValue(stats.currentProjects)}
            </span>
            <span className="font-mono text-[11px] font-bold text-slate-700 tracking-wider block uppercase">
              ACTIVE INITIATIVES
            </span>
            <span className="font-mono text-[10px] text-slate-500">In dev &amp; experimental</span>
          </div>

          <div className="p-4 sm:p-5 bg-white col-span-2 sm:col-span-1">
            <span className="font-mono text-2xl sm:text-3xl font-black text-black block mb-0.5">
              {formatStatValue(stats.completedProjects ?? stats.conceptRoadmaps)}
            </span>
            <span className="font-mono text-[11px] font-bold text-slate-700 tracking-wider block uppercase">
              {stats.completedProjects !== null ? 'COMPLETED BUILDS' : 'CONCEPT ROADMAPS'}
            </span>
            <span className="font-mono text-[10px] text-slate-500">
              {stats.completedProjects !== null ? 'Verified deliverables' : 'Research & architecture'}
            </span>
          </div>
        </div>
      </div>
    </section>
  );
};
