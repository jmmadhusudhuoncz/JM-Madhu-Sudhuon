import React, { useState, useEffect } from 'react';
import {
  X,
  Check,
  ExternalLink,
  Download,
  Printer,
  Award,
  FileText,
  CheckCircle2,
  ShieldCheck,
  Share2,
  ArrowLeft,
  Github,
  AlertCircle,
  Smartphone,
  Clock
} from 'lucide-react';
import { ProjectItem } from './Projects';
import { CertificateItem } from './Certifications';
import { PublishedApp, getDownloadButtonLabel } from '../data/publishedApps';
import { resolveStorageDownloadUrl } from '../services/firebase';
import { profile } from '../data/profile';
import { skillsData } from '../data/skills';
import { capabilitiesData } from '../data/capabilities';
import { certificatesData } from '../data/certificates';
import { projectsData } from '../data/projects';
import { journeyData } from '../data/journey';
import { socialsData } from '../data/socials';
import { ProjectRequestForm } from './ProjectRequestForm';
import { CapacitorService } from '../services/capacitorService';

// --- CONTACT MODAL ---
interface ContactModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ContactModal: React.FC<ContactModalProps> = ({ isOpen, onClose }) => {
  useEffect(() => {
    if (!isOpen) return;
    const unregister = CapacitorService.registerBackButtonHandler(() => {
      onClose();
      return true;
    });
    return () => unregister();
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-0 sm:p-4 bg-black/60 backdrop-blur-xs overflow-y-auto"
      style={{
        paddingTop: 'max(env(safe-area-inset-top), 0px)',
        paddingBottom: 'max(env(safe-area-inset-bottom), 0px)',
      }}
    >
      <div className="relative w-full h-full sm:h-auto sm:max-w-2xl bg-white border-0 sm:border-2 border-black shadow-none sm:shadow-[10px_10px_0px_#000000] overflow-hidden flex flex-col font-mono animate-in fade-in duration-150">
        {/* Title Bar */}
        <div className="h-12 sm:h-10 px-4 bg-[#d4fc35] text-black font-extrabold text-xs flex items-center justify-between border-b-2 border-black select-none shrink-0">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 bg-black" />
            <span className="uppercase text-[11px] sm:text-xs">
              PROJECT REQUEST // DIRECT DISPATCH
            </span>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 sm:w-6 sm:h-6 border border-black bg-white hover:bg-black hover:text-white flex items-center justify-center cursor-pointer transition-colors active:scale-95"
            aria-label="Close dialog"
          >
            <X className="w-4 h-4 sm:w-3.5 sm:h-3.5" />
          </button>
        </div>

        {/* Real Contact & Order Form Component */}
        <div className="flex-1 overflow-y-auto p-2 sm:p-0">
          <ProjectRequestForm isModal onSuccessClose={onClose} />
        </div>
      </div>
    </div>
  );
};

// --- MOBILE-FIRST PROJECT DETAILS MODAL / PAGE ---
interface ProjectModalProps {
  project: ProjectItem | null;
  onClose: () => void;
}

export const ProjectModal: React.FC<ProjectModalProps> = ({ project, onClose }) => {
  const [shareFeedback, setShareFeedback] = useState<string | null>(null);

  useEffect(() => {
    if (!project) return;
    const unregister = CapacitorService.registerBackButtonHandler(() => {
      onClose();
      return true;
    });
    return () => unregister();
  }, [project, onClose]);

  if (!project) return null;

  const handleShare = async () => {
    const success = await CapacitorService.share({
      title: `${project.title} — JM/CZ Portfolio`,
      text: `${project.title}: ${project.subtitle}\nProblem: ${project.problem}\nTech Stack: ${project.technology.join(', ')}`,
      url: window.location.href,
    });
    if (success) {
      setShareFeedback('Shared / Copied!');
      setTimeout(() => setShareFeedback(null), 2500);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex flex-col bg-white sm:bg-black/60 sm:items-center sm:justify-center p-0 sm:p-4 overflow-hidden font-mono select-none sm:select-auto"
      style={{
        paddingTop: 'max(env(safe-area-inset-top), 0px)',
        paddingBottom: 'max(env(safe-area-inset-bottom), 0px)',
      }}
    >
      <div className="relative w-full h-full sm:h-auto sm:max-h-[92vh] sm:max-w-3xl bg-white border-0 sm:border-2 border-black sm:shadow-[10px_10px_0px_#000000] flex flex-col overflow-hidden animate-in fade-in duration-150">
        {/* Top Header Bar */}
        <div className="h-13 sm:h-11 px-3 sm:px-4 bg-[#1d4ed8] text-white font-extrabold text-xs flex items-center justify-between border-b-2 border-black select-none shrink-0">
          {/* Back button that returns to Projects */}
          <button
            onClick={onClose}
            className="flex items-center gap-1.5 px-2.5 py-1.5 bg-black hover:bg-slate-800 text-white border border-white font-mono text-[11px] font-bold cursor-pointer active:scale-95"
            title="Return to Projects"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>BACK TO PROJECTS</span>
          </button>

          {/* Share & Close Actions */}
          <div className="flex items-center gap-1.5">
            <button
              onClick={handleShare}
              className="flex items-center gap-1 px-2.5 py-1.5 bg-[#d4fc35] hover:bg-[#bef264] text-black border border-black font-mono text-[11px] font-bold cursor-pointer active:scale-95"
              title="Share Project"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span>{shareFeedback || 'SHARE'}</span>
            </button>

            <button
              onClick={onClose}
              className="w-8 h-8 sm:w-7 sm:h-7 border border-white bg-black hover:bg-white hover:text-black flex items-center justify-center cursor-pointer transition-colors active:scale-95"
              aria-label="Close project view"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Project Title & Category Banner */}
        <div className="p-4 sm:p-6 border-b-2 border-black bg-slate-50 flex flex-wrap items-center justify-between gap-3 text-xs shrink-0">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2 py-0.5 bg-[#d4fc35] text-black font-mono text-[10px] font-black border border-black">
                #{project.number}
              </span>
              <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">
                {project.category}
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-black uppercase tracking-tight break-words">
              {project.title}
            </h2>
            <p className="text-slate-700 font-semibold text-xs sm:text-sm mt-0.5">
              {project.subtitle}
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[10px] text-slate-500 font-bold">STATUS:</span>
            <span
              className={`px-2.5 py-1 text-xs font-black border border-black uppercase ${
                project.status === 'Completed'
                  ? 'bg-emerald-600 text-white'
                  : project.status === 'In Development'
                  ? 'bg-[#1d4ed8] text-white'
                  : project.status === 'Concept'
                  ? 'bg-[#d4fc35] text-black'
                  : 'bg-purple-700 text-white'
              }`}
            >
              {project.status}
            </span>
          </div>
        </div>

        {/* Scrollable Project Details Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-5 text-xs leading-relaxed">
          {/* OVERVIEW & PROBLEM */}
          <div className="p-3.5 bg-red-50/70 border-l-4 border-red-500 border-y border-r border-red-200">
            <span className="text-[10px] font-black text-red-900 tracking-wider block mb-1 uppercase">
              // PROBLEM STATEMENT &amp; CONTEXT
            </span>
            <p className="text-slate-900 text-xs sm:text-sm font-medium">{project.problem}</p>
          </div>

          {/* SOLUTION */}
          <div className="p-3.5 bg-blue-50/70 border-l-4 border-[#1d4ed8] border-y border-r border-blue-200">
            <span className="text-[10px] font-black text-[#1d4ed8] tracking-wider block mb-1 uppercase">
              // ARCHITECTURAL SOLUTION
            </span>
            <p className="text-slate-900 text-xs sm:text-sm font-medium">{project.solution}</p>
          </div>

          {/* ROLE & TECHNOLOGIES */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div className="p-3.5 bg-slate-50 border border-slate-300">
              <span className="text-[10px] font-black text-slate-500 tracking-wider block mb-1 uppercase">
                // MY ROLE
              </span>
              <p className="font-bold text-black text-xs sm:text-sm">{project.role}</p>
            </div>

            <div className="p-3.5 bg-slate-50 border border-slate-300">
              <span className="text-[10px] font-black text-slate-500 tracking-wider block mb-1 uppercase">
                // TECHNOLOGIES &amp; STACK
              </span>
              <div className="flex flex-wrap gap-1.5 pt-1">
                {project.technology.map((tech) => (
                  <span
                    key={tech}
                    className="px-2 py-0.5 bg-white border border-black font-bold text-black text-[10px]"
                  >
                    {tech}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* KEY FEATURES */}
          <div>
            <span className="text-[10px] font-black text-black tracking-wider block mb-2 uppercase">
              // KEY SPECIFICATIONS &amp; FEATURES
            </span>
            <ul className="space-y-2">
              {project.features.map((feat, idx) => (
                <li
                  key={idx}
                  className="flex items-start gap-2.5 p-2 bg-slate-50 border border-slate-200 text-slate-800 text-xs"
                >
                  <CheckCircle2 className="w-4 h-4 text-[#1d4ed8] shrink-0 mt-0.5" />
                  <span>{feat}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* LEARNING & INSIGHTS */}
          <div className="p-3.5 bg-slate-100 border border-black">
            <span className="text-[10px] font-black text-black tracking-wider block mb-1 uppercase">
              // TECHNICAL &amp; ANALYTICAL LEARNING
            </span>
            <p className="text-slate-800 italic text-xs">{project.learning}</p>
          </div>

          {/* SCREENSHOTS / GRAPHIC VISUAL BLOCK */}
          <div className="p-4 border-2 border-black bg-slate-900 text-white space-y-2 text-center">
            <div className="text-[10px] text-[#d4fc35] font-bold tracking-widest uppercase">
              // VISUAL SYSTEM &amp; BLUEPRINT
            </div>
            <p className="text-[11px] text-slate-300 max-w-md mx-auto">
              System architecture designed for high throughput, mobile-first responsiveness, and modular component isolation.
            </p>
          </div>
        </div>

        {/* Modal Bottom Actions */}
        <div className="p-3.5 sm:p-4 bg-slate-50 border-t-2 border-black flex flex-wrap items-center justify-between gap-2.5 text-xs shrink-0">
          <div className="flex items-center gap-2">
            {project.links?.demo && (
              <a
                href={project.links.demo}
                target="_blank"
                rel="noreferrer"
                className="min-h-[40px] px-3.5 py-1.5 bg-[#d4fc35] hover:bg-[#bef264] text-black font-bold border border-black flex items-center gap-1.5 cursor-pointer active:scale-95"
              >
                <span>LIVE DEMO</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            )}

            {project.links?.repo && (
              <a
                href={project.links.repo}
                target="_blank"
                rel="noreferrer"
                className="min-h-[40px] px-3.5 py-1.5 bg-white hover:bg-slate-100 text-black font-bold border border-black flex items-center gap-1.5 cursor-pointer active:scale-95"
              >
                <Github className="w-3.5 h-3.5" />
                <span>GITHUB</span>
              </a>
            )}
          </div>

          <button
            onClick={onClose}
            className="min-h-[40px] px-4 py-1.5 bg-black hover:bg-slate-800 text-white font-bold border border-black cursor-pointer active:scale-95 ml-auto"
          >
            RETURN TO PROJECTS
          </button>
        </div>
      </div>
    </div>
  );
};

// --- CERTIFICATE VIEW MODAL ---
interface CertificateModalProps {
  certificate: CertificateItem | null;
  onClose: () => void;
}

export const CertificateModal: React.FC<CertificateModalProps> = ({ certificate, onClose }) => {
  useEffect(() => {
    if (!certificate) return;
    const unregister = CapacitorService.registerBackButtonHandler(() => {
      onClose();
      return true;
    });
    return () => unregister();
  }, [certificate, onClose]);

  if (!certificate) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-0 sm:p-4 bg-black/60 backdrop-blur-xs overflow-y-auto font-mono"
      style={{
        paddingTop: 'max(env(safe-area-inset-top), 0px)',
        paddingBottom: 'max(env(safe-area-inset-bottom), 0px)',
      }}
    >
      <div className="relative w-full h-full sm:h-auto sm:max-w-2xl bg-white border-0 sm:border-2 border-black sm:shadow-[10px_10px_0px_#000000] overflow-hidden flex flex-col animate-in fade-in duration-150">
        {/* Title bar */}
        <div className="h-12 sm:h-10 px-4 bg-black text-white font-extrabold text-xs flex items-center justify-between border-b-2 border-black select-none shrink-0">
          <div className="flex items-center gap-2">
            <Award className="w-4 h-4 text-[#d4fc35]" />
            <span className="uppercase text-[11px] sm:text-xs">
              CERTIFICATE // {certificate.issuer.toUpperCase()}
            </span>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 sm:w-6 sm:h-6 border border-white bg-slate-800 hover:bg-[#d4fc35] hover:text-black flex items-center justify-center cursor-pointer transition-colors active:scale-95"
          >
            <X className="w-4 h-4 sm:w-3.5 sm:h-3.5" />
          </button>
        </div>

        {/* Certificate Card Content */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-8 space-y-5">
          <div className="p-5 sm:p-6 border-2 border-black bg-slate-50 text-center relative overflow-hidden">
            <div className="inline-block px-3 py-1 font-black text-xs uppercase mb-3 border border-black bg-[#d4fc35] text-black">
              {certificate.issuer} ACCREDITED COURSEWORK
            </div>

            <h2 className="text-xl sm:text-3xl font-black text-black uppercase tracking-tight mb-2">
              {certificate.title}
            </h2>

            <p className="text-xs text-slate-600 font-semibold mb-3">
              Category: {certificate.category}
            </p>

            <div className="w-16 h-0.5 bg-black mx-auto mb-3" />

            <div className="text-xs font-bold text-slate-700">
              Awarded to <strong className="text-black">{profile.name}</strong>
            </div>

            {/* Verification / Attachment */}
            {certificate.image ? (
              <div className="mt-4 border border-black overflow-hidden">
                <img src={certificate.image} alt={certificate.title} className="w-full h-auto" />
              </div>
            ) : certificate.pdf ? (
              <div className="mt-4 p-3 bg-white border border-black flex items-center justify-center gap-2">
                <FileText className="w-5 h-5 text-[#1d4ed8]" />
                <a
                  href={certificate.pdf}
                  target="_blank"
                  rel="noreferrer"
                  className="font-bold underline text-[#1d4ed8] text-xs"
                >
                  Open Certificate PDF Document
                </a>
              </div>
            ) : (
              <div className="mt-4 p-3 bg-white border border-slate-300 text-[11px] text-slate-600 text-left">
                <div className="flex items-center gap-1.5 font-bold text-black mb-1">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  <span>Accreditation on record</span>
                </div>
                Coursework evaluation successfully completed under {certificate.issuer}.
              </div>
            )}
          </div>

          <div className="space-y-2 text-xs">
            <p className="text-slate-800 leading-relaxed font-medium">
              {certificate.description}
            </p>
            {certificate.date && (
              <div className="font-mono text-xs">
                <span className="font-bold">Completion Date:</span> {certificate.date}
              </div>
            )}
            {certificate.credentialId && (
              <div className="font-mono text-xs">
                <span className="font-bold">Credential Reference ID:</span> {certificate.credentialId}
              </div>
            )}
          </div>
        </div>

        {/* Footer actions */}
        <div className="p-3.5 sm:p-4 bg-slate-50 border-t-2 border-black flex items-center justify-between text-xs shrink-0">
          {certificate.verificationUrl ? (
            <a
              href={certificate.verificationUrl}
              target="_blank"
              rel="noreferrer"
              className="px-4 py-2 bg-[#d4fc35] hover:bg-[#bef264] text-black font-bold border border-black flex items-center gap-1.5 cursor-pointer"
            >
              <span>VERIFY ONLINE</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          ) : (
            <span className="text-[11px] text-slate-500 font-bold">
              Issuer: {certificate.issuer}
            </span>
          )}

          <button
            onClick={onClose}
            className="min-h-[38px] px-4 py-1.5 border border-slate-300 hover:bg-slate-200 text-black font-bold cursor-pointer"
          >
            CLOSE
          </button>
        </div>
      </div>
    </div>
  );
};

// --- DOWNLOAD CV / RESUME MODAL ---
interface CvModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CvModal: React.FC<CvModalProps> = ({ isOpen, onClose }) => {
  const [downloadSuccess, setDownloadSuccess] = useState(false);
  const [checkingFile, setCheckingFile] = useState(false);
  const [cvNotFound, setCvNotFound] = useState(false);

  useEffect(() => {
    if (!isOpen) return;
    const unregister = CapacitorService.registerBackButtonHandler(() => {
      onClose();
      return true;
    });
    return () => unregister();
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleDownload = async () => {
    setCheckingFile(true);
    setCvNotFound(false);

    await CapacitorService.handleCvDownload(profile.cvPath, () => {
      // File missing callback: show proper message and generate verified text/markdown
      setCvNotFound(true);
    });

    setCheckingFile(false);
  };

  const handleCopyText = async () => {
    const cvText = `# ${profile.name} — CURRICULUM VITAE
Email: ${profile.email}
Brand: ${profile.brand}
Role: ${profile.role}

${profile.aboutHeadline}
${profile.aboutText}

WHO AM I:
${profile.whoAmI}

FOCUS:
${profile.focus}

TECHNOLOGY:
${profile.technology}

CURRENT STATUS:
${profile.currentStatus}

TECHNICAL SKILLS:
${skillsData.map((c) => `${c.category}:\n${c.skills.map((s) => `  - ${s.name} (${s.status})`).join('\n')}`).join('\n\n')}

CAPABILITIES:
${capabilitiesData.map((c) => `- ${c.title}: ${c.description}`).join('\n')}

CERTIFICATIONS:
${certificatesData.map((c) => `- ${c.issuer}: ${c.title}`).join('\n')}

PROJECTS:
${projectsData.map((p) => `- ${p.title} (${p.status}): ${p.subtitle}`).join('\n')}

JOURNEY:
${journeyData.map((j) => `- [${j.phase}] ${j.title}: ${j.description}`).join('\n')}
`;

    try {
      await navigator.clipboard.writeText(cvText);
      setDownloadSuccess(true);
      setTimeout(() => setDownloadSuccess(false), 2500);
    } catch {
      // Fallback
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-0 sm:p-4 bg-black/60 backdrop-blur-xs overflow-y-auto font-mono"
      style={{
        paddingTop: 'max(env(safe-area-inset-top), 0px)',
        paddingBottom: 'max(env(safe-area-inset-bottom), 0px)',
      }}
    >
      <div className="relative w-full h-full sm:h-auto sm:max-h-[92vh] sm:max-w-2xl bg-white border-0 sm:border-2 border-black sm:shadow-[10px_10px_0px_#000000] overflow-hidden flex flex-col animate-in fade-in duration-150">
        {/* Title bar */}
        <div className="h-12 sm:h-10 px-4 bg-black text-white font-extrabold text-xs flex items-center justify-between border-b-2 border-black select-none shrink-0">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 bg-[#d4fc35]" />
            <span className="text-[11px] sm:text-xs uppercase">
              CURRICULUM VITAE // {profile.name}
            </span>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 sm:w-6 sm:h-6 border border-white bg-slate-800 hover:bg-[#d4fc35] hover:text-black flex items-center justify-center cursor-pointer transition-colors active:scale-95 text-white"
          >
            <X className="w-4 h-4 sm:w-3.5 sm:h-3.5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-5 text-xs">
          {cvNotFound && (
            <div className="p-3.5 bg-amber-50 border-2 border-amber-500 text-amber-900 space-y-1">
              <div className="flex items-center gap-1.5 font-bold">
                <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
                <span>PDF FILE NOTICE</span>
              </div>
              <p className="text-[11px] leading-relaxed">
                The standalone PDF file (<code className="bg-amber-100 px-1">{profile.cvPath}</code>) is not uploaded to assets yet. The complete, verified CV record is provided below and can be copied or printed directly.
              </p>
            </div>
          )}

          {/* Profile Header */}
          <div className="p-4 bg-slate-50 border-2 border-black space-y-1">
            <h2 className="text-lg sm:text-xl font-black text-black uppercase">
              {profile.name}
            </h2>
            <div className="text-[#1d4ed8] font-bold text-xs">
              {profile.role}
            </div>
            <div className="text-slate-600 text-[11px] pt-1">
              Email: <span className="text-black font-bold">{profile.email}</span> • {profile.location}
            </div>
          </div>

          {/* Profile Summary */}
          <div className="space-y-1">
            <h3 className="font-extrabold text-black uppercase tracking-wider text-xs border-b border-black pb-0.5">
              // Professional Summary
            </h3>
            <p className="text-slate-800 leading-relaxed text-xs">
              {profile.aboutText}
            </p>
          </div>

          {/* WHO AM I & FOCUS */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="p-3 bg-slate-50 border border-slate-300">
              <div className="font-bold text-black text-[11px] uppercase mb-1">WHO AM I</div>
              <p className="text-slate-700 text-[11px] leading-relaxed">{profile.whoAmI}</p>
            </div>
            <div className="p-3 bg-slate-50 border border-slate-300">
              <div className="font-bold text-black text-[11px] uppercase mb-1">FOCUS</div>
              <p className="text-slate-700 text-[11px] leading-relaxed">{profile.focus}</p>
            </div>
          </div>

          {/* TECHNICAL SKILLS */}
          <div className="space-y-2">
            <h3 className="font-extrabold text-black uppercase tracking-wider text-xs border-b border-black pb-0.5">
              // Technical Skills &amp; Stack
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {skillsData.map((cat) => (
                <div key={cat.category} className="p-2.5 bg-slate-50 border border-slate-200">
                  <div className="font-bold text-black text-[10px] uppercase mb-1">{cat.category}</div>
                  <div className="text-slate-700 text-[11px] space-y-0.5">
                    {cat.skills.map((s) => (
                      <div key={s.name} className="flex justify-between">
                        <span>• {s.name}</span>
                        <span className="text-slate-500 text-[9px]">{s.status}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* ACCREDITED CERTIFICATIONS */}
          <div className="space-y-1">
            <h3 className="font-extrabold text-black uppercase tracking-wider text-xs border-b border-black pb-0.5">
              // Accredited Certifications
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
              {certificatesData.map((cert) => (
                <div key={cert.id} className="p-2 bg-slate-50 border border-slate-200 text-[11px]">
                  <strong>{cert.issuer}:</strong> {cert.title}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-3.5 sm:p-4 bg-slate-50 border-t-2 border-black flex flex-wrap items-center justify-between gap-2 text-xs shrink-0">
          <div className="flex items-center gap-2">
            <button
              onClick={handleDownload}
              disabled={checkingFile}
              className="min-h-[40px] px-3.5 py-1.5 bg-[#1d4ed8] hover:bg-[#1e40af] text-white font-bold border border-black flex items-center gap-1.5 cursor-pointer active:scale-95"
            >
              <Download className="w-3.5 h-3.5" />
              <span>{checkingFile ? 'CHECKING...' : 'DOWNLOAD PDF'}</span>
            </button>

            <button
              onClick={handleCopyText}
              className="min-h-[40px] px-3.5 py-1.5 bg-white hover:bg-slate-100 text-black font-bold border border-black flex items-center gap-1.5 cursor-pointer active:scale-95"
            >
              {downloadSuccess ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <FileText className="w-3.5 h-3.5" />}
              <span>{downloadSuccess ? 'COPIED!' : 'COPY CV TEXT'}</span>
            </button>
          </div>

          <button
            onClick={onClose}
            className="min-h-[40px] px-4 py-1.5 border border-slate-300 hover:bg-slate-200 text-black font-bold cursor-pointer"
          >
            CLOSE
          </button>
        </div>
      </div>
    </div>
  );
};

// --- APP DETAILS MODAL ---
interface AppDetailsModalProps {
  app: PublishedApp | null;
  onClose: () => void;
}

export const AppDetailsModal: React.FC<AppDetailsModalProps> = ({ app, onClose }) => {
  const [copiedLink, setCopiedLink] = useState(false);

  useEffect(() => {
    if (!app) return;
    const unregister = CapacitorService.registerBackButtonHandler(() => {
      onClose();
      return true;
    });
    return () => unregister();
  }, [app, onClose]);

  if (!app) return null;

  const handleShare = async () => {
    const success = await CapacitorService.share({
      title: `${app.name} (v${app.version}) — JM/CZ`,
      text: `${app.name} (${app.platform}) v${app.version}\n${app.description}`,
      url: window.location.href,
    });
    if (success) {
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-0 sm:p-4 bg-black/60 backdrop-blur-xs overflow-y-auto font-mono"
      style={{
        paddingTop: 'max(env(safe-area-inset-top), 0px)',
        paddingBottom: 'max(env(safe-area-inset-bottom), 0px)',
      }}
    >
      <div className="relative w-full h-full sm:h-auto sm:max-h-[92vh] sm:max-w-3xl bg-white border-0 sm:border-2 border-black sm:shadow-[10px_10px_0px_#000000] overflow-hidden flex flex-col animate-in fade-in duration-150">
        {/* Title Bar */}
        <div className="h-12 sm:h-11 px-3 sm:px-4 bg-black text-white font-extrabold text-xs flex items-center justify-between border-b-2 border-black select-none shrink-0">
          <div className="flex items-center gap-2">
            <Smartphone className="w-4 h-4 text-[#d4fc35]" />
            <span className="uppercase text-[11px] sm:text-xs">
              APP DETAILS // {app.name.toUpperCase()} (v{app.version})
            </span>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={handleShare}
              className="flex items-center gap-1 px-2.5 py-1 bg-[#d4fc35] hover:bg-[#bef264] text-black font-bold text-[10px] sm:text-[11px] cursor-pointer"
            >
              <Share2 className="w-3 h-3" />
              <span>{copiedLink ? 'SHARED' : 'SHARE'}</span>
            </button>

            <button
              onClick={onClose}
              className="w-7 h-7 border border-white bg-slate-800 hover:bg-[#d4fc35] hover:text-black flex items-center justify-center cursor-pointer transition-colors"
              aria-label="Close dialog"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-5 text-xs">
          {/* Header Card */}
          <div className="p-4 sm:p-5 bg-slate-50 border-2 border-black flex flex-wrap items-center justify-between gap-3">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="px-2 py-0.5 bg-[#1d4ed8] text-white text-[10px] font-bold border border-black uppercase">
                  {app.platform}
                </span>
                <span className="text-[10px] font-bold text-slate-500 uppercase">
                  {app.category}
                </span>
              </div>
              <h2 className="text-xl sm:text-2xl font-black text-black uppercase tracking-tight">
                {app.name}
              </h2>
              <div className="text-xs font-bold text-[#1d4ed8]">
                VERSION {app.version} · {app.fileType}
              </div>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-[10px] font-bold text-slate-500">STATUS:</span>
              <span
                className={`px-2.5 py-1 text-xs font-black border border-black uppercase ${
                  app.status === 'available'
                    ? 'bg-emerald-600 text-white'
                    : 'bg-[#d4fc35] text-black'
                }`}
              >
                {app.status.toUpperCase()}
              </span>
            </div>
          </div>

          {/* Description */}
          <div className="space-y-1.5">
            <span className="text-[10px] font-black text-slate-500 tracking-wider block uppercase">
              // OVERVIEW &amp; SPECIFICATIONS
            </span>
            <p className="text-slate-800 text-xs sm:text-sm leading-relaxed">
              {app.fullDescription || app.description}
            </p>
          </div>

          {/* Features */}
          {app.features && app.features.length > 0 && (
            <div>
              <span className="text-[10px] font-black text-black tracking-wider block mb-2 uppercase">
                // APPLICATION FEATURES
              </span>
              <div className="space-y-1.5">
                {app.features.map((feat, i) => (
                  <div
                    key={i}
                    className="p-2.5 bg-slate-50 border border-slate-200 flex items-start gap-2 text-slate-800 text-xs"
                  >
                    <CheckCircle2 className="w-4 h-4 text-[#1d4ed8] shrink-0 mt-0.5" />
                    <span>{feat}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Technologies */}
          {app.technologies && app.technologies.length > 0 && (
            <div>
              <span className="text-[10px] font-black text-slate-500 tracking-wider block mb-1.5 uppercase">
                // TECHNOLOGIES &amp; STACK
              </span>
              <div className="flex flex-wrap gap-1.5">
                {app.technologies.map((tech) => (
                  <span
                    key={tech}
                    className="px-2.5 py-1 bg-white border border-black font-bold text-black text-[10px]"
                  >
                    {tech}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Screenshots - Only rendered if actual images exist */}
          {app.screenshots && app.screenshots.length > 0 && (
            <div>
              <span className="text-[10px] font-black text-black tracking-wider block mb-2 uppercase">
                // SCREENSHOTS &amp; PREVIEWS
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {app.screenshots.map((src, idx) => (
                  <div key={idx} className="border-2 border-black overflow-hidden bg-slate-100">
                    <img src={src} alt={`${app.name} preview ${idx + 1}`} className="w-full h-auto object-cover" />
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Dedicated Downloads Area */}
          <div className="p-4 bg-slate-50 border-2 border-black space-y-3">
            <div className="flex items-center justify-between border-b border-black pb-2">
              <div className="flex items-center gap-2">
                <Download className="w-4 h-4 text-[#1d4ed8]" />
                <span className="font-black text-xs uppercase text-black">
                  AVAILABLE DOWNLOAD PACKAGES
                </span>
              </div>
              {app.releaseDate && (
                <span className="text-[10px] text-slate-500 font-bold">
                  RELEASE: {app.releaseDate}
                </span>
              )}
            </div>

            <div className="space-y-2">
              {app.files.map((file, idx) => {
                const label = file.label || getDownloadButtonLabel(file.type);
                const canDownload = app.status === 'available' && file.exists;

                return (
                  <div
                    key={idx}
                    className="p-3 bg-white border border-slate-300 flex flex-wrap items-center justify-between gap-2 text-xs"
                  >
                    <div>
                      <div className="font-bold text-black flex items-center gap-1.5">
                        <span className="px-1.5 py-0.5 bg-[#d4fc35] text-black text-[9px] font-black border border-black">
                          {file.type}
                        </span>
                        <span>{file.name}</span>
                      </div>
                      <div className="text-[10px] text-slate-500 mt-0.5">
                        Path: <code className="bg-slate-100 px-1">{file.path}</code>
                        {file.size && <span> · Size: {file.size}</span>}
                      </div>
                    </div>

                    <div>
                      {canDownload ? (
                        <a
                          href={file.path}
                          download={file.name}
                          onClick={async (e) => {
                            if (file.path && (file.path.startsWith('gs://') || file.path.startsWith('apps/') || file.path.startsWith('media/'))) {
                              e.preventDefault();
                              const url = await resolveStorageDownloadUrl(file.path);
                              if (url) {
                                const link = document.createElement('a');
                                link.href = url;
                                link.target = '_blank';
                                link.rel = 'noopener noreferrer';
                                document.body.appendChild(link);
                                link.click();
                                document.body.removeChild(link);
                              }
                            }
                          }}
                          className="px-3.5 py-1.5 bg-[#1d4ed8] hover:bg-[#1e40af] text-white font-bold text-xs border border-black flex items-center gap-1.5 shadow-[1px_1px_0px_#000000] cursor-pointer"
                        >
                          <Download className="w-3.5 h-3.5" />
                          <span>{label}</span>
                        </a>
                      ) : (
                        <button
                          disabled
                          className="px-3.5 py-1.5 bg-slate-100 text-slate-500 font-bold text-xs border border-slate-300 flex items-center gap-1.5 cursor-not-allowed"
                        >
                          <Clock className="w-3.5 h-3.5 text-slate-400" />
                          <span>COMING SOON</span>
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Footer Actions & External Links */}
        <div className="p-3.5 sm:p-4 bg-slate-50 border-t-2 border-black flex flex-wrap items-center justify-between gap-2 text-xs shrink-0">
          <div className="flex items-center gap-2">
            {app.github && (
              <a
                href={app.github}
                target="_blank"
                rel="noreferrer"
                className="px-3 py-1.5 bg-white hover:bg-slate-100 text-black font-bold border border-black flex items-center gap-1.5"
              >
                <Github className="w-3.5 h-3.5" />
                <span>GITHUB</span>
              </a>
            )}

            {app.liveDemo && (
              <a
                href={app.liveDemo}
                target="_blank"
                rel="noreferrer"
                className="px-3 py-1.5 bg-[#d4fc35] hover:bg-[#bef264] text-black font-bold border border-black flex items-center gap-1.5"
              >
                <span>LIVE DEMO</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            )}
          </div>

          <button
            onClick={onClose}
            className="min-h-[38px] px-4 py-1.5 border border-slate-300 hover:bg-slate-200 text-black font-bold cursor-pointer ml-auto"
          >
            CLOSE
          </button>
        </div>
      </div>
    </div>
  );
};
