import React, { useState, useEffect } from 'react';
import { ArrowUpRight, Download, Github, Instagram, Facebook, Twitter, Mail, Check, FileText, Smartphone } from 'lucide-react';
import { HeroIsometricCluster } from './IsometricGraphics';
import { profile } from '../data/profile';
import { socialsData } from '../data/socials';

interface HeroProps {
  onViewProjects: () => void;
  onDownloadCv: () => void;
  onOpenConnect: () => void;
  onDownloadApp?: () => void;
  profileData?: typeof profile;
  socials?: typeof socialsData;
}

export const Hero: React.FC<HeroProps> = ({
  onViewProjects,
  onDownloadCv,
  onOpenConnect,
  onDownloadApp,
  profileData = profile,
  socials = socialsData,
}) => {
  const [copiedEmail, setCopiedEmail] = useState(false);
  const [socialNotice, setSocialNotice] = useState<string | null>(null);
  const [cursorVisible, setCursorVisible] = useState(true);

  // Blinking terminal cursor effect
  useEffect(() => {
    const timer = setInterval(() => {
      setCursorVisible((v) => !v);
    }, 600);
    return () => clearInterval(timer);
  }, []);

  const handleCopyEmail = () => {
    navigator.clipboard.writeText(profile.email);
    setCopiedEmail(true);
    setTimeout(() => setCopiedEmail(false), 2000);
  };

  const handleSocialClick = (e: React.MouseEvent, label: string, url: string, placeholder: string) => {
    if (!url) {
      e.preventDefault();
      setSocialNotice(`Configure ${label} in src/data/socials.js (${placeholder})`);
      setTimeout(() => setSocialNotice(null), 3500);
    }
  };

  const handleDownloadCvClick = () => {
    // Check if configured CV path exists or open graceful viewer/fallback
    if (profile.cvPath) {
      fetch(profile.cvPath, { method: 'HEAD' })
        .then((res) => {
          if (res.ok) {
            window.location.href = profile.cvPath;
          } else {
            // Graceful fallback: trigger formatted CV modal preview
            onDownloadCv();
          }
        })
        .catch(() => {
          onDownloadCv();
        });
    } else {
      onDownloadCv();
    }
  };

  const githubSocial = socials.find((s) => s.id === 'github');
  const instagramSocial = socials.find((s) => s.id === 'instagram');
  const facebookSocial = socials.find((s) => s.id === 'facebook');
  const twitterSocial = socials.find((s) => s.id === 'twitter');

  return (
    <section id="home" className="relative w-full bg-white border-b-2 border-black overflow-hidden">
      {/* 
        Responsive layout architecture:
        Desktop: 12-column grid with left content and right 3D visual.
        Mobile: Single column matching exact required hierarchy:
        JM/CZ -> JM MADHU SUDHUON CZ_ -> ROLE -> DESCRIPTION -> CTA -> 3D VISUAL
      */}
      <div className="grid grid-cols-1 lg:grid-cols-12 min-h-[540px]">
        {/* Left Column: Personal Identity & Typography */}
        <div className="lg:col-span-7 p-5 sm:p-8 md:p-12 xl:p-14 flex flex-col justify-between border-b-2 lg:border-b-0 lg:border-r-2 border-black">
          <div>
            {/* 1. SMALL LABEL: JM/CZ */}
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-[#1d4ed8] text-white font-mono text-xs font-bold tracking-wider mb-4 sm:mb-6 border border-black shadow-[2px_2px_0px_#000000]">
              <span>JM/CZ</span>
            </div>

            {/* 2. MAIN HEADING: JM MADHU SUDHUON CZ_ */}
            <h1 className="text-3xl sm:text-4xl md:text-5xl xl:text-6xl font-mono font-extrabold tracking-tight text-black leading-[1.08] uppercase mb-4 break-words">
              {profile.nameLine1}
              <br />
              {profile.nameLine2}
              <span 
                className={`text-[#1d4ed8] ${cursorVisible ? 'opacity-100' : 'opacity-0'} transition-opacity select-none motion-reduce:opacity-100`}
                aria-hidden="true"
              >
                _
              </span>
            </h1>

            {/* 3. SUBHEADING: DEVELOPER • PROGRAMMER • CREATOR */}
            <div className="text-xs sm:text-sm font-mono font-bold tracking-widest text-[#1d4ed8] uppercase mb-4 flex flex-wrap items-center gap-1.5">
              <span>DEVELOPER • PROGRAMMER • CREATOR</span>
            </div>

            {/* 4. SECONDARY DESCRIPTION */}
            <p className="text-sm sm:text-base md:text-lg font-display font-bold tracking-tight text-slate-900 leading-snug max-w-xl mb-6 text-balance">
              I build software, explore AI/ML, analyze projects and turn ideas into real digital products.
            </p>

            {/* 5. Primary CTA Buttons: Touch-friendly (>=44px), Accessible */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 sm:gap-4 mb-6 sm:mb-8">
              <button
                onClick={onViewProjects}
                className="min-h-[48px] flex items-center justify-center gap-2 px-6 py-3.5 bg-[#1d4ed8] hover:bg-[#1e40af] text-white font-mono text-xs sm:text-sm font-bold tracking-wide border-2 border-black shadow-[3px_3px_0px_#000000] active:translate-x-0.5 active:translate-y-0.5 active:shadow-[1px_1px_0px_#000000] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-black transition-all cursor-pointer select-none group"
              >
                <span>VIEW MY WORK</span>
                <ArrowUpRight className="w-4 h-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
              </button>

              <button
                onClick={handleDownloadCvClick}
                className="min-h-[48px] flex items-center justify-center gap-2 px-6 py-3.5 bg-white hover:bg-slate-100 text-black font-mono text-xs sm:text-sm font-bold tracking-wide border-2 border-black shadow-[3px_3px_0px_#000000] active:translate-x-0.5 active:translate-y-0.5 active:shadow-[1px_1px_0px_#000000] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-black transition-all cursor-pointer select-none"
              >
                <span>DOWNLOAD CV</span>
                <Download className="w-4 h-4" />
              </button>

              {onDownloadApp && (
                <button
                  onClick={onDownloadApp}
                  className="min-h-[48px] flex items-center justify-center gap-2 px-6 py-3.5 bg-[#d4fc35] hover:bg-[#bef264] text-black font-mono text-xs sm:text-sm font-bold tracking-wide border-2 border-black shadow-[3px_3px_0px_#000000] active:translate-x-0.5 active:translate-y-0.5 active:shadow-[1px_1px_0px_#000000] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-black transition-all cursor-pointer select-none"
                  title="Download Android Portfolio App"
                >
                  <Smartphone className="w-4 h-4 text-black" />
                  <span>DOWNLOAD APP</span>
                </button>
              )}
            </div>
          </div>

          {/* Social Links Row (Driven by editable socialsData) */}
          <div className="pt-5 border-t border-slate-200 flex flex-wrap items-center gap-2 sm:gap-3">
            {/* Direct Email Copy Button */}
            <button
              onClick={handleCopyEmail}
              aria-label={`Copy email address: ${profile.email}`}
              className="w-10 h-10 border-2 border-black flex items-center justify-center bg-white hover:bg-[#d4fc35] transition-colors shadow-[2px_2px_0px_#000000] cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-black"
              title={`Copy: ${profile.email}`}
            >
              {copiedEmail ? (
                <Check className="w-5 h-5 text-emerald-600" />
              ) : (
                <Mail className="w-5 h-5 text-black" />
              )}
            </button>

            {/* GitHub */}
            {githubSocial && (
              <a
                href={githubSocial.url || '#'}
                onClick={(e) => handleSocialClick(e, githubSocial.label, githubSocial.url, githubSocial.placeholder)}
                target={githubSocial.url ? '_blank' : '_self'}
                rel="noreferrer"
                aria-label="GitHub Profile"
                className="w-10 h-10 border-2 border-black flex items-center justify-center bg-white hover:bg-slate-100 transition-colors shadow-[2px_2px_0px_#000000] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-black"
                title={githubSocial.url ? "GitHub Profile" : "Configure GitHub in src/data/socials.js"}
              >
                <Github className="w-5 h-5 text-black" />
              </a>
            )}

            {/* Instagram */}
            {instagramSocial && (
              <a
                href={instagramSocial.url || '#'}
                onClick={(e) => handleSocialClick(e, instagramSocial.label, instagramSocial.url, instagramSocial.placeholder)}
                target={instagramSocial.url ? '_blank' : '_self'}
                rel="noopener noreferrer"
                aria-label="Instagram Profile"
                className="w-10 h-10 border-2 border-black flex items-center justify-center bg-white hover:bg-slate-100 transition-colors shadow-[2px_2px_0px_#000000] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-black"
                title={instagramSocial.url ? "Instagram Profile" : "Configure Instagram in src/data/socials.js"}
              >
                <Instagram className="w-5 h-5 text-black" />
              </a>
            )}

            {/* Facebook */}
            {facebookSocial && (
              <a
                href={facebookSocial.url || '#'}
                onClick={(e) => handleSocialClick(e, facebookSocial.label, facebookSocial.url, facebookSocial.placeholder)}
                target={facebookSocial.url ? '_blank' : '_self'}
                rel="noopener noreferrer"
                aria-label="Facebook Profile"
                className="w-10 h-10 border-2 border-black flex items-center justify-center bg-white hover:bg-slate-100 transition-colors shadow-[2px_2px_0px_#000000] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-black"
                title={facebookSocial.url ? "Facebook Profile" : "Configure Facebook in src/data/socials.js"}
              >
                <Facebook className="w-5 h-5 text-black" />
              </a>
            )}

            {/* X / Twitter */}
            {twitterSocial && (
              <a
                href={twitterSocial.url || '#'}
                onClick={(e) => handleSocialClick(e, twitterSocial.label, twitterSocial.url, twitterSocial.placeholder)}
                target={twitterSocial.url ? '_blank' : '_self'}
                rel="noopener noreferrer"
                aria-label="X / Twitter Profile"
                className="w-10 h-10 border-2 border-black flex items-center justify-center bg-white hover:bg-slate-100 transition-colors shadow-[2px_2px_0px_#000000] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-black"
                title={twitterSocial.url ? "X / Twitter Profile" : "Configure Twitter in src/data/socials.js"}
              >
                <Twitter className="w-5 h-5 text-black" />
              </a>
            )}

            {copiedEmail && (
              <span className="font-mono text-xs text-emerald-700 font-bold ml-1 animate-fade-in bg-emerald-50 px-2 py-1 border border-emerald-300">
                Email copied!
              </span>
            )}

            {socialNotice && (
              <span className="font-mono text-xs text-blue-900 font-bold ml-1 animate-fade-in bg-blue-50 px-2 py-1 border border-blue-300">
                {socialNotice}
              </span>
            )}
          </div>
        </div>

        {/* Right Column: Isometric 3D Visual + Side Technical Ribbon */}
        <div className="lg:col-span-5 relative flex items-stretch border-t-2 lg:border-t-0 border-black bg-[#fafbfc]">
          {/* Main 3D Canvas Container */}
          <div className="flex-1 p-4 sm:p-6 md:p-8 flex items-center justify-center overflow-hidden">
            <HeroIsometricCluster className="py-2 sm:py-4 max-w-[420px] sm:max-w-[520px]" />
          </div>

          {/* Right Border Vertical Ribbon */}
          <div 
            onClick={onOpenConnect}
            className="w-9 sm:w-11 bg-white border-l-2 border-black flex items-center justify-center hover:bg-[#d4fc35] transition-colors cursor-pointer select-none group"
            title="Click to discuss a project or collaboration"
          >
            <div className="rotate-90 whitespace-nowrap font-mono font-extrabold text-[9px] sm:text-[11px] tracking-widest text-[#1d4ed8] group-hover:text-black transition-colors flex items-center gap-2">
              <span>EXPLORING IDEAS &amp; CODE</span>
              <span className="w-1.5 h-1.5 bg-[#1d4ed8] group-hover:bg-black rounded-full inline-block motion-safe:animate-pulse" aria-hidden="true" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
