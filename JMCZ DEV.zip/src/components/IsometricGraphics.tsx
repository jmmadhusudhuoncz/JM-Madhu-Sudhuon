import React from 'react';

/**
 * Pixel Face Avatar (From Section 03/ ABOUT ME)
 * 8-bit smiley face with solid black pixels and a bold royal blue shadow block
 */
export const PixelFace: React.FC<{ className?: string }> = ({ className = 'w-24 h-24' }) => {
  return (
    <div className={`relative ${className} select-none`}>
      {/* Royal blue offset drop-shadow block */}
      <div className="absolute right-0 bottom-0 w-16 h-16 bg-[#1d4ed8] translate-x-2 translate-y-2 pointer-events-none" />
      
      {/* Main white pixel face card */}
      <div className="relative w-full h-full bg-white border-2 border-black flex items-center justify-center p-2 shadow-[2px_2px_0px_#000000]">
        <svg
          viewBox="0 0 16 16"
          className="w-16 h-16"
          shapeRendering="crispEdges"
        >
          {/* Eyes */}
          <rect x="3" y="5" width="2" height="3" fill="#000000" />
          <rect x="11" y="5" width="2" height="3" fill="#000000" />
          
          {/* Smile mouth */}
          <rect x="4" y="11" width="2" height="2" fill="#000000" />
          <rect x="6" y="12" width="4" height="2" fill="#000000" />
          <rect x="10" y="11" width="2" height="2" fill="#000000" />
          
          {/* Small nose dot */}
          <rect x="7.5" y="8" width="1" height="1" fill="#000000" />
        </svg>
      </div>
    </div>
  );
};

/**
 * Hero Isometric 3D Architecture Graphic
 * Engineering, Software, AI/ML and Space technical exploration isometric visual.
 * Features modular technical nodes, orbital telemetry marks, circuitry bus lines,
 * and precision isometric blocks with cobalt blue and subtle lime accents.
 */
export const HeroIsometricCluster: React.FC<{ className?: string }> = ({ className = '' }) => {
  return (
    <div 
      aria-hidden="true" 
      className={`relative w-full h-full flex items-center justify-center select-none motion-reduce:transition-none ${className}`}
    >
      {/* Telemetry coordinate marks */}
      <div className="absolute top-2 left-6 font-mono text-[9px] text-slate-400 font-bold tracking-widest hidden sm:block">
        SYS.AI_CORE // [COORD: 32.4°N, 14.2°E]
      </div>

      <div className="absolute bottom-3 right-6 font-mono text-[9px] text-slate-400 font-bold tracking-widest hidden sm:block">
        ORBIT_VEC: 7.68 KM/S · TELEMETRY_OK
      </div>

      {/* Decorative dot matrix top right */}
      <div className="absolute top-6 right-10 grid grid-cols-4 gap-2 opacity-60">
        {Array.from({ length: 16 }).map((_, i) => (
          <div key={i} className="w-1 h-1 bg-black rounded-full" />
        ))}
      </div>

      {/* Decorative neural matrix top left */}
      <div className="absolute top-10 left-12 grid grid-cols-4 gap-2 opacity-40">
        {Array.from({ length: 16 }).map((_, i) => (
          <div key={i} className="w-1 h-1 bg-[#1d4ed8] rounded-full" />
        ))}
      </div>

      {/* Small floating blue tensor indicator */}
      <div className="absolute top-8 left-1/3 w-3 h-3 bg-[#1d4ed8] border border-black shadow-[1px_1px_0px_#000000]" />

      {/* Floating engineering cross marker */}
      <div className="absolute top-10 right-6 text-xl font-mono text-black font-light">+</div>

      {/* Isometric SVG Canvas */}
      <svg
        viewBox="0 0 620 540"
        className="w-full h-auto max-w-[560px] drop-shadow-sm"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <linearGradient id="blueGlow" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#2563eb" />
            <stop offset="100%" stopColor="#1d4ed8" />
          </linearGradient>
          <pattern id="gridPattern" width="16" height="16" patternUnits="userSpaceOnUse">
            <path d="M 16 0 L 0 0 0 16" fill="none" stroke="#e2e8f0" strokeWidth="0.8" />
          </pattern>
        </defs>

        {/* --- ORBITAL TRAJECTORY / SPACE EXPLORATION ELLIPSE --- */}
        <ellipse 
          cx="380" 
          cy="260" 
          rx="210" 
          ry="110" 
          stroke="#1d4ed8" 
          strokeWidth="1.2" 
          strokeDasharray="4 6" 
          opacity="0.35" 
          transform="rotate(-18 380 260)"
        />

        {/* Small orbital satellite marker */}
        <circle cx="560" cy="205" r="3.5" fill="#1d4ed8" />
        <line x1="560" y1="205" x2="575" y2="190" stroke="#000000" strokeWidth="1" />
        <rect x="575" y="184" width="28" height="12" fill="#ffffff" stroke="#000000" strokeWidth="1" />
        <text x="578" y="193" fill="#000000" fontSize="7" fontFamily="monospace" fontWeight="bold">SAT.01</text>

        {/* --- GROUND SHADOW / BASE WIREFRAME --- */}
        <polygon points="340,490 580,380 440,290 200,390" fill="#000000" opacity="0.08" />

        {/* --- FLOATING COMPUTING CUBE (Lime / Yellow top) on left --- */}
        <g className="transition-transform duration-500 hover:-translate-y-2 cursor-pointer">
          {/* Top Face (Lime Green) */}
          <polygon
            points="240,150 280,128 320,150 280,172"
            fill="#d4fc35"
            stroke="#000000"
            strokeWidth="2.5"
            strokeLinejoin="round"
          />
          {/* Left Face (Dark / Code Node) */}
          <polygon
            points="240,150 280,172 280,215 240,192"
            fill="#0f172a"
            stroke="#000000"
            strokeWidth="2.5"
            strokeLinejoin="round"
          />
          {/* Code node syntax on side */}
          <text x="248" y="188" fill="#d4fc35" fontSize="9" fontFamily="monospace" fontWeight="bold">&lt;/&gt;</text>
          {/* Right Face (White) */}
          <polygon
            points="280,172 320,150 320,192 280,215"
            fill="#ffffff"
            stroke="#000000"
            strokeWidth="2.5"
            strokeLinejoin="round"
          />
        </g>

        {/* --- MAIN ISOMETRIC STRUCTURE --- */}
        
        {/* Cube on Top-most tier (AI Core Node) */}
        <polygon points="410,40 450,20 490,40 450,62" fill="#ffffff" stroke="#000000" strokeWidth="2.5" />
        <polygon points="410,40 450,62 450,105 410,82" fill="#000000" stroke="#000000" strokeWidth="2.5" />
        <polygon points="450,62 490,40 490,82 450,105" fill="#f8fafc" stroke="#000000" strokeWidth="2.5" />
        <circle cx="450" cy="41" r="4" fill="#1d4ed8" />

        {/* Upper Left Cube (Cobalt Blue Face Accent) */}
        <polygon points="330,85 370,62 410,85 370,108" fill="#1d4ed8" stroke="#000000" strokeWidth="2.5" />
        <polygon points="330,85 370,108 370,150 330,128" fill="#ffffff" stroke="#000000" strokeWidth="2.5" />
        <polygon points="370,108 410,85 410,128 370,150" fill="#000000" stroke="#000000" strokeWidth="2.5" />

        {/* Upper Middle Mega-Block */}
        <polygon points="370,108 450,62 530,108 450,155" fill="#ffffff" stroke="#000000" strokeWidth="2.5" />
        {/* Subtle grid on upper platform */}
        <line x1="410" y1="85" x2="490" y2="131" stroke="#cbd5e1" strokeWidth="1.5" />
        <line x1="450" y1="108" x2="410" y2="131" stroke="#cbd5e1" strokeWidth="1.5" />
        
        {/* Blue Accent Cube on upper right */}
        <polygon points="490,82 530,60 570,82 530,105" fill="#d4fc35" stroke="#000000" strokeWidth="2.5" />
        <polygon points="530,105 570,82 570,125 530,148" fill="#1d4ed8" stroke="#000000" strokeWidth="2.5" />

        {/* Center Back Portal Block */}
        <polygon points="450,155 530,108 530,225 450,270" fill="#ffffff" stroke="#000000" strokeWidth="2.5" />
        {/* Blue Doorway Cutout inside Center Back */}
        <polygon points="485,160 510,145 510,205 485,220" fill="#1d4ed8" stroke="#000000" strokeWidth="2" />

        {/* Center Left Pillar (Pure Solid Black Shadow Face) */}
        <polygon points="350,170 390,148 430,170 390,192" fill="#ffffff" stroke="#000000" strokeWidth="2.5" />
        <polygon points="350,170 390,192 390,265 350,242" fill="#000000" stroke="#000000" strokeWidth="2.5" />
        <polygon points="390,192 430,170 430,242 390,265" fill="#ffffff" stroke="#000000" strokeWidth="2.5" />

        {/* Lower Left Prominent Block with Big Cobalt Blue Face */}
        <polygon points="330,210 390,175 450,210 390,245" fill="#ffffff" stroke="#000000" strokeWidth="2.5" />
        {/* Royal Blue Front Face */}
        <polygon points="330,210 390,245 390,325 330,290" fill="#1d4ed8" stroke="#000000" strokeWidth="2.5" />
        {/* Circuit bus traces across blue face */}
        <line x1="345" y1="230" x2="375" y2="248" stroke="#ffffff" strokeWidth="1.5" />
        <circle cx="375" cy="248" r="2.5" fill="#d4fc35" />
        <line x1="375" y1="248" x2="375" y2="280" stroke="#ffffff" strokeWidth="1.5" />

        {/* Crisp White Right Face */}
        <polygon points="390,245 450,210 450,290 390,325" fill="#f8fafc" stroke="#000000" strokeWidth="2.5" />

        {/* Bottom Left Extension (Solid White Top & Blue Face) */}
        <polygon points="290,232 330,210 370,232 330,255" fill="#ffffff" stroke="#000000" strokeWidth="2.5" />
        <polygon points="290,232 330,255 330,300 290,278" fill="#1d4ed8" stroke="#000000" strokeWidth="2.5" />
        <polygon points="330,255 370,232 370,278 330,300" fill="#ffffff" stroke="#000000" strokeWidth="2.5" />

        {/* Central Foundation Block (Black Face Front) */}
        <polygon points="390,265 470,220 510,242 430,290" fill="#ffffff" stroke="#000000" strokeWidth="2.5" />
        <polygon points="430,290 470,268 470,350 430,370" fill="#000000" stroke="#000000" strokeWidth="2.5" />
        <polygon points="470,268 510,242 510,325 470,350" fill="#ffffff" stroke="#000000" strokeWidth="2.5" />

        {/* --- STAIRCASE STRUCTURE ON RIGHT --- */}
        {/* Step 1 */}
        <polygon points="470,240 500,222 520,234 490,252" fill="#ffffff" stroke="#000000" strokeWidth="2" />
        <polygon points="490,252 520,234 520,246 490,264" fill="#e2e8f0" stroke="#000000" strokeWidth="2" />

        {/* Step 2 */}
        <polygon points="490,264 520,246 540,258 510,276" fill="#ffffff" stroke="#000000" strokeWidth="2" />
        <polygon points="510,276 540,258 540,270 510,288" fill="#e2e8f0" stroke="#000000" strokeWidth="2" />

        {/* Step 3 */}
        <polygon points="510,288 540,270 560,282 530,300" fill="#ffffff" stroke="#000000" strokeWidth="2" />
        <polygon points="530,300 560,282 560,294 530,312" fill="#e2e8f0" stroke="#000000" strokeWidth="2" />

        {/* Step 4 */}
        <polygon points="530,312 560,294 580,306 550,324" fill="#ffffff" stroke="#000000" strokeWidth="2" />
        <polygon points="550,324 580,306 580,318 550,336" fill="#e2e8f0" stroke="#000000" strokeWidth="2" />

        {/* Staircase Base Platform extending out */}
        <polygon points="550,336 580,318 630,348 600,366" fill="#ffffff" stroke="#000000" strokeWidth="2.5" />
        <polygon points="550,336 600,366 600,395 550,365" fill="#f8fafc" stroke="#000000" strokeWidth="2.5" />
        <polygon points="600,366 630,348 630,378 600,395" fill="#e2e8f0" stroke="#000000" strokeWidth="2.5" />

        {/* Small isolated steps at front right */}
        <polygon points="360,370 395,350 415,362 380,382" fill="#ffffff" stroke="#000000" strokeWidth="2" />
        <polygon points="360,370 380,382 380,395 360,383" fill="#000000" stroke="#000000" strokeWidth="2" />

        {/* Floating Wireframe Cube on bottom right */}
        <polygon points="260,110 290,92 320,110 290,128" fill="none" stroke="#000000" strokeWidth="1.5" strokeDasharray="3 3" />
        <line x1="260" y1="110" x2="260" y2="135" stroke="#000000" strokeWidth="1.5" strokeDasharray="3 3" />
        <line x1="290" y1="128" x2="290" y2="153" stroke="#000000" strokeWidth="1.5" strokeDasharray="3 3" />
        <line x1="320" y1="110" x2="320" y2="135" stroke="#000000" strokeWidth="1.5" strokeDasharray="3 3" />
      </svg>
    </div>
  );
};

/**
 * Experience Section Isometric Cubes Cluster (Bottom Left of 04/ EXPERIENCE)
 */
export const ExperienceIsometricCluster: React.FC<{ className?: string }> = ({ className = '' }) => {
  return (
    <div className={`relative select-none ${className}`}>
      {/* Decorative dots */}
      <div className="absolute top-0 left-0 grid grid-cols-3 gap-1.5 opacity-60">
        {Array.from({ length: 9 }).map((_, i) => (
          <div key={i} className="w-1 h-1 bg-black rounded-full" />
        ))}
      </div>

      <svg viewBox="0 0 160 160" className="w-28 h-28" fill="none">
        {/* Top Cube (Blue Front) */}
        <polygon points="75,25 95,12 115,25 95,38" fill="#ffffff" stroke="#000000" strokeWidth="2" />
        <polygon points="75,25 95,38 95,65 75,52" fill="#1d4ed8" stroke="#000000" strokeWidth="2" />
        <polygon points="95,38 115,25 115,52 95,65" fill="#000000" stroke="#000000" strokeWidth="2" />

        {/* Left Cube (Lime Face Accent) */}
        <polygon points="50,60 70,47 90,60 70,73" fill="#d4fc35" stroke="#000000" strokeWidth="2" />
        <polygon points="50,60 70,73 70,105 50,92" fill="#ffffff" stroke="#000000" strokeWidth="2" />
        <polygon points="70,73 90,60 90,92 70,105" fill="#d4fc35" stroke="#000000" strokeWidth="2" />

        {/* Right Base Cube (White & Dark) */}
        <polygon points="90,60 110,47 130,60 110,73" fill="#ffffff" stroke="#000000" strokeWidth="2" />
        <polygon points="90,60 110,73 110,105 90,92" fill="#0f172a" stroke="#000000" strokeWidth="2" />
        <polygon points="110,73 130,60 130,92 110,105" fill="#ffffff" stroke="#000000" strokeWidth="2" />

        {/* Front Bottom Cube (Cobalt Blue Face) */}
        <polygon points="30,85 50,72 70,85 50,98" fill="#ffffff" stroke="#000000" strokeWidth="2" />
        <polygon points="30,85 50,98 50,125 30,112" fill="#1d4ed8" stroke="#000000" strokeWidth="2" />
        <polygon points="50,98 70,85 70,112 50,125" fill="#ffffff" stroke="#000000" strokeWidth="2" />
      </svg>
    </div>
  );
};

/**
 * Footer Isometric Block Cluster (Row 5 center block)
 */
export const FooterIsometricCluster: React.FC<{ className?: string }> = ({ className = '' }) => {
  return (
    <div className={`relative flex items-center justify-center select-none ${className}`}>
      {/* Mini Dot Pattern */}
      <div className="absolute top-2 right-4 grid grid-cols-3 gap-1.5 opacity-50">
        {Array.from({ length: 9 }).map((_, i) => (
          <div key={i} className="w-1 h-1 bg-black rounded-full" />
        ))}
      </div>

      <svg viewBox="0 0 180 160" className="w-36 h-32" fill="none">
        {/* Floating small blue cube */}
        <rect x="25" y="45" width="8" height="8" fill="#1d4ed8" />

        {/* Floating mini lime cube */}
        <polygon points="50,115 58,110 66,115 58,120" fill="#d4fc35" stroke="#000000" strokeWidth="1.5" />
        <polygon points="50,115 58,120 58,130 50,125" fill="#000000" stroke="#000000" strokeWidth="1.5" />
        <polygon points="58,120 66,115 66,125 58,130" fill="#ffffff" stroke="#000000" strokeWidth="1.5" />

        {/* Tall Isometric Structure */}
        {/* Top cube */}
        <polygon points="80,25 105,10 130,25 105,40" fill="#ffffff" stroke="#000000" strokeWidth="2" />
        <polygon points="80,25 105,40 105,70 80,55" fill="#ffffff" stroke="#000000" strokeWidth="2" />
        <polygon points="105,40 130,25 130,55 105,70" fill="#1d4ed8" stroke="#000000" strokeWidth="2" />

        {/* Center Base Block */}
        <polygon points="60,60 85,45 110,60 85,75" fill="#ffffff" stroke="#000000" strokeWidth="2" />
        <polygon points="60,60 85,75 85,115 60,100" fill="#1d4ed8" stroke="#000000" strokeWidth="2" />
        <polygon points="85,75 110,60 110,100 85,115" fill="#ffffff" stroke="#000000" strokeWidth="2" />

        {/* Right Stepping Block */}
        <polygon points="105,70 130,55 150,67 125,82" fill="#ffffff" stroke="#000000" strokeWidth="2" />
        <polygon points="105,70 125,82 125,120 105,108" fill="#000000" stroke="#000000" strokeWidth="2" />
        <polygon points="125,82 150,67 150,105 125,120" fill="#f8fafc" stroke="#000000" strokeWidth="2" />

        {/* Bottom Left Connected Cube */}
        <polygon points="40,85 65,70 90,85 65,100" fill="#ffffff" stroke="#000000" strokeWidth="2" />
        <polygon points="40,85 65,100 65,130 40,115" fill="#f8fafc" stroke="#000000" strokeWidth="2" />
        <polygon points="65,100 90,85 90,115 65,130" fill="#e2e8f0" stroke="#000000" strokeWidth="2" />
      </svg>
    </div>
  );
};
