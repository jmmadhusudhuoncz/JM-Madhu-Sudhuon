import React, { useState } from 'react';
import { Download, ArrowUpRight, Smartphone, ShieldCheck, Info, CheckCircle2, Clock, Github, ExternalLink, FileArchive } from 'lucide-react';
import { publishedAppsData, PublishedApp, getDownloadButtonLabel } from '../data/publishedApps';
import { resolveStorageDownloadUrl } from '../services/firebase';
import { AppDetailsModal } from './Modals';

interface AppDownloadSectionProps {
  onOpenDetails?: (app?: PublishedApp) => void;
  apps?: PublishedApp[];
}

export const AppDownloadSection: React.FC<AppDownloadSectionProps> = ({
  onOpenDetails,
  apps = publishedAppsData,
}) => {
  const [selectedApp, setSelectedApp] = useState<PublishedApp | null>(null);

  const primaryApp = apps[0];
  const allApps = apps.filter((a) => a.showInDownloads !== false);

  const handleDownloadClick = async (e: React.MouseEvent, filePath: string) => {
    if (filePath && (filePath.startsWith('gs://') || filePath.startsWith('apps/') || filePath.startsWith('media/'))) {
      e.preventDefault();
      const resolved = await resolveStorageDownloadUrl(filePath);
      if (resolved) {
        const link = document.createElement('a');
        link.href = resolved;
        link.target = '_blank';
        link.rel = 'noopener noreferrer';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      }
    }
  };

  const handleOpenAppDetails = (app: PublishedApp) => {
    if (onOpenDetails) {
      onOpenDetails(app);
    } else {
      setSelectedApp(app);
    }
  };

  return (
    <section id="app-download" className="w-full bg-white border-b-2 border-black font-mono">
      {/* Top Banner Bar */}
      <div className="border-b-2 border-black p-4 sm:p-6 md:p-8 bg-slate-50 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5 mb-1.5">
            <div className="w-2 h-6 sm:h-7 bg-[#1d4ed8]" />
            <span className="text-xs sm:text-sm font-extrabold tracking-widest text-[#1d4ed8] uppercase">
              GET THE JM/CZ APP
            </span>
          </div>
          <h2 className="text-xl sm:text-3xl font-mono font-black tracking-tight text-black uppercase">
            JM/CZ PORTFOLIO APP
          </h2>
          <p className="font-mono text-xs sm:text-sm text-slate-700 max-w-2xl mt-1 leading-relaxed">
            {primaryApp?.description || 'Get the JM/CZ portfolio experience on Android.'}
          </p>
        </div>

        <div className="flex items-center gap-2 self-start md:self-auto">
          <span className="px-3 py-1 bg-white border border-black text-black text-xs font-bold shadow-[2px_2px_0px_#000000]">
            {primaryApp?.platform.toUpperCase() || 'ANDROID'}
          </span>
          <span className="px-3 py-1 bg-[#d4fc35] border border-black text-black text-xs font-black shadow-[2px_2px_0px_#000000]">
            VERSION {primaryApp?.version || '1.0.0'}
          </span>
        </div>
      </div>

      {/* Primary Featured App Download Area */}
      {primaryApp && (
        <div className="grid grid-cols-1 lg:grid-cols-12 divide-y-2 lg:divide-y-0 lg:divide-x-2 divide-black border-b-2 border-black">
          {/* Left Column: Primary Technical Download Card */}
          <div className="lg:col-span-5 p-5 sm:p-8 flex flex-col justify-between bg-white">
            <div className="space-y-4">
              <div className="p-5 sm:p-6 border-2 border-black bg-white shadow-[6px_6px_0px_#000000] relative">
                {/* Corner Accents */}
                <div className="absolute top-2 right-2 flex items-center gap-1.5">
                  <span className="w-2 h-2 bg-[#1d4ed8]" />
                  <span className="w-2 h-2 bg-[#d4fc35]" />
                  <span className="w-2 h-2 bg-black" />
                </div>

                <div className="flex items-center gap-2 mb-3">
                  <Smartphone className="w-5 h-5 text-[#1d4ed8]" />
                  <span className="text-[11px] font-extrabold tracking-wider text-slate-500 uppercase">
                    FEATURED RELEASE
                  </span>
                </div>

                <div className="space-y-1 mb-4">
                  <div className="text-2xl sm:text-3xl font-black text-black tracking-tight uppercase">
                    {primaryApp.name}
                  </div>
                  <div className="text-xs font-extrabold text-[#1d4ed8] uppercase tracking-wider">
                    {primaryApp.platform.toUpperCase()}
                  </div>
                  <div className="text-xs font-bold text-slate-700">
                    VERSION {primaryApp.version}
                  </div>
                </div>

                {/* File size & path info */}
                <div className="p-2.5 bg-slate-50 border border-slate-300 text-[11px] text-slate-600 mb-5 space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-black">FILE TYPE:</span>
                    <span className="text-slate-700">{primaryApp.fileType}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-black">APK SIZE:</span>
                    <span className="text-slate-500 italic">
                      {primaryApp.files[0]?.size || 'Not available until actual APK exists'}
                    </span>
                  </div>
                </div>

                {/* Primary Download / Coming Soon Button */}
                {primaryApp.status === 'available' && primaryApp.files[0]?.exists ? (
                  <a
                    href={primaryApp.files[0].path}
                    download={primaryApp.files[0].name}
                    onClick={(e) => handleDownloadClick(e, primaryApp.files[0].path)}
                    className="w-full min-h-[46px] px-4 py-3 bg-[#1d4ed8] hover:bg-[#1e40af] text-white font-mono font-bold text-xs sm:text-sm tracking-wide border-2 border-black shadow-[3px_3px_0px_#000000] active:translate-x-0.5 active:translate-y-0.5 active:shadow-[1px_1px_0px_#000000] flex items-center justify-center gap-2 cursor-pointer transition-all select-none"
                  >
                    <Download className="w-4 h-4" />
                    <span>DOWNLOAD FOR ANDROID ↓</span>
                  </a>
                ) : (
                  <div className="space-y-2">
                    <button
                      disabled
                      className="w-full min-h-[46px] px-4 py-3 bg-slate-100 text-slate-500 font-mono font-bold text-xs sm:text-sm tracking-wide border-2 border-slate-300 cursor-not-allowed flex items-center justify-center gap-2 select-none"
                    >
                      <Clock className="w-4 h-4 text-slate-400" />
                      <span>ANDROID APP COMING SOON</span>
                    </button>
                    <p className="text-[10px] text-slate-500 text-center">
                      Direct APK download will activate once the compiled release is deployed to <code className="bg-slate-100 px-1">{primaryApp.files[0]?.path || '/downloads/JM-CZ-Portfolio.apk'}</code>.
                    </p>
                  </div>
                )}
              </div>
            </div>

            {/* Secondary Action */}
            <div className="pt-4 flex items-center gap-3">
              <button
                onClick={() => handleOpenAppDetails(primaryApp)}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-white hover:bg-slate-100 text-black font-bold text-xs border border-black shadow-[2px_2px_0px_#000000] cursor-pointer transition-all active:scale-95"
              >
                <span>VIEW APP DETAILS</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>

              <span className="text-[10px] text-slate-500">
                Standalone Native Presentation Target
              </span>
            </div>
          </div>

          {/* Right Column: App Architecture & Features */}
          <div className="lg:col-span-7 p-5 sm:p-8 flex flex-col justify-between bg-slate-50">
            <div>
              <div className="flex items-center gap-2 mb-3">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span className="text-[11px] font-extrabold text-black uppercase tracking-wider">
                  NATIVE ANDROID INTEGRATION
                </span>
              </div>

              <p className="text-xs text-slate-700 leading-relaxed mb-5">
                The JM/CZ Android application provides a standalone, installable presentation target of the portfolio with native mobile device capabilities.
              </p>

              {/* Feature Highlights */}
              <div className="space-y-2.5 mb-6">
                {(primaryApp.features || []).map((feature, i) => (
                  <div
                    key={i}
                    className="p-3 bg-white border border-black shadow-[2px_2px_0px_#000000] flex items-start gap-2.5 text-xs text-slate-800"
                  >
                    <CheckCircle2 className="w-4 h-4 text-[#1d4ed8] shrink-0 mt-0.5" />
                    <span>{feature}</span>
                  </div>
                ))}
              </div>

              {/* Config Transparency Box */}
              <div className="p-3.5 bg-blue-50/70 border border-blue-200 text-[11px] space-y-1 text-slate-800">
                <div className="font-bold text-blue-900 flex items-center gap-1.5">
                  <Info className="w-3.5 h-3.5 text-blue-700" />
                  <span>ONE-STEP APP PUBLISHING SYSTEM</span>
                </div>
                <p className="text-slate-600 leading-normal">
                  All APK and Source ZIP distributions are registered in a centralized registry (<code className="bg-blue-100 text-blue-900 px-1">src/data/publishedApps.ts</code>). Every published app is automatically integrated into the App Downloads and Projects sections.
                </p>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-200 text-[10px] text-slate-500 flex flex-wrap items-center justify-between gap-2">
              <span>JM/CZ Portfolio · Android Native Distribution</span>
              <span>Version {primaryApp.version} · {primaryApp.category}</span>
            </div>
          </div>
        </div>
      )}

      {/* Additional Published Apps & Packages Section */}
      {allApps.length > 1 && (
        <div className="p-4 sm:p-6 md:p-8 bg-slate-100">
          <div className="mb-5 flex items-center justify-between">
            <div>
              <span className="text-[10px] font-extrabold text-slate-500 uppercase tracking-widest block">
                // PUBLISHED PACKAGES &amp; RELEASES
              </span>
              <h3 className="text-lg sm:text-xl font-black text-black uppercase">
                ALL AVAILABLE DOWNLOADS ({allApps.length})
              </h3>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {allApps.map((app) => {
              const apkFile = app.files.find((f) => f.type === 'APK');
              const zipFile = app.files.find((f) => f.type === 'ZIP');
              const otherFiles = app.files.filter((f) => f.type !== 'APK' && f.type !== 'ZIP');

              return (
                <div
                  key={app.id}
                  className="bg-white border-2 border-black p-5 flex flex-col justify-between shadow-[4px_4px_0px_#000000]"
                >
                  <div>
                    {/* Top Row: Platform + Version + Status */}
                    <div className="flex items-center justify-between gap-2 mb-2">
                      <span className="px-2 py-0.5 bg-[#d4fc35] border border-black text-black text-[10px] font-black">
                        {app.platform.toUpperCase()}
                      </span>
                      <span className="text-[10px] font-bold text-slate-500">
                        v{app.version}
                      </span>
                      <span
                        className={`px-1.5 py-0.5 text-[9px] font-bold border border-black uppercase ${
                          app.status === 'available'
                            ? 'bg-emerald-600 text-white'
                            : 'bg-slate-200 text-slate-700'
                        }`}
                      >
                        {app.status}
                      </span>
                    </div>

                    <h4 className="text-base sm:text-lg font-black text-black uppercase tracking-tight mb-1">
                      {app.name}
                    </h4>

                    <p className="text-xs text-slate-700 mb-3 line-clamp-2">
                      {app.description}
                    </p>

                    <div className="text-[10px] text-slate-500 font-bold mb-3">
                      FILE TYPE: <span className="text-black">{app.fileType}</span>
                    </div>
                  </div>

                  {/* Actions Row */}
                  <div className="pt-3 border-t border-slate-200 space-y-2">
                    {/* Primary Download Buttons */}
                    <div className="flex flex-col gap-1.5">
                      {apkFile && (
                        apkFile.exists && app.status === 'available' ? (
                          <a
                            href={apkFile.path}
                            download={apkFile.name}
                            onClick={(e) => handleDownloadClick(e, apkFile.path)}
                            className="w-full py-2 px-3 bg-[#1d4ed8] hover:bg-[#1e40af] text-white font-bold text-xs border border-black flex items-center justify-center gap-1.5 active:scale-95"
                          >
                            <Download className="w-3.5 h-3.5" />
                            <span>DOWNLOAD APK ↓</span>
                          </a>
                        ) : (
                          <button
                            disabled
                            className="w-full py-2 px-3 bg-slate-100 text-slate-400 font-bold text-xs border border-slate-300 flex items-center justify-center gap-1.5 cursor-not-allowed"
                          >
                            <Clock className="w-3.5 h-3.5" />
                            <span>APK COMING SOON</span>
                          </button>
                        )
                      )}

                      {zipFile && (
                        zipFile.exists && app.status === 'available' ? (
                          <a
                            href={zipFile.path}
                            download={zipFile.name}
                            onClick={(e) => handleDownloadClick(e, zipFile.path)}
                            className="w-full py-2 px-3 bg-[#d4fc35] hover:bg-[#bef264] text-black font-bold text-xs border border-black flex items-center justify-center gap-1.5 active:scale-95"
                          >
                            <FileArchive className="w-3.5 h-3.5" />
                            <span>DOWNLOAD SOURCE ZIP ↓</span>
                          </a>
                        ) : (
                          <button
                            disabled
                            className="w-full py-2 px-3 bg-slate-100 text-slate-400 font-bold text-xs border border-slate-300 flex items-center justify-center gap-1.5 cursor-not-allowed"
                          >
                            <Clock className="w-3.5 h-3.5" />
                            <span>SOURCE ZIP COMING SOON</span>
                          </button>
                        )
                      )}

                      {otherFiles.map((f, idx) => (
                        f.exists && app.status === 'available' ? (
                          <a
                            key={idx}
                            href={f.path}
                            download={f.name}
                            onClick={(e) => handleDownloadClick(e, f.path)}
                            className="w-full py-2 px-3 bg-white hover:bg-slate-100 text-black font-bold text-xs border border-black flex items-center justify-center gap-1.5 active:scale-95"
                          >
                            <Download className="w-3.5 h-3.5" />
                            <span>{getDownloadButtonLabel(f.type)}</span>
                          </a>
                        ) : null
                      ))}
                    </div>

                    {/* Secondary Navigation Row: VIEW DETAILS + External Links */}
                    <div className="flex items-center justify-between gap-1.5 pt-1">
                      <button
                        onClick={() => handleOpenAppDetails(app)}
                        className="px-2.5 py-1.5 bg-white hover:bg-slate-100 text-black font-bold text-[11px] border border-black flex items-center gap-1"
                      >
                        <span>VIEW DETAILS</span>
                        <ArrowUpRight className="w-3 h-3" />
                      </button>

                      <div className="flex items-center gap-1">
                        {app.github && (
                          <a
                            href={app.github}
                            target="_blank"
                            rel="noreferrer"
                            className="p-1.5 bg-white hover:bg-slate-100 text-black border border-black"
                            title="GitHub Repository"
                          >
                            <Github className="w-3.5 h-3.5" />
                          </a>
                        )}

                        {app.liveDemo && (
                          <a
                            href={app.liveDemo}
                            target="_blank"
                            rel="noreferrer"
                            className="p-1.5 bg-white hover:bg-slate-100 text-black border border-black"
                            title="Live Demo"
                          >
                            <ExternalLink className="w-3.5 h-3.5" />
                          </a>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* App Details Modal if triggered internally */}
      <AppDetailsModal
        app={selectedApp}
        onClose={() => setSelectedApp(null)}
      />
    </section>
  );
};
