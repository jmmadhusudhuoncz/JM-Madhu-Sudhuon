import React, { useState } from 'react';
import { ArrowUpRight, Menu, X, Smartphone } from 'lucide-react';
import { profile } from '../data/profile';
import { PWAInstallButton } from './PWAInstallButton';

interface NavigationProps {
  activeSection: string;
  onNavigate: (sectionId: string) => void;
  onOpenConnect: () => void;
}

export const Navigation: React.FC<NavigationProps> = ({
  activeSection,
  onNavigate,
  onOpenConnect,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { id: 'home', label: 'HOME' },
    { id: 'projects', label: 'PROJECTS' },
    { id: 'skills', label: 'SKILLS' },
    { id: 'capabilities', label: 'CAPABILITIES' },
    { id: 'certifications', label: 'CERTIFICATIONS' },
    { id: 'about', label: 'ABOUT' },
    { id: 'experience', label: 'JOURNEY' },
    { id: 'contact', label: 'CONTACT' },
    { id: 'app-download', label: 'APP' },
  ];

  const handleSelectNav = (id: string) => {
    onNavigate(id);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-white border-b-2 border-black">
      <div className="flex items-stretch justify-between h-14 md:h-16">
        {/* Brand Zone */}
        <div 
          onClick={() => handleSelectNav('home')}
          className="flex items-center gap-3 px-3 md:px-6 border-r-2 border-black cursor-pointer hover:bg-slate-50 transition-colors select-none"
        >
          {/* Modular grid logo icon */}
          <div className="flex flex-col gap-0.5">
            <div className="flex gap-0.5">
              <div className="w-2.5 h-2.5 bg-black" />
              <div className="w-2.5 h-2.5 bg-[#1d4ed8]" />
            </div>
            <div className="flex gap-0.5">
              <div className="w-2.5 h-2.5 border border-black bg-[#d4fc35]" />
              <div className="w-2.5 h-2.5 bg-black" />
            </div>
          </div>

          <div className="flex items-center gap-1.5 font-mono">
            <span className="text-xs md:text-sm font-black tracking-tight text-black">
              {profile.brand}
            </span>
            <span className="text-[10px] md:text-xs font-bold text-slate-500">
              —
            </span>
            <span className="text-[10px] md:text-xs font-bold tracking-wider text-slate-700">
              PORTFOLIO
            </span>
          </div>
        </div>

        {/* Desktop Navigation Tabs */}
        <nav className="hidden xl:flex items-stretch flex-1 divide-x-2 divide-black overflow-x-auto">
          {navItems.map((item) => {
            const isActive = activeSection === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleSelectNav(item.id)}
                className={`relative px-4 2xl:px-5 py-2 flex items-center justify-center font-mono text-xs font-bold tracking-wide transition-colors whitespace-nowrap select-none cursor-pointer ${
                  isActive
                    ? 'bg-[#1d4ed8] text-white'
                    : 'bg-white text-black hover:bg-slate-100'
                }`}
              >
                {item.label}
                {isActive && (
                  <span className="absolute bottom-0 left-0 right-0 h-1 bg-black" />
                )}
              </button>
            );
          })}
        </nav>

        {/* Tablet / Medium view horizontal scroll */}
        <div className="hidden md:flex xl:hidden items-center flex-1 justify-center px-2 divide-x divide-black overflow-x-auto text-[11px] font-mono">
          {navItems.map((item) => {
            const isActive = activeSection === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleSelectNav(item.id)}
                className={`px-3 py-1 font-bold whitespace-nowrap ${
                  isActive ? 'bg-[#1d4ed8] text-white' : 'text-slate-800 hover:bg-slate-100'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </div>

        {/* PWA Install Button & Mobile Hamburger toggle */}
        <div className="flex items-center">
          <div className="px-2 md:px-3 border-l-2 border-black h-full flex items-center">
            <PWAInstallButton />
          </div>

          <div className="flex md:hidden h-full">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="w-12 h-full flex items-center justify-center border-l-2 border-black hover:bg-slate-100 text-black cursor-pointer"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* DOWNLOAD APP Button */}
        <button
          onClick={() => handleSelectNav('app-download')}
          className="hidden sm:flex items-center gap-1.5 px-3 md:px-4 bg-white hover:bg-slate-100 active:bg-slate-200 text-black font-mono font-bold text-xs tracking-wide border-l-2 border-black transition-all cursor-pointer select-none whitespace-nowrap"
          title="Download Android App"
        >
          <Smartphone className="w-3.5 h-3.5 text-[#1d4ed8]" />
          <span>DOWNLOAD APP</span>
        </button>

        {/* Right CTA Button: LET'S CONNECT ↗ */}
        <button
          onClick={onOpenConnect}
          className="flex items-center gap-1.5 px-3 md:px-6 bg-[#d4fc35] hover:bg-[#bef264] active:bg-[#a3e635] text-black font-mono font-bold text-xs md:text-sm tracking-wide border-l-2 border-black transition-all cursor-pointer select-none group whitespace-nowrap"
        >
          <span>LET'S CONNECT</span>
          <ArrowUpRight className="w-4 h-4 md:w-5 md:h-5 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
        </button>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t-2 border-black bg-white divide-y divide-black font-mono text-xs animate-in slide-in-from-top-2 duration-150">
          {navItems.map((item) => {
            const isActive = activeSection === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleSelectNav(item.id)}
                className={`w-full py-3 px-4 text-left font-bold flex items-center justify-between ${
                  isActive ? 'bg-[#1d4ed8] text-white' : 'hover:bg-slate-50 text-black'
                }`}
              >
                <span>{item.label}</span>
                {isActive && <span className="w-2 h-2 bg-[#d4fc35]" />}
              </button>
            );
          })}
        </div>
      )}
    </header>
  );
};
