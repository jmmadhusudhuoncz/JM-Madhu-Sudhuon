import React, { useState } from 'react';
import {
  Send,
  CheckCircle2,
  AlertTriangle,
  Mail,
  Copy,
  Check,
  RefreshCw,
  ExternalLink,
  MessageSquare,
  Sparkles,
} from 'lucide-react';
import {
  ProjectSubmission,
  PROJECT_TYPES,
  RECIPIENT_EMAIL,
  validateSubmission,
  submitProjectRequest,
  generateMailtoUrl,
  generateWhatsAppUrl,
  copySubmissionToClipboard,
  formatEmailBody,
} from '../services/contactService';

interface ProjectRequestFormProps {
  onSuccessClose?: () => void;
  defaultProjectType?: string;
  isModal?: boolean;
}

type FormStatus = 'IDLE' | 'VALIDATING' | 'SENDING' | 'SUCCESS' | 'ERROR' | 'UNCONFIGURED';

export const ProjectRequestForm: React.FC<ProjectRequestFormProps> = ({
  onSuccessClose,
  defaultProjectType,
  isModal = false,
}) => {
  const [formData, setFormData] = useState<ProjectSubmission>({
    name: '',
    email: '',
    phone: '',
    projectType: defaultProjectType || 'Web Development',
    budget: '',
    preferredContact: 'Email',
    subject: '',
    message: '',
  });

  const [formStatus, setFormStatus] = useState<FormStatus>('IDLE');
  const [statusMessage, setStatusMessage] = useState<string>('');
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [copied, setCopied] = useState(false);
  const [lastSubmissionTime, setLastSubmissionTime] = useState<string>('');

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (fieldErrors[name]) {
      setFieldErrors((prev) => {
        const next = { ...prev };
        delete next[name];
        return next;
      });
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    setFormStatus('VALIDATING');
    const validation = validateSubmission(formData);
    if (!validation.valid) {
      setFieldErrors(validation.errors);
      setFormStatus('IDLE');
      return;
    }

    setFieldErrors({});
    setFormStatus('SENDING');

    const result = await submitProjectRequest(formData);

    if (result.success) {
      setFormStatus('SUCCESS');
      setStatusMessage(result.message);
      setLastSubmissionTime(result.timestamp || new Date().toISOString());
      if (onSuccessClose) {
        setTimeout(() => {
          // Keep open long enough for user to read or close manually
        }, 3000);
      }
    } else if (result.configured === false) {
      setFormStatus('UNCONFIGURED');
      setStatusMessage(result.message || 'Email delivery service is pending configuration.');
      setLastSubmissionTime(new Date().toISOString());
    } else {
      setFormStatus('ERROR');
      setStatusMessage(result.error || result.message || 'Delivery failed.');
      setLastSubmissionTime(new Date().toISOString());
    }
  };

  const handleCopy = async () => {
    const ok = await copySubmissionToClipboard(formData);
    if (ok) {
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  const handleReset = () => {
    setFormData({
      name: '',
      email: '',
      phone: '',
      projectType: 'Web Development',
      budget: '',
      preferredContact: 'Email',
      subject: '',
      message: '',
    });
    setFormStatus('IDLE');
    setStatusMessage('');
    setFieldErrors({});
  };

  return (
    <div className="font-mono text-xs text-black">
      {/* SUCCESS STATE */}
      {formStatus === 'SUCCESS' && (
        <div className="p-6 sm:p-8 text-center space-y-5 bg-white">
          <div className="w-14 h-14 mx-auto bg-emerald-500 text-white border-2 border-black flex items-center justify-center shadow-[3px_3px_0px_#000000]">
            <CheckCircle2 className="w-8 h-8" />
          </div>

          <div className="space-y-2">
            <span className="inline-block px-2.5 py-0.5 bg-[#d4fc35] text-black font-extrabold text-[10px] border border-black uppercase tracking-wider">
              DELIVERY CONFIRMED
            </span>
            <h3 className="text-lg sm:text-xl font-black text-black uppercase tracking-tight">
              REQUEST SENT SUCCESSFULLY
            </h3>
            <p className="text-slate-700 max-w-md mx-auto leading-relaxed text-xs">
              Your complete request has been delivered to{' '}
              <strong className="text-black underline">{RECIPIENT_EMAIL}</strong>. Madhu will review your requirements and follow up via{' '}
              <strong className="text-[#1d4ed8]">{formData.preferredContact}</strong>.
            </p>
          </div>

          {/* Submission Recap */}
          <div className="p-4 bg-slate-50 border-2 border-black text-left space-y-1.5 text-[11px] shadow-[2px_2px_0px_#000000] max-h-48 overflow-y-auto">
            <div className="font-bold text-black border-b border-slate-200 pb-1 flex justify-between">
              <span>SUMMARY OF DISPATCHED BRIEF</span>
              <span className="text-slate-500 font-normal">{new Date(lastSubmissionTime).toLocaleTimeString()}</span>
            </div>
            <div><strong>Client:</strong> {formData.name} ({formData.email})</div>
            <div><strong>Discipline:</strong> {formData.projectType}</div>
            <div><strong>Subject:</strong> {formData.subject}</div>
            {formData.budget && <div><strong>Budget:</strong> {formData.budget}</div>}
            {formData.phone && <div><strong>Phone / WA:</strong> {formData.phone}</div>}
          </div>

          <div className="pt-2 flex flex-wrap items-center justify-center gap-3">
            <button
              onClick={handleReset}
              className="px-4 py-2 bg-black hover:bg-slate-800 text-white font-bold border-2 border-black transition-colors cursor-pointer flex items-center gap-1.5 shadow-[2px_2px_0px_#000000]"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>SUBMIT ANOTHER REQUEST</span>
            </button>

            {onSuccessClose && (
              <button
                onClick={onSuccessClose}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-black font-bold border-2 border-black transition-colors cursor-pointer"
              >
                CLOSE
              </button>
            )}
          </div>
        </div>
      )}

      {/* UNCONFIGURED / PENDING EMAIL SERVICE STATE */}
      {formStatus === 'UNCONFIGURED' && (
        <div className="p-6 sm:p-8 space-y-5 bg-white">
          <div className="p-4 bg-amber-50 border-2 border-amber-600 space-y-2">
            <div className="flex items-center gap-2 text-amber-900 font-bold text-xs uppercase tracking-wider">
              <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
              <span>EMAIL SERVICE CONFIGURATION NOTICE</span>
            </div>
            <p className="text-slate-800 leading-relaxed text-[11px]">
              The backend email dispatch API is functioning, but <code className="bg-amber-100 px-1 py-0.5 font-bold text-amber-950">EMAIL_API_KEY</code> has not been configured in the server environment yet.
            </p>
            <p className="text-slate-700 leading-relaxed text-[11px]">
              <strong>No data has been lost!</strong> Your complete submission is prepared below. You can send it directly to <strong className="text-black">{RECIPIENT_EMAIL}</strong> using any of these 1-click delivery channels:
            </p>
          </div>

          {/* Action Fallbacks */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
            <a
              href={generateMailtoUrl(formData)}
              target="_blank"
              rel="noopener noreferrer"
              className="p-3 bg-[#1d4ed8] hover:bg-[#1e40af] text-white font-bold border-2 border-black shadow-[3px_3px_0px_#000000] flex items-center justify-center gap-2 cursor-pointer transition-transform hover:-translate-y-0.5"
            >
              <Mail className="w-4 h-4" />
              <span>OPEN IN GMAIL / MAIL APP</span>
            </a>

            <a
              href={generateWhatsAppUrl(formData)}
              target="_blank"
              rel="noopener noreferrer"
              className="p-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold border-2 border-black shadow-[3px_3px_0px_#000000] flex items-center justify-center gap-2 cursor-pointer transition-transform hover:-translate-y-0.5"
            >
              <MessageSquare className="w-4 h-4" />
              <span>SEND VIA WHATSAPP</span>
            </a>
          </div>

          <div className="flex items-center justify-between pt-2 border-t border-slate-200">
            <button
              onClick={handleCopy}
              className="px-3 py-2 bg-white hover:bg-slate-100 text-black font-bold border-2 border-black flex items-center gap-1.5 cursor-pointer shadow-[2px_2px_0px_#000000]"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'COPIED TO CLIPBOARD!' : 'COPY BRIEF TEXT'}</span>
            </button>

            <button
              onClick={() => setFormStatus('IDLE')}
              className="px-3 py-2 border border-slate-300 hover:bg-slate-100 text-slate-700 font-bold cursor-pointer"
            >
              EDIT FORM
            </button>
          </div>
        </div>
      )}

      {/* ERROR STATE */}
      {formStatus === 'ERROR' && (
        <div className="p-6 sm:p-8 space-y-5 bg-white">
          <div className="p-4 bg-red-50 border-2 border-red-600 space-y-2">
            <div className="flex items-center gap-2 text-red-900 font-bold text-xs uppercase tracking-wider">
              <AlertTriangle className="w-4 h-4 text-red-600 shrink-0" />
              <span>EMAIL SERVICE TEMPORARILY UNAVAILABLE</span>
            </div>
            <p className="text-slate-800 leading-relaxed text-[11px]">
              {statusMessage || 'Unable to deliver request via server-side email service at this moment.'}
            </p>
            <p className="text-slate-700 text-[11px]">
              Your project brief is safely preserved. Send it directly using the direct client buttons below:
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
            <a
              href={generateMailtoUrl(formData)}
              target="_blank"
              rel="noopener noreferrer"
              className="p-3 bg-[#1d4ed8] hover:bg-[#1e40af] text-white font-bold border-2 border-black shadow-[3px_3px_0px_#000000] flex items-center justify-center gap-2 cursor-pointer transition-transform hover:-translate-y-0.5"
            >
              <Mail className="w-4 h-4" />
              <span>OPEN IN GMAIL / MAIL APP</span>
            </a>

            <a
              href={generateWhatsAppUrl(formData)}
              target="_blank"
              rel="noopener noreferrer"
              className="p-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold border-2 border-black shadow-[3px_3px_0px_#000000] flex items-center justify-center gap-2 cursor-pointer transition-transform hover:-translate-y-0.5"
            >
              <MessageSquare className="w-4 h-4" />
              <span>SEND VIA WHATSAPP</span>
            </a>
          </div>

          <div className="flex items-center justify-between pt-2 border-t border-slate-200">
            <button
              onClick={handleCopy}
              className="px-3 py-2 bg-white hover:bg-slate-100 text-black font-bold border-2 border-black flex items-center gap-1.5 cursor-pointer shadow-[2px_2px_0px_#000000]"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'COPIED TO CLIPBOARD!' : 'COPY BRIEF TEXT'}</span>
            </button>

            <button
              onClick={() => setFormStatus('IDLE')}
              className="px-3 py-2 border border-slate-300 hover:bg-slate-100 text-slate-700 font-bold cursor-pointer"
            >
              EDIT FORM
            </button>
          </div>
        </div>
      )}

      {/* FORM INPUT STATE (IDLE / VALIDATING / SENDING) */}
      {(formStatus === 'IDLE' || formStatus === 'VALIDATING' || formStatus === 'SENDING') && (
        <form onSubmit={handleSubmit} className="p-5 sm:p-6 space-y-4">
          {/* Header banner inside modal */}
          <div className="p-3 bg-[#d4fc35]/40 border-2 border-black flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-black shrink-0" />
              <div>
                <strong className="text-black uppercase text-xs block">PROJECT INQUIRY &amp; ORDER SYSTEM</strong>
                <span className="text-[10px] text-slate-700">Direct transmission to {RECIPIENT_EMAIL}</span>
              </div>
            </div>
            <span className="text-[10px] font-bold px-2 py-0.5 bg-black text-white shrink-0">
              REAL DISPATCH
            </span>
          </div>

          {/* Anti-spam honeypot (hidden from human users) */}
          <div className="hidden" aria-hidden="true" style={{ display: 'none' }}>
            <label htmlFor="form_website_hp">Leave blank</label>
            <input
              id="form_website_hp"
              type="text"
              name="website"
              tabIndex={-1}
              autoComplete="off"
              value={(formData as any).website || ''}
              onChange={handleChange}
            />
          </div>

          {/* Row 1: Name & Email */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-black mb-1 uppercase tracking-wider">
                FULL NAME <span className="text-red-600">*</span>
              </label>
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleChange}
                placeholder="e.g. Alex Rivera"
                disabled={formStatus === 'SENDING'}
                className={`w-full p-2.5 bg-slate-50 border-2 ${
                  fieldErrors.name ? 'border-red-600 bg-red-50/40' : 'border-black'
                } outline-none focus:bg-white focus:border-[#1d4ed8] transition-colors`}
              />
              {fieldErrors.name && (
                <span className="text-[10px] text-red-600 font-bold mt-1 block">
                  {fieldErrors.name}
                </span>
              )}
            </div>

            <div>
              <label className="block font-bold text-black mb-1 uppercase tracking-wider">
                EMAIL ADDRESS <span className="text-red-600">*</span>
              </label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                placeholder="name@company.com"
                disabled={formStatus === 'SENDING'}
                className={`w-full p-2.5 bg-slate-50 border-2 ${
                  fieldErrors.email ? 'border-red-600 bg-red-50/40' : 'border-black'
                } outline-none focus:bg-white focus:border-[#1d4ed8] transition-colors`}
              />
              {fieldErrors.email && (
                <span className="text-[10px] text-red-600 font-bold mt-1 block">
                  {fieldErrors.email}
                </span>
              )}
            </div>
          </div>

          {/* Row 2: Project Type & Subject */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-black mb-1 uppercase tracking-wider">
                PROJECT TYPE <span className="text-red-600">*</span>
              </label>
              <select
                name="projectType"
                value={formData.projectType}
                onChange={handleChange}
                disabled={formStatus === 'SENDING'}
                className="w-full p-2.5 bg-slate-50 border-2 border-black outline-none focus:bg-white focus:border-[#1d4ed8] cursor-pointer"
              >
                {PROJECT_TYPES.map((pt) => (
                  <option key={pt} value={pt}>
                    {pt}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-bold text-black mb-1 uppercase tracking-wider">
                SUBJECT <span className="text-red-600">*</span>
              </label>
              <input
                type="text"
                name="subject"
                value={formData.subject}
                onChange={handleChange}
                placeholder="e.g. New Android App build / AI integration"
                disabled={formStatus === 'SENDING'}
                className={`w-full p-2.5 bg-slate-50 border-2 ${
                  fieldErrors.subject ? 'border-red-600 bg-red-50/40' : 'border-black'
                } outline-none focus:bg-white focus:border-[#1d4ed8] transition-colors`}
              />
              {fieldErrors.subject && (
                <span className="text-[10px] text-red-600 font-bold mt-1 block">
                  {fieldErrors.subject}
                </span>
              )}
            </div>
          </div>

          {/* Row 3: Optional Fields (Phone/WA, Budget, Preferred Contact) */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block font-bold text-slate-700 mb-1 uppercase tracking-wider">
                PHONE / WHATSAPP <span className="text-slate-400 font-normal">(OPTIONAL)</span>
              </label>
              <input
                type="text"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                placeholder="+1 555 0192 / +91 ..."
                disabled={formStatus === 'SENDING'}
                className="w-full p-2 bg-slate-50 border-2 border-black outline-none focus:bg-white focus:border-[#1d4ed8]"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1 uppercase tracking-wider">
                BUDGET <span className="text-slate-400 font-normal">(OPTIONAL)</span>
              </label>
              <input
                type="text"
                name="budget"
                value={formData.budget}
                onChange={handleChange}
                placeholder="e.g. $500 - $2,500"
                disabled={formStatus === 'SENDING'}
                className="w-full p-2 bg-slate-50 border-2 border-black outline-none focus:bg-white focus:border-[#1d4ed8]"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1 uppercase tracking-wider">
                PREFERRED CONTACT
              </label>
              <select
                name="preferredContact"
                value={formData.preferredContact}
                onChange={handleChange}
                disabled={formStatus === 'SENDING'}
                className="w-full p-2 bg-slate-50 border-2 border-black outline-none focus:bg-white focus:border-[#1d4ed8] cursor-pointer"
              >
                <option value="Email">Email</option>
                <option value="WhatsApp">WhatsApp</option>
              </select>
            </div>
          </div>

          {/* Row 4: Message */}
          <div>
            <label className="block font-bold text-black mb-1 uppercase tracking-wider">
              PROJECT REQUIREMENTS &amp; DETAILS <span className="text-red-600">*</span>
            </label>
            <textarea
              name="message"
              rows={4}
              value={formData.message}
              onChange={handleChange}
              placeholder="Tell me about your project, requirements, features, deadline, or anything else I should know."
              disabled={formStatus === 'SENDING'}
              className={`w-full p-2.5 bg-slate-50 border-2 ${
                fieldErrors.message ? 'border-red-600 bg-red-50/40' : 'border-black'
              } outline-none focus:bg-white focus:border-[#1d4ed8] transition-colors leading-relaxed`}
            />
            {fieldErrors.message && (
              <span className="text-[10px] text-red-600 font-bold mt-1 block">
                {fieldErrors.message}
              </span>
            )}
          </div>

          {/* Form Actions Footer */}
          <div className="pt-2 flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-t border-slate-200">
            <div className="text-[10px] text-slate-500 font-mono">
              <span>Recipient: <strong className="text-black">{RECIPIENT_EMAIL}</strong></span>
              <span className="hidden sm:inline"> • Reply-To enabled</span>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="submit"
                disabled={formStatus === 'SENDING'}
                className="w-full sm:w-auto px-6 py-2.5 bg-[#1d4ed8] hover:bg-[#1e40af] disabled:bg-slate-400 text-white font-bold border-2 border-black shadow-[3px_3px_0px_#000000] active:translate-x-0.5 active:translate-y-0.5 transition-all cursor-pointer flex items-center justify-center gap-2"
              >
                {formStatus === 'SENDING' ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>SENDING REQUEST...</span>
                  </>
                ) : (
                  <>
                    <span>SUBMIT PROJECT REQUEST</span>
                    <Send className="w-3.5 h-3.5" />
                  </>
                )}
              </button>
            </div>
          </div>
        </form>
      )}
    </div>
  );
};
