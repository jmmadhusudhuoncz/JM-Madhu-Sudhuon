import React, { useState } from 'react';
import { Download, Smartphone, X, Check, Laptop } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface PWAInstallButtonProps {
  className?: string;
  variant?: 'nav' | 'badge' | 'hero';
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({
  className = '',
  variant = 'nav',
}) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);
  const [showDesktopGuide, setShowDesktopGuide] = useState(false);
  const [installSuccess, setInstallSuccess] = useState(false);

  // If already running inside standalone PWA mode, hide or show installed badge
  if (isInstalled) {
    if (variant === 'nav') {
      return (
        <div className="hidden sm:inline-flex items-center gap-1.5 px-2 py-1 bg-emerald-50 border border-emerald-400 text-emerald-800 text-[10px] font-mono font-bold">
          <Check className="w-3 h-3 text-emerald-600" />
          <span>APP INSTALLED</span>
        </div>
      );
    }
    return null;
  }

  const handleInstallClick = async () => {
    const success = await install();
    if (success) {
      setInstallSuccess(true);
      setTimeout(() => setInstallSuccess(false), 4000);
    }
  };

  // Chromium / Android / Desktop PWA install trigger
  if (isInstallable) {
    return (
      <>
        <button
          onClick={handleInstallClick}
          aria-label="Install JM/CZ Portfolio App"
          className={`inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#d4fc35] hover:bg-[#bef264] text-black border border-black text-xs font-mono font-extrabold uppercase shadow-[2px_2px_0px_#000000] active:translate-x-0.5 active:translate-y-0.5 active:shadow-none transition-all cursor-pointer ${className}`}
        >
          <Download className="w-3.5 h-3.5" />
          <span>INSTALL APP</span>
        </button>

        {installSuccess && (
          <div className="fixed bottom-4 right-4 z-50 p-3 bg-black text-[#d4fc35] border-2 border-[#d4fc35] font-mono text-xs font-bold shadow-lg">
            ✓ JM/CZ APP INSTALLED SUCCESSFULLY!
          </div>
        )}
      </>
    );
  }

  // iOS Safari flow
  if (isIOS) {
    return (
      <>
        <button
          onClick={() => setShowIOSGuide(true)}
          aria-label="Install JM/CZ Portfolio on iOS"
          className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-black border border-black text-xs font-mono font-bold shadow-[2px_2px_0px_#000000] transition-all cursor-pointer ${className}`}
        >
          <Smartphone className="w-3.5 h-3.5 text-[#1d4ed8]" />
          <span>INSTALL ON IOS</span>
        </button>

        {showIOSGuide && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 font-mono">
            <div className="w-full max-w-sm bg-white border-2 border-black p-5 shadow-[8px_8px_0px_#000000] text-xs space-y-4">
              <div className="flex items-center justify-between border-b-2 border-black pb-2">
                <span className="font-extrabold text-black uppercase">INSTALL ON IPHONE / IPAD</span>
                <button
                  onClick={() => setShowIOSGuide(false)}
                  className="w-6 h-6 border border-black hover:bg-black hover:text-white flex items-center justify-center cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="space-y-2 text-slate-700 leading-relaxed">
                <p>To run JM/CZ as a standalone application on iOS:</p>
                <ol className="list-decimal pl-5 space-y-1.5 text-black font-semibold">
                  <li>Tap the <strong>Share</strong> button (box with upward arrow) in the Safari toolbar.</li>
                  <li>Scroll down the actions list and tap <strong>Add to Home Screen</strong>.</li>
                  <li>Tap <strong>Add</strong> in the top-right corner.</li>
                </ol>
              </div>

              <button
                onClick={() => setShowIOSGuide(false)}
                className="w-full py-2 bg-black text-white font-bold uppercase tracking-wider hover:bg-slate-800 cursor-pointer"
              >
                GOT IT
              </button>
            </div>
          </div>
        )}
      </>
    );
  }

  // Fallback for browsers before prompt fires (or desktop browsers with manual install option)
  return (
    <>
      <button
        onClick={() => setShowDesktopGuide(true)}
        aria-label="Install App"
        title="Install progressive web app"
        className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 bg-slate-100 hover:bg-[#d4fc35] text-black border border-black text-xs font-mono font-bold shadow-[2px_2px_0px_#000000] active:translate-x-0.5 active:translate-y-0.5 transition-all cursor-pointer ${className}`}
      >
        <Laptop className="w-3.5 h-3.5 text-[#1d4ed8]" />
        <span>APP READY</span>
      </button>

      {showDesktopGuide && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 font-mono">
          <div className="w-full max-w-sm bg-white border-2 border-black p-5 shadow-[8px_8px_0px_#000000] text-xs space-y-4">
            <div className="flex items-center justify-between border-b-2 border-black pb-2">
              <span className="font-extrabold text-black uppercase">INSTALL JM/CZ PORTFOLIO</span>
              <button
                onClick={() => setShowDesktopGuide(false)}
                className="w-6 h-6 border border-black hover:bg-black hover:text-white flex items-center justify-center cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="space-y-2 text-slate-700 leading-relaxed">
              <p>To install this application on your computer or phone:</p>
              <ol className="list-decimal pl-5 space-y-1.5 text-black font-semibold">
                <li>Look for the <strong>Install</strong> icon in your browser address bar (top right).</li>
                <li>Or open the browser menu (⋮) and select <strong>"Install JM/CZ Portfolio"</strong>.</li>
                <li>Confirm to launch standalone without browser borders.</li>
              </ol>
            </div>

            <button
              onClick={() => setShowDesktopGuide(false)}
              className="w-full py-2 bg-black text-white font-bold uppercase tracking-wider hover:bg-slate-800 cursor-pointer"
            >
              GOT IT
            </button>
          </div>
        </div>
      )}
    </>
  );
};
