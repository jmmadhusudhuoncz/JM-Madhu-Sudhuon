import React from 'react';
import { ChevronRight, Target, Lightbulb, Users, Code, Cpu, User, Zap, Terminal, Activity } from 'lucide-react';
import { PixelFace } from './IsometricGraphics';
import { AgencyCard } from './AgencyCard';
import { profile } from '../data/profile';

interface AboutSectionProps {
  onOpenConnect: () => void;
  onOpenCv: () => void;
  profileData?: typeof profile;
}

export const AboutSection: React.FC<AboutSectionProps> = ({
  onOpenConnect,
  onOpenCv,
  profileData = profile,
}) => {
  return (
    <section id="about" className="w-full bg-white border-b-2 border-black">
      <div className="grid grid-cols-1 lg:grid-cols-12 divide-y-2 lg:divide-y-0 lg:divide-x-2 divide-black">
        {/* Left Column: Identity, Bio, Structured Details */}
        <div className="lg:col-span-7 p-5 sm:p-8 md:p-10 flex flex-col justify-between bg-white">
          <div>
            <div className="flex items-center gap-2.5 mb-5">
              <div className="w-2 h-7 bg-[#1d4ed8]" />
              <h2 className="text-xl sm:text-2xl font-mono font-extrabold tracking-tight text-black uppercase">
                07/ ABOUT ME
              </h2>
            </div>

            {/* Top Identity Block */}
            <div className="flex flex-col sm:flex-row items-start gap-5 mb-6">
              <div className="shrink-0">
                <PixelFace className="w-20 h-20 sm:w-24 sm:h-24" />
              </div>

              <div className="font-mono space-y-1">
                <h3 className="text-xl sm:text-2xl font-black text-black uppercase tracking-tight">
                  {profileData.name}
                </h3>
                <div className="text-xs sm:text-sm font-extrabold text-[#1d4ed8] tracking-wider uppercase">
                  {profileData.role}
                </div>
                <div className="text-xs text-slate-600 pt-1 leading-relaxed">
                  {profileData.aboutHeadline}: {profileData.aboutText}
                </div>
              </div>
            </div>

            {/* 4 Explicit Required Cards: WHO AM I / FOCUS / TECHNOLOGY / CURRENT STATUS */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6 font-mono text-xs">
              {/* WHO AM I */}
              <div className="p-3.5 bg-slate-50 border-2 border-black space-y-1 shadow-[2px_2px_0px_#000000]">
                <div className="flex items-center gap-1.5 font-extrabold text-black uppercase text-[11px]">
                  <User className="w-3.5 h-3.5 text-[#1d4ed8]" />
                  <span>WHO AM I</span>
                </div>
                <p className="text-slate-700 leading-relaxed text-[11px]">
                  {profileData.whoAmI}
                </p>
              </div>

              {/* FOCUS */}
              <div className="p-3.5 bg-slate-50 border-2 border-black space-y-1 shadow-[2px_2px_0px_#000000]">
                <div className="flex items-center gap-1.5 font-extrabold text-black uppercase text-[11px]">
                  <Zap className="w-3.5 h-3.5 text-[#d4fc35] bg-black p-0.5" />
                  <span>FOCUS</span>
                </div>
                <p className="text-slate-700 leading-relaxed text-[11px]">
                  {profileData.focus}
                </p>
              </div>

              {/* TECHNOLOGY */}
              <div className="p-3.5 bg-slate-50 border-2 border-black space-y-1 shadow-[2px_2px_0px_#000000]">
                <div className="flex items-center gap-1.5 font-extrabold text-black uppercase text-[11px]">
                  <Terminal className="w-3.5 h-3.5 text-[#1d4ed8]" />
                  <span>TECHNOLOGY</span>
                </div>
                <p className="text-slate-700 leading-relaxed text-[11px]">
                  {profileData.technology}
                </p>
              </div>

              {/* CURRENT STATUS */}
              <div className="p-3.5 bg-slate-50 border-2 border-black space-y-1 shadow-[2px_2px_0px_#000000]">
                <div className="flex items-center gap-1.5 font-extrabold text-black uppercase text-[11px]">
                  <Activity className="w-3.5 h-3.5 text-emerald-600 animate-pulse" />
                  <span>CURRENT STATUS</span>
                </div>
                <p className="text-slate-700 leading-relaxed text-[11px]">
                  {profileData.currentStatus}
                </p>
              </div>
            </div>

            {/* Dedicated Agency Card */}
            <div className="mb-4">
              <AgencyCard compact />
            </div>
          </div>

          {/* Action Buttons */}
          <div className="pt-4 border-t border-slate-200 flex flex-wrap items-center gap-3">
            <button
              onClick={onOpenConnect}
              className="inline-flex items-center gap-2 px-5 py-2.5 text-xs font-mono font-bold text-white bg-[#1d4ed8] hover:bg-[#1e40af] border-2 border-black transition-all cursor-pointer select-none shadow-[2px_2px_0px_#000000] active:scale-95"
            >
              <span>DISCUSS A PROJECT</span>
              <ChevronRight className="w-4 h-4" />
            </button>

            <button
              onClick={onOpenCv}
              className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-mono font-bold text-black bg-white hover:bg-slate-100 border-2 border-black transition-all cursor-pointer select-none active:scale-95"
            >
              <span>DOWNLOAD RESUME / CV</span>
            </button>
          </div>
        </div>

        {/* Right Column: Pillars & Specializations */}
        <div className="lg:col-span-5 p-5 sm:p-8 flex flex-col justify-between bg-slate-50 font-mono">
          <div>
            <span className="text-[10px] font-extrabold text-slate-500 uppercase tracking-widest block mb-4">
              // PILLARS &amp; SPECIALIZATIONS
            </span>

            <div className="space-y-3 text-xs">
              <div className="p-3 bg-white border border-black shadow-[2px_2px_0px_#000000] flex items-start gap-3">
                <Code className="w-4 h-4 text-[#1d4ed8] shrink-0 mt-0.5" />
                <div>
                  <strong className="block text-black">SOFTWARE &amp; PROGRAMMING</strong>
                  <span className="text-[11px] text-slate-600 leading-snug">
                    HTML, CSS, JavaScript, Python, C++, algorithmic problem solving.
                  </span>
                </div>
              </div>

              <div className="p-3 bg-white border border-black shadow-[2px_2px_0px_#000000] flex items-start gap-3">
                <Cpu className="w-4 h-4 text-purple-700 shrink-0 mt-0.5" />
                <div>
                  <strong className="block text-black">AI &amp; MACHINE LEARNING</strong>
                  <span className="text-[11px] text-slate-600 leading-snug">
                    Google ML coursework, machine learning concepts, model experimentation.
                  </span>
                </div>
              </div>

              <div className="p-3 bg-white border border-black shadow-[2px_2px_0px_#000000] flex items-start gap-3">
                <Target className="w-4 h-4 text-[#1d4ed8] shrink-0 mt-0.5" />
                <div>
                  <strong className="block text-black">PROJECT ANALYSIS</strong>
                  <span className="text-[11px] text-slate-600 leading-snug">
                    Systematic requirement discovery, project planning, architecture maps.
                  </span>
                </div>
              </div>

              <div className="p-3 bg-white border border-black shadow-[2px_2px_0px_#000000] flex items-start gap-3">
                <Users className="w-4 h-4 text-[#1d4ed8] shrink-0 mt-0.5" />
                <div>
                  <strong className="block text-black">TEAM MANAGEMENT &amp; WORKFLOW</strong>
                  <span className="text-[11px] text-slate-600 leading-snug">
                    Collaborative coordination, task distribution, delivery alignment.
                  </span>
                </div>
              </div>

              <div className="p-3 bg-white border border-black shadow-[2px_2px_0px_#000000] flex items-start gap-3">
                <Lightbulb className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <div>
                  <strong className="block text-black">IDEA DEVELOPMENT</strong>
                  <span className="text-[11px] text-slate-600 leading-snug">
                    Transforming conceptual breakthroughs into working software products.
                  </span>
                </div>
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-200 text-[10px] text-slate-500">
            Open to technical partnerships, software development, and innovative project engineering.
          </div>
        </div>
      </div>
    </section>
  );
};
