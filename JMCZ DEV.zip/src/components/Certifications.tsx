import React from 'react';
import { Award, ExternalLink, Eye, CheckCircle, FileBadge } from 'lucide-react';
import { certificatesData } from '../data/certificates';

export type CertificateItem = typeof certificatesData[0];

interface CertificationsProps {
  onViewCertificate: (cert: CertificateItem) => void;
  certificates?: CertificateItem[];
}

export const Certifications: React.FC<CertificationsProps> = ({
  onViewCertificate,
  certificates = certificatesData,
}) => {
  return (
    <section id="certifications" className="w-full bg-white border-b-2 border-black">
      {/* Header Bar */}
      <div className="p-6 sm:p-8 border-b-2 border-black flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <div className="w-2 h-7 bg-[#1d4ed8]" />
            <h2 className="text-xl sm:text-2xl font-mono font-extrabold tracking-tight text-black">
              05/ CERTIFICATIONS
            </h2>
          </div>
          <p className="font-mono text-xs sm:text-sm text-slate-700 max-w-2xl leading-relaxed">
            Accredited qualifications earned across Machine Learning, programming languages, and web engineering standards from Google and FABEVY.
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs text-slate-600 bg-slate-50 border border-black px-3 py-1.5 self-start md:self-auto">
          <Award className="w-4 h-4 text-[#1d4ed8]" />
          <span className="font-bold">{certificates.length} CREDENTIALS RECORDED</span>
        </div>
      </div>

      {/* Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 divide-y-2 md:divide-y-0 divide-black md:gap-px md:bg-black">
        {certificates.map((cert) => (
          <div
            key={cert.id}
            className="p-6 bg-white flex flex-col justify-between hover:bg-slate-50 transition-colors"
          >
            <div>
              {/* Issuer Tag & Category */}
              <div className="flex items-center justify-between gap-2 mb-3">
                <span
                  className={`px-2.5 py-0.5 font-mono text-xs font-black border border-black ${
                    cert.issuer === 'Google'
                      ? 'bg-[#1d4ed8] text-white'
                      : 'bg-[#d4fc35] text-black'
                  }`}
                >
                  {cert.issuer}
                </span>

                <span className="font-mono text-[10px] text-slate-500 uppercase tracking-wider">
                  {cert.category}
                </span>
              </div>

              {/* Title */}
              <h3 className="font-mono text-lg font-black text-black tracking-tight uppercase mb-2">
                {cert.title}
              </h3>

              {/* Description */}
              <p className="font-mono text-xs text-slate-600 mb-4 leading-relaxed">
                {cert.description}
              </p>

              {/* Date if available (no fake date) */}
              {cert.date ? (
                <div className="font-mono text-[11px] text-slate-700 mb-4">
                  <span className="font-bold text-black">COMPLETED:</span> {cert.date}
                </div>
              ) : null}

              {/* Credential ID if available (no fake ID) */}
              {cert.credentialId ? (
                <div className="font-mono text-[10px] text-slate-500 mb-4">
                  <span className="font-bold">ID:</span> {cert.credentialId}
                </div>
              ) : null}
            </div>

            {/* Action Buttons */}
            <div className="pt-4 border-t border-slate-200 flex flex-wrap items-center gap-2 font-mono text-xs">
              {/* VIEW CERTIFICATE Button */}
              <button
                onClick={() => onViewCertificate(cert)}
                className="flex-1 py-2 px-3 bg-black hover:bg-slate-800 text-white font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <Eye className="w-3.5 h-3.5" />
                <span>VIEW CERTIFICATE</span>
              </button>

              {/* VERIFY Button (Rendered ONLY if a real verificationUrl exists) */}
              {cert.verificationUrl ? (
                <a
                  href={cert.verificationUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="py-2 px-3 bg-[#d4fc35] hover:bg-[#bef264] text-black font-bold border border-black flex items-center justify-center gap-1 transition-colors cursor-pointer"
                >
                  <span>VERIFY</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              ) : null}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};
