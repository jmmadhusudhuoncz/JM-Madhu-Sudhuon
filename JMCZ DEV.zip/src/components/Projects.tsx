import React, { useState, useMemo } from 'react';
import { ArrowUpRight, Github, ExternalLink, Search, Download, FileArchive, X } from 'lucide-react';
import { projectsData } from '../data/projects';
import { publishedAppsData, PublishedApp } from '../data/publishedApps';
import { resolveStorageDownloadUrl } from '../services/firebase';

export type ProjectItem = typeof projectsData[0];

interface ProjectsProps {
  onSelectProject: (project: ProjectItem) => void;
  onSelectApp?: (app: PublishedApp) => void;
  projects?: ProjectItem[];
  apps?: PublishedApp[];
}

export const Projects: React.FC<ProjectsProps> = ({
  onSelectProject,
  onSelectApp,
  projects = projectsData,
  apps = publishedAppsData,
}) => {
  const [activeFilter, setActiveFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Apps configured to appear in the projects section
  const projectsFromApps = useMemo(() => {
    return apps
      .filter((app) => app.showInProjects !== false)
      .map((app, index) => {
        return {
          id: app.id,
          number: `A${String(index + 1).padStart(2, '0')}`,
          title: app.name,
          subtitle: `${app.platform} ${app.fileType} · Version ${app.version}`,
          status: app.status === 'available' ? 'Completed' : 'In Development',
          category: app.category,
          role: 'Lead Architect & Developer',
          problem: app.fullDescription || app.description,
          solution: `Engineered as a high-performance ${app.platform} package with offline support and modular architecture.`,
          technology: app.technologies && app.technologies.length > 0 ? app.technologies : [app.platform, app.fileType],
          features: app.features || [],
          learning: 'Packaging and maintaining production-grade distributions with native platform integrations.',
          links: {
            demo: app.liveDemo || '',
            repo: app.github || ''
          },
          isApp: true,
          rawApp: app
        };
      });
  }, [apps]);

  const allItems = useMemo(() => {
    return [...projects, ...projectsFromApps];
  }, [projects, projectsFromApps]);

  const filteredItems = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();

    return allItems.filter((item) => {
      // 1. Text Search Filter (name, description, category, technology, version)
      if (q) {
        const matchesTitle = item.title.toLowerCase().includes(q);
        const matchesSubtitle = item.subtitle.toLowerCase().includes(q);
        const matchesProblem = (item.problem || '').toLowerCase().includes(q);
        const matchesCategory = item.category.toLowerCase().includes(q);
        const matchesTech = item.technology.some((t) => t.toLowerCase().includes(q));
        const rawAppVersion = (item as any).rawApp?.version?.toLowerCase() || '';
        const matchesVersion = rawAppVersion.includes(q);

        if (!matchesTitle && !matchesSubtitle && !matchesProblem && !matchesCategory && !matchesTech && !matchesVersion) {
          return false;
        }
      }

      // 2. Category / Type Filter
      if (activeFilter === 'ALL') return true;

      if (activeFilter === 'PROJECTS') {
        return !('isApp' in item);
      }

      if (activeFilter === 'ANDROID') {
        return (
          item.category.toLowerCase().includes('android') ||
          item.technology.some((t) => t.toLowerCase().includes('android')) ||
          (item as any).rawApp?.platform?.toLowerCase().includes('android')
        );
      }

      if (activeFilter === 'APK') {
        const app = (item as any).rawApp as PublishedApp | undefined;
        return app?.files?.some((f) => f.type === 'APK') || false;
      }

      if (activeFilter === 'ZIP' || activeFilter === 'SOURCE CODE') {
        const app = (item as any).rawApp as PublishedApp | undefined;
        return app?.files?.some((f) => f.type === 'ZIP') || false;
      }

      return item.status.toUpperCase() === activeFilter;
    });
  }, [allItems, activeFilter, searchQuery]);

  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case 'Completed':
        return 'bg-emerald-600 text-white';
      case 'In Development':
        return 'bg-[#1d4ed8] text-white';
      case 'Concept':
        return 'bg-[#d4fc35] text-black';
      case 'Experimental':
        return 'bg-purple-700 text-white';
      default:
        return 'bg-slate-800 text-white';
    }
  };

  const handleCardClick = (item: any) => {
    if (item.isApp && item.rawApp && onSelectApp) {
      onSelectApp(item.rawApp);
    } else {
      onSelectProject(item as ProjectItem);
    }
  };

  const filterTabs = [
    'ALL',
    'PROJECTS',
    'ANDROID',
    'APK',
    'ZIP',
    'IN DEVELOPMENT',
    'CONCEPT',
    'EXPERIMENTAL'
  ];

  return (
    <section id="projects" className="w-full bg-white border-b-2 border-black">
      {/* Top Banner & Analytical Intro */}
      <div className="border-b-2 border-black p-4 sm:p-6 md:p-8 flex flex-col gap-4 bg-white">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2.5 mb-1.5">
              <div className="w-2 h-6 sm:h-7 bg-[#1d4ed8]" />
              <h2 className="text-lg sm:text-2xl font-mono font-extrabold tracking-tight text-black uppercase">
                02/ PROJECTS &amp; INITIATIVES
              </h2>
            </div>
            <p className="font-mono text-xs sm:text-sm text-slate-700 max-w-2xl leading-relaxed">
              Analytical problem-solving and software systems across computer vision, edtech, creative media, performance analytics, and published applications.
            </p>
          </div>

          {/* Real-time Search Input */}
          <div className="relative w-full md:w-72 font-mono">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search name, tech, version..."
              className="w-full pl-8 pr-7 py-2 bg-slate-50 border-2 border-black text-xs text-black placeholder:text-slate-400 outline-none focus:bg-white"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-black cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Filter Segmented Controls */}
        <div className="flex flex-wrap items-center gap-1.5 pt-2 border-t border-slate-200 font-mono text-[10px] sm:text-[11px]">
          {filterTabs.map((filter) => (
            <button
              key={filter}
              onClick={() => setActiveFilter(filter)}
              className={`px-3 py-1 font-bold border transition-colors cursor-pointer select-none whitespace-nowrap ${
                activeFilter === filter
                  ? 'bg-black text-white border-black shadow-[1px_1px_0px_#000000]'
                  : 'bg-white text-slate-700 border-slate-300 hover:text-black hover:border-black'
              }`}
            >
              {filter}
            </button>
          ))}
          <span className="text-[10px] text-slate-500 ml-auto font-bold">
            {filteredItems.length} ITEM{filteredItems.length === 1 ? '' : 'S'}
          </span>
        </div>
      </div>

      {/* Grid of Projects & Published Apps */}
      {filteredItems.length === 0 ? (
        <div className="p-8 text-center font-mono text-xs text-slate-500 bg-slate-50">
          No projects or apps matching your search criteria. Try a different query or reset filters.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 divide-y-2 md:divide-y-0 divide-black md:gap-px md:bg-black">
          {filteredItems.map((item: any) => {
            const rawApp = item.rawApp as PublishedApp | undefined;
            const apkFile = rawApp?.files?.find((f) => f.type === 'APK');
            const zipFile = rawApp?.files?.find((f) => f.type === 'ZIP');

            return (
              <div
                key={item.id}
                className="group flex flex-col justify-between bg-white hover:bg-slate-50 transition-colors p-4 sm:p-6 select-none"
              >
                {/* Header: Number + Category + Status Badge */}
                <div>
                  <div className="flex items-center justify-between gap-2 mb-3">
                    <div className="flex items-center gap-1.5">
                      <span className="px-2 py-0.5 bg-[#d4fc35] border border-black text-black font-mono text-xs font-black shadow-[1px_1px_0px_#000000]">
                        #{item.number}
                      </span>
                      <span className="text-[10px] font-mono font-bold text-slate-500 uppercase tracking-wider truncate max-w-[130px] sm:max-w-none">
                        {item.category}
                      </span>
                    </div>

                    <span
                      className={`px-2 py-0.5 font-mono text-[10px] font-bold border border-black uppercase tracking-wider shrink-0 ${getStatusBadgeClass(
                        item.status
                      )}`}
                    >
                      {item.status}
                    </span>
                  </div>

                  {/* Title & Subtitle */}
                  <h3 className="font-mono text-lg sm:text-xl font-extrabold text-black tracking-tight uppercase mb-1 group-hover:text-[#1d4ed8] transition-colors break-words">
                    {item.title}
                  </h3>
                  <p className="font-mono text-xs font-semibold text-slate-700 mb-3 leading-snug">
                    {item.subtitle}
                  </p>

                  {/* Description / Problem Brief */}
                  <div className="p-3 bg-slate-50 border border-slate-200 mb-4 font-mono text-[11px] text-slate-700 leading-relaxed">
                    <span className="font-bold text-black block mb-0.5 text-[10px] uppercase tracking-wide">
                      OVERVIEW &amp; PROBLEM:
                    </span>
                    <p className="line-clamp-3">{item.problem}</p>
                  </div>

                  {/* Technology Tags */}
                  <div className="flex flex-wrap items-center gap-1.5 mb-4">
                    {item.technology.map((tech: string) => (
                      <span
                        key={tech}
                        className="px-2 py-0.5 border border-slate-300 bg-white text-[10px] font-mono font-bold text-slate-800"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Actions */}
                <div className="pt-3 border-t border-slate-200 flex flex-wrap items-center justify-between gap-2 font-mono text-xs">
                  <div className="flex flex-wrap items-center gap-1.5">
                    {/* Direct Download Buttons for Published Apps */}
                    {apkFile && apkFile.exists && rawApp?.status === 'available' && (
                      <a
                        href={apkFile.path}
                        download={apkFile.name}
                        onClick={async (e) => {
                          e.stopPropagation();
                          if (apkFile.path && (apkFile.path.startsWith('gs://') || apkFile.path.startsWith('apps/'))) {
                            e.preventDefault();
                            const url = await resolveStorageDownloadUrl(apkFile.path);
                            if (url) {
                              const link = document.createElement('a');
                              link.href = url;
                              link.target = '_blank';
                              link.rel = 'noopener noreferrer';
                              document.body.appendChild(link);
                              link.click();
                              document.body.removeChild(link);
                            }
                          }
                        }}
                        className="px-2.5 py-1.5 bg-[#1d4ed8] hover:bg-[#1e40af] text-white font-bold text-[11px] border border-black flex items-center gap-1 cursor-pointer"
                        title={`Download APK: ${apkFile.name}`}
                      >
                        <Download className="w-3 h-3" />
                        <span>APK</span>
                      </a>
                    )}

                    {zipFile && zipFile.exists && rawApp?.status === 'available' && (
                      <a
                        href={zipFile.path}
                        download={zipFile.name}
                        onClick={async (e) => {
                          e.stopPropagation();
                          if (zipFile.path && (zipFile.path.startsWith('gs://') || zipFile.path.startsWith('apps/'))) {
                            e.preventDefault();
                            const url = await resolveStorageDownloadUrl(zipFile.path);
                            if (url) {
                              const link = document.createElement('a');
                              link.href = url;
                              link.target = '_blank';
                              link.rel = 'noopener noreferrer';
                              document.body.appendChild(link);
                              link.click();
                              document.body.removeChild(link);
                            }
                          }
                        }}
                        className="px-2.5 py-1.5 bg-[#d4fc35] hover:bg-[#bef264] text-black font-bold text-[11px] border border-black flex items-center gap-1 cursor-pointer"
                        title={`Download ZIP: ${zipFile.name}`}
                      >
                        <FileArchive className="w-3 h-3" />
                        <span>ZIP</span>
                      </a>
                    )}

                    {/* External links: Demo & Repo */}
                    {item.links?.demo && (
                      <a
                        href={item.links.demo}
                        target="_blank"
                        rel="noopener noreferrer"
                        onClick={(e) => e.stopPropagation()}
                        className="px-2.5 py-1.5 bg-white hover:bg-slate-100 text-black border border-black font-bold text-[11px] flex items-center gap-1 cursor-pointer"
                      >
                        <span>DEMO</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    )}

                    {item.links?.repo && (
                      <a
                        href={item.links.repo}
                        target="_blank"
                        rel="noopener noreferrer"
                        onClick={(e) => e.stopPropagation()}
                        className="px-2.5 py-1.5 bg-white hover:bg-slate-100 text-black border border-black font-bold text-[11px] flex items-center gap-1 cursor-pointer"
                        title="GitHub Repository"
                      >
                        <Github className="w-3 h-3" />
                      </a>
                    )}
                  </div>

                  <button
                    onClick={() => handleCardClick(item)}
                    className="min-h-[38px] px-3.5 py-1.5 bg-[#1d4ed8] hover:bg-[#1e40af] text-white font-bold text-[11px] border border-black shadow-[2px_2px_0px_#000000] flex items-center gap-1.5 cursor-pointer ml-auto active:translate-x-0.5 active:translate-y-0.5"
                  >
                    <span>VIEW DETAILS</span>
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </section>
  );
};
