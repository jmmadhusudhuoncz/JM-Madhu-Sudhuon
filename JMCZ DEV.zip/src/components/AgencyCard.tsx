import React from 'react';
import { ArrowUpRight, Building2, Globe } from 'lucide-react';
import { profile } from '../data/profile';

interface AgencyCardProps {
  className?: string;
  compact?: boolean;
}

export const AgencyCard: React.FC<AgencyCardProps> = ({ className = '', compact = false }) => {
  return (
    <div
      className={`bg-white border-2 border-black shadow-[4px_4px_0px_#000000] font-mono transition-transform hover:-translate-y-0.5 ${
        compact ? 'p-3 sm:p-4' : 'p-5 sm:p-6'
      } ${className}`}
    >
      <div className="flex items-start justify-between gap-3 mb-3">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-[#d4fc35] border border-black flex items-center justify-center shrink-0">
            <Building2 className="w-4 h-4 text-black" />
          </div>
          <div>
            <span className="text-[10px] font-extrabold uppercase tracking-widest text-[#1d4ed8] block">
              // AFFILIATED VENTURE
            </span>
            <h3 className="text-sm sm:text-base font-black text-black tracking-tight leading-tight">
              BM DEVELOPER AGENCY
            </h3>
          </div>
        </div>

        <span className="px-2 py-0.5 text-[9px] font-bold bg-slate-100 border border-slate-400 text-slate-700 uppercase shrink-0">
          OFFICIAL
        </span>
      </div>

      <p className="text-xs text-slate-700 font-medium mb-4 leading-relaxed">
        Digital Development &amp; Technology
      </p>

      <div className="pt-3 border-t border-slate-200 flex items-center justify-between gap-3">
        <span className="text-[10px] text-slate-500 flex items-center gap-1">
          <Globe className="w-3 h-3 text-slate-400" />
          <span>bmdeveloperagency.netlify.app</span>
        </span>

        <a
          href={profile.agencyUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-black hover:bg-[#1d4ed8] text-white text-xs font-bold transition-colors border border-black shadow-[2px_2px_0px_#000000] cursor-pointer shrink-0"
        >
          <span>VISIT AGENCY</span>
          <ArrowUpRight className="w-3.5 h-3.5" />
        </a>
      </div>
    </div>
  );
};
