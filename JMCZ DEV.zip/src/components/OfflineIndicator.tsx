import React, { useEffect, useState } from 'react';
import { WifiOff } from 'lucide-react';

export function useOnlineStatus() {
  const [isOnline, setIsOnline] = useState(
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  return isOnline;
}

export const OfflineIndicator: React.FC = () => {
  const isOnline = useOnlineStatus();

  if (isOnline) return null;

  return (
    <div className="fixed bottom-4 left-4 z-50 flex items-center gap-2 border-2 border-black bg-[#d4fc35] px-3.5 py-2 font-mono text-xs font-bold text-black shadow-[4px_4px_0px_#000000] animate-in fade-in duration-200">
      <WifiOff className="w-4 h-4 text-black animate-pulse" />
      <span>OFFLINE MODE — CACHED PORTFOLIO ACTIVE</span>
    </div>
  );
};
