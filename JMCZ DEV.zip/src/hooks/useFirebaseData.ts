import { useState, useEffect } from 'react';
import {
  subscribeToPublishedApps,
  subscribeToPublishedProjects,
  subscribeToCertificates,
  subscribeToSkills,
  subscribeToServices,
  subscribeToAbout,
  subscribeToSocials,
  validateFirestoreConnection,
} from '../services/firebase';
import { publishedAppsData, PublishedApp } from '../data/publishedApps';
import { projectsData } from '../data/projects';
import { certificatesData } from '../data/certificates';
import { skillsData } from '../data/skills';
import { capabilitiesData } from '../data/capabilities';
import { profile } from '../data/profile';
import { socialsData } from '../data/socials';

export function useFirebaseData() {
  const [apps, setApps] = useState<PublishedApp[]>(publishedAppsData);
  const [projects, setProjects] = useState<typeof projectsData>(projectsData);
  const [certificates, setCertificates] = useState<typeof certificatesData>(certificatesData);
  const [skills, setSkills] = useState<typeof skillsData>(skillsData);
  const [capabilities, setCapabilities] = useState<typeof capabilitiesData>(capabilitiesData);
  const [userProfile, setUserProfile] = useState<typeof profile>(profile);
  const [socials, setSocials] = useState<typeof socialsData>(socialsData);
  const [isFirebaseConnected, setIsFirebaseConnected] = useState<boolean>(true);

  useEffect(() => {
    // 1. Connection check
    validateFirestoreConnection()
      .then((connected) => setIsFirebaseConnected(connected))
      .catch(() => setIsFirebaseConnected(false));

    // 2. Realtime listener: Published Apps
    const unsubApps = subscribeToPublishedApps((liveApps) => {
      if (liveApps && liveApps.length > 0) {
        setApps(liveApps);
      }
    });

    // 3. Realtime listener: Published Projects
    const unsubProjects = subscribeToPublishedProjects((liveProjects) => {
      if (liveProjects && liveProjects.length > 0) {
        setProjects(liveProjects);
      }
    });

    // 4. Realtime listener: Published Certificates
    const unsubCerts = subscribeToCertificates((liveCerts) => {
      if (liveCerts && liveCerts.length > 0) {
        setCertificates(liveCerts);
      }
    });

    // 5. Realtime listener: Skills
    const unsubSkills = subscribeToSkills((liveSkills) => {
      if (liveSkills && liveSkills.length > 0) {
        setSkills(liveSkills);
      }
    });

    // 6. Realtime listener: Services / Capabilities
    const unsubServices = subscribeToServices((liveServices) => {
      if (liveServices && liveServices.length > 0) {
        setCapabilities(liveServices);
      }
    });

    // 7. Realtime listener: About info
    const unsubAbout = subscribeToAbout((liveAbout) => {
      if (liveAbout) {
        setUserProfile((prev) => ({ ...prev, ...liveAbout }));
      }
    });

    // 8. Realtime listener: Social Links
    const unsubSocials = subscribeToSocials((liveSocials) => {
      if (liveSocials && liveSocials.length > 0) {
        setSocials(liveSocials);
      }
    });

    return () => {
      unsubApps();
      unsubProjects();
      unsubCerts();
      unsubSkills();
      unsubServices();
      unsubAbout();
      unsubSocials();
    };
  }, []);

  return {
    apps,
    projects,
    certificates,
    skills,
    capabilities,
    profile: userProfile,
    socials,
    isFirebaseConnected,
  };
}
