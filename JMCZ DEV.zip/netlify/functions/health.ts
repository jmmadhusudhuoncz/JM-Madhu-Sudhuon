export const handler = async () => {
  const key = (process.env.EMAIL_API_KEY || '').trim();
  const isEmailConfigured = Boolean(
    key &&
    !key.includes('@') &&
    (key.startsWith('re_') || key.startsWith('SG.'))
  );
  return {
    statusCode: 200,
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
    },
    body: JSON.stringify({
      status: 'ok',
      platform: 'netlify',
      app: 'JM/CZ Portfolio',
      emailConfigured: isEmailConfigured,
      recipient: process.env.EMAIL_TO || 'jmmadhusudhuoncz@gmail.com',
      timestamp: new Date().toISOString(),
    }),
  };
};
