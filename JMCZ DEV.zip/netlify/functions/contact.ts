/**
 * Netlify Serverless Function: /api/contact -> /.netlify/functions/contact
 * Handles contact requests and emails them to jmmadhusudhuoncz@gmail.com
 * Reads EMAIL_API_KEY, EMAIL_TO, EMAIL_FROM from Netlify environment variables.
 */

interface NetlifyEvent {
  httpMethod: string;
  headers: Record<string, string | undefined>;
  body: string | null;
  isBase64Encoded: boolean;
}

interface ProjectSubmissionPayload {
  name: string;
  email: string;
  phone?: string;
  projectType: string;
  budget?: string;
  preferredContact?: string;
  subject: string;
  message: string;
  website?: string;
}

function escapeHtml(str: string): string {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function formatTextEmail(data: ProjectSubmissionPayload, recipientEmail: string, timestamp: string): string {
  return [
    '--------------------------------',
    'NEW JM/CZ PROJECT REQUEST',
    '--------------------------------',
    '',
    'Name:',
    data.name.trim(),
    '',
    'Email:',
    data.email.trim(),
    '',
    'Phone / WhatsApp:',
    data.phone && data.phone.trim() ? data.phone.trim() : 'Not provided',
    '',
    'Project Type:',
    data.projectType,
    '',
    'Budget:',
    data.budget && data.budget.trim() ? data.budget.trim() : 'Not specified',
    '',
    'Preferred Contact Method:',
    data.preferredContact || 'Email',
    '',
    'Subject:',
    data.subject.trim(),
    '',
    'Message / Requirements:',
    data.message.trim(),
    '',
    'Submitted At:',
    timestamp,
    '',
    'Target Recipient:',
    recipientEmail,
    '',
    'Source:',
    'JM/CZ Portfolio Website',
    '--------------------------------',
  ].join('\n');
}

function formatHtmlEmail(data: ProjectSubmissionPayload, recipientEmail: string, timestamp: string): string {
  return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, monospace; background: #f8fafc; padding: 24px; color: #0f172a; margin: 0; }
    .card { background: #ffffff; border: 2px solid #000000; box-shadow: 6px 6px 0 #000000; max-width: 600px; margin: 0 auto; padding: 24px; }
    .header { border-bottom: 2px solid #000000; padding-bottom: 12px; margin-bottom: 18px; }
    .badge { background: #d4fc35; padding: 4px 8px; font-weight: bold; border: 1px solid #000000; display: inline-block; font-size: 11px; }
    .title { font-size: 18px; font-weight: 800; margin: 8px 0 0 0; }
    .row { margin-bottom: 14px; }
    .label { font-size: 11px; text-transform: uppercase; color: #64748b; font-weight: bold; letter-spacing: 0.05em; }
    .value { font-size: 14px; font-weight: 600; margin-top: 2px; }
    .message-box { background: #f1f5f9; border-left: 4px solid #1d4ed8; padding: 14px; white-space: pre-wrap; font-size: 13px; line-height: 1.6; }
    .footer { border-top: 1px solid #e2e8f0; margin-top: 20px; padding-top: 12px; font-size: 11px; color: #94a3b8; }
  </style>
</head>
<body>
  <div class="card">
    <div class="header">
      <div class="badge">JM/CZ PORTFOLIO INQUIRY</div>
      <h2 class="title">NEW PROJECT REQUEST</h2>
    </div>
    <div class="row"><div class="label">Client Name</div><div class="value">${escapeHtml(data.name)}</div></div>
    <div class="row"><div class="label">Client Email (Reply-To)</div><div class="value"><a href="mailto:${escapeHtml(data.email)}">${escapeHtml(data.email)}</a></div></div>
    <div class="row"><div class="label">Phone / WhatsApp</div><div class="value">${escapeHtml(data.phone || 'Not provided')}</div></div>
    <div class="row"><div class="label">Project Type</div><div class="value">${escapeHtml(data.projectType)}</div></div>
    <div class="row"><div class="label">Budget</div><div class="value">${escapeHtml(data.budget || 'Not specified')}</div></div>
    <div class="row"><div class="label">Preferred Contact Method</div><div class="value">${escapeHtml(data.preferredContact || 'Email')}</div></div>
    <div class="row"><div class="label">Subject</div><div class="value">${escapeHtml(data.subject)}</div></div>
    <div class="row"><div class="label">Message / Requirements</div><div class="message-box">${escapeHtml(data.message)}</div></div>
    <div class="footer">
      <div>Submitted At: ${timestamp}</div>
      <div>Source: JM/CZ Portfolio Website • Recipient: ${recipientEmail}</div>
    </div>
  </div>
</body>
</html>
  `.trim();
}

export const handler = async (event: NetlifyEvent) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Content-Type': 'application/json',
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 204, headers, body: '' };
  }

  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ success: false, error: 'Method not allowed. Use POST.' }),
    };
  }

  let data: ProjectSubmissionPayload;
  try {
    data = event.body ? JSON.parse(event.body) : {};
  } catch {
    return {
      statusCode: 400,
      headers,
      body: JSON.stringify({ success: false, error: 'Invalid JSON payload.' }),
    };
  }

  const timestamp = new Date().toISOString();
  const recipientEmail = (process.env.EMAIL_TO || 'jmmadhusudhuoncz@gmail.com').trim();
  const rawFrom = (process.env.EMAIL_FROM || '"JM CZ Inquiries" <onboarding@resend.dev>').trim();
  const emailApiKey = (process.env.EMAIL_API_KEY || '').trim();

  let fromAddress = rawFrom;
  const match = rawFrom.match(/^(.*?)\s*<([^>]+)>$/);
  if (match) {
    let name = match[1].trim();
    const email = match[2].trim();
    if (name.startsWith('"') && name.endsWith('"')) {
      name = name.slice(1, -1);
    }
    name = name.replace(/[/\\",;]/g, ' ').replace(/\s+/g, ' ').trim();
    fromAddress = name ? `"${name}" <${email}>` : email;
  }

  // Honeypot anti-spam
  if (data.website && String(data.website).trim().length > 0) {
    return {
      statusCode: 400,
      headers,
      body: JSON.stringify({ success: false, configured: true, error: 'Invalid submission.' }),
    };
  }

  // Server-side validations
  if (!data.name || !data.name.trim() || data.name.trim().length < 2) {
    return {
      statusCode: 400,
      headers,
      body: JSON.stringify({ success: false, configured: true, error: 'Full name is required (minimum 2 characters).' }),
    };
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!data.email || !data.email.trim() || !emailRegex.test(data.email.trim())) {
    return {
      statusCode: 400,
      headers,
      body: JSON.stringify({ success: false, configured: true, error: 'A valid email address is required.' }),
    };
  }

  if (!data.subject || !data.subject.trim() || data.subject.trim().length < 2) {
    return {
      statusCode: 400,
      headers,
      body: JSON.stringify({ success: false, configured: true, error: 'Subject is required.' }),
    };
  }

  if (!data.projectType || !data.projectType.trim()) {
    return {
      statusCode: 400,
      headers,
      body: JSON.stringify({ success: false, configured: true, error: 'Project type is required.' }),
    };
  }

  if (!data.message || !data.message.trim() || data.message.trim().length < 10) {
    return {
      statusCode: 400,
      headers,
      body: JSON.stringify({ success: false, configured: true, error: 'Message must be at least 10 characters.' }),
    };
  }

  // Unconfigured check
  if (!emailApiKey) {
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: false,
        configured: false,
        error: 'EMAIL_API_KEY has not been configured in the server environment yet.',
        recipient: recipientEmail,
        timestamp,
      }),
    };
  }

  // Detect accidental entry of email address in EMAIL_API_KEY
  if (emailApiKey.includes('@')) {
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: false,
        configured: false,
        error: `EMAIL_API_KEY is currently set to an email address (${emailApiKey}). It must be set to your private Resend API key (starts with "re_") or SendGrid API key (starts with "SG."). Generate a free key at https://resend.com/api-keys.`,
        details: 'Invalid API key format: email address supplied instead of API key',
        recipient: recipientEmail,
        timestamp,
      }),
    };
  }

  // Ensure key has a valid service prefix (re_ for Resend or SG. for SendGrid)
  if (!emailApiKey.startsWith('re_') && !emailApiKey.startsWith('SG.')) {
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: false,
        configured: false,
        error: 'Invalid API key format in EMAIL_API_KEY. Resend API keys must start with "re_" and SendGrid keys with "SG.". Generate a free key at https://resend.com/api-keys.',
        details: 'Invalid API key prefix',
        recipient: recipientEmail,
        timestamp,
      }),
    };
  }

  const emailText = formatTextEmail(data, recipientEmail, timestamp);
  const emailHtml = formatHtmlEmail(data, recipientEmail, timestamp);
  const emailSubject = `[JM/CZ PROJECT REQUEST] ${data.projectType}: ${data.subject}`;

  try {
    if (emailApiKey.startsWith('SG.')) {
      // SendGrid
      const sgResponse = await fetch('https://api.sendgrid.com/v3/mail/send', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${emailApiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          personalizations: [{ to: [{ email: recipientEmail }] }],
          from: { email: fromAddress.includes('<') ? fromAddress.match(/<([^>]+)>/)?.[1] || recipientEmail : fromAddress },
          reply_to: { email: data.email, name: data.name },
          subject: emailSubject,
          content: [
            { type: 'text/plain', value: emailText },
            { type: 'text/html', value: emailHtml },
          ],
        }),
      });

      if (!sgResponse.ok) {
        const errorText = await sgResponse.text();
        console.error('[Netlify Function SendGrid Error]:', errorText);
        return {
          statusCode: 502,
          headers,
          body: JSON.stringify({
            success: false,
            configured: true,
            error: 'EMAIL SERVICE TEMPORARILY UNAVAILABLE',
            details: `SendGrid error (${sgResponse.status})`,
          }),
        };
      }
    } else {
      // Resend
      const resendResponse = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${emailApiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          from: fromAddress,
          to: [recipientEmail],
          reply_to: data.email,
          subject: emailSubject,
          text: emailText,
          html: emailHtml,
        }),
      });

      const resendData = await resendResponse.json().catch(() => null);

      if (!resendResponse.ok) {
        console.error('[Netlify Function Resend Error]:', resendData);
        const detailedError = resendData?.message || resendData?.name || `Resend error (${resendResponse.status})`;
        return {
          statusCode: resendResponse.status >= 400 && resendResponse.status < 500 ? 400 : 502,
          headers,
          body: JSON.stringify({
            success: false,
            configured: true,
            error: 'EMAIL SERVICE TEMPORARILY UNAVAILABLE',
            details: detailedError,
          }),
        };
      }
    }

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        configured: true,
        message: 'REQUEST SENT SUCCESSFULLY',
        recipient: recipientEmail,
        timestamp,
      }),
    };
  } catch (err: unknown) {
    const errorMsg = err instanceof Error ? err.message : 'Unknown exception';
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        configured: true,
        error: 'EMAIL SERVICE TEMPORARILY UNAVAILABLE',
        details: errorMsg,
      }),
    };
  }
};
