/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-afac4cd2'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "registerSW.js",
    "revision": "1872c500de691dce40960bb85481de07"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "41746990e761a0e282744042fc7a8c82"
  }, {
    "url": "pwa-512x512.png",
    "revision": "17dee73a54c5e070505089c855cbfe15"
  }, {
    "url": "pwa-192x192.png",
    "revision": "4383a54135069b296c23f02f0859359e"
  }, {
    "url": "index.html",
    "revision": "e585a4ed4821156700abb05d6407c24c"
  }, {
    "url": "icon.svg",
    "revision": "ccb133b298ca424071576a3352ae0f91"
  }, {
    "url": "favicon.ico",
    "revision": "92d9676153b239efd5fd5bc3a60e0fdf"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "62688d17a243e35fe2c8b7120853652a"
  }, {
    "url": "assets/web-PBIBdlPc.js",
    "revision": null
  }, {
    "url": "assets/web-CkPhGVb3.js",
    "revision": null
  }, {
    "url": "assets/web-BJGQvh8y.js",
    "revision": null
  }, {
    "url": "assets/vendor-react-BfmJ51xv.js",
    "revision": null
  }, {
    "url": "assets/vendor-lucide-CLZDeQwV.js",
    "revision": null
  }, {
    "url": "assets/vendor-firebase-B4NRYuQ1.js",
    "revision": null
  }, {
    "url": "assets/rolldown-runtime-CbXtAM7H.js",
    "revision": null
  }, {
    "url": "assets/index-D1MkqLcI.css",
    "revision": null
  }, {
    "url": "assets/index-BeZBJgLf.js",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "62688d17a243e35fe2c8b7120853652a"
  }, {
    "url": "favicon.ico",
    "revision": "92d9676153b239efd5fd5bc3a60e0fdf"
  }, {
    "url": "icon.svg",
    "revision": "ccb133b298ca424071576a3352ae0f91"
  }, {
    "url": "pwa-192x192.png",
    "revision": "4383a54135069b296c23f02f0859359e"
  }, {
    "url": "pwa-512x512.png",
    "revision": "17dee73a54c5e070505089c855cbfe15"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "41746990e761a0e282744042fc7a8c82"
  }, {
    "url": "manifest.webmanifest",
    "revision": "bf91b512f2446cc04999ea6218ed1d6a"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));
  workbox.registerRoute(/^https:\/\/fonts\.googleapis\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "google-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/^https:\/\/fonts\.gstatic\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "gstatic-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');

}));
