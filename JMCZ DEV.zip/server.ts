import express from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json());

const RECIPIENT_EMAIL = (process.env.EMAIL_TO || 'jmmadhusudhuoncz@gmail.com').trim();
const RAW_FROM = (process.env.EMAIL_FROM || '"JM CZ Inquiries" <onboarding@resend.dev>').trim();

function formatSender(raw: string): string {
  const trimmed = raw.trim();
  const match = trimmed.match(/^(.*?)\s*<([^>]+)>$/);
  if (match) {
    let name = match[1].trim();
    const email = match[2].trim();
    if (name.startsWith('"') && name.endsWith('"')) {
      name = name.slice(1, -1);
    }
    name = name.replace(/[/\\",;]/g, ' ').replace(/\s+/g, ' ').trim();
    return name ? `"${name}" <${email}>` : email;
  }
  return trimmed;
}

const FROM_EMAIL = formatSender(RAW_FROM);

export interface ProjectSubmissionPayload {
  name: string;
  email: string;
  phone?: string;
  projectType: string;
  budget?: string;
  preferredContact?: string;
  subject: string;
  message: string;
  website?: string; // Honeypot
}

export interface EmailDispatchResult {
  statusCode: number;
  body: {
    success: boolean;
    configured: boolean;
    message?: string;
    error?: string;
    messageId?: string;
    recipient?: string;
    timestamp?: string;
    details?: string;
  };
}

// In-memory sliding rate limiter per IP address
const ipRateMap = new Map<string, number[]>();
const RATE_LIMIT_WINDOW_MS = 60 * 1000; // 1 minute
const MAX_REQUESTS_PER_WINDOW = 5;

function checkRateLimit(clientIp: string): boolean {
  if (!clientIp) return true;
  const now = Date.now();
  const timestamps = (ipRateMap.get(clientIp) || []).filter((t) => now - t < RATE_LIMIT_WINDOW_MS);
  
  if (timestamps.length >= MAX_REQUESTS_PER_WINDOW) {
    return false;
  }
  
  timestamps.push(now);
  ipRateMap.set(clientIp, timestamps);
  return true;
}

function escapeHtml(str: string): string {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function formatTextEmail(data: ProjectSubmissionPayload, timestamp: string): string {
  return [
    '--------------------------------',
    'NEW JM/CZ PROJECT REQUEST',
    '--------------------------------',
    '',
    'Name:',
    data.name.trim(),
    '',
    'Email:',
    data.email.trim(),
    '',
    'Phone / WhatsApp:',
    data.phone && data.phone.trim() ? data.phone.trim() : 'Not provided',
    '',
    'Project Type:',
    data.projectType,
    '',
    'Budget:',
    data.budget && data.budget.trim() ? data.budget.trim() : 'Not specified',
    '',
    'Preferred Contact Method:',
    data.preferredContact || 'Email',
    '',
    'Subject:',
    data.subject.trim(),
    '',
    'Message / Requirements:',
    data.message.trim(),
    '',
    'Submitted At:',
    timestamp,
    '',
    'Target Recipient:',
    RECIPIENT_EMAIL,
    '',
    'Source:',
    'JM/CZ Portfolio Website',
    '--------------------------------',
  ].join('\n');
}

function formatHtmlEmail(data: ProjectSubmissionPayload, recipientEmail: string, timestamp: string): string {
  return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, monospace; background: #f8fafc; padding: 24px; color: #0f172a; margin: 0; }
    .card { background: #ffffff; border: 2px solid #000000; box-shadow: 6px 6px 0 #000000; max-width: 600px; margin: 0 auto; padding: 24px; }
    .header { border-bottom: 2px solid #000000; padding-bottom: 12px; margin-bottom: 18px; }
    .badge { background: #d4fc35; padding: 4px 8px; font-weight: bold; border: 1px solid #000000; display: inline-block; font-size: 11px; }
    .title { font-size: 18px; font-weight: 800; margin: 8px 0 0 0; }
    .row { margin-bottom: 14px; }
    .label { font-size: 11px; text-transform: uppercase; color: #64748b; font-weight: bold; letter-spacing: 0.05em; }
    .value { font-size: 14px; font-weight: 600; margin-top: 2px; }
    .message-box { background: #f1f5f9; border-left: 4px solid #1d4ed8; padding: 14px; white-space: pre-wrap; font-size: 13px; line-height: 1.6; }
    .footer { border-top: 1px solid #e2e8f0; margin-top: 20px; padding-top: 12px; font-size: 11px; color: #94a3b8; }
  </style>
</head>
<body>
  <div class="card">
    <div class="header">
      <div class="badge">JM/CZ PORTFOLIO INQUIRY</div>
      <h2 class="title">NEW PROJECT REQUEST</h2>
    </div>
    
    <div class="row">
      <div class="label">Client Name</div>
      <div class="value">${escapeHtml(data.name)}</div>
    </div>

    <div class="row">
      <div class="label">Client Email (Reply-To)</div>
      <div class="value"><a href="mailto:${escapeHtml(data.email)}">${escapeHtml(data.email)}</a></div>
    </div>

    <div class="row">
      <div class="label">Phone / WhatsApp</div>
      <div class="value">${escapeHtml(data.phone || 'Not provided')}</div>
    </div>

    <div class="row">
      <div class="label">Project Type</div>
      <div class="value">${escapeHtml(data.projectType)}</div>
    </div>

    <div class="row">
      <div class="label">Budget</div>
      <div class="value">${escapeHtml(data.budget || 'Not specified')}</div>
    </div>

    <div class="row">
      <div class="label">Preferred Contact Method</div>
      <div class="value">${escapeHtml(data.preferredContact || 'Email')}</div>
    </div>

    <div class="row">
      <div class="label">Subject</div>
      <div class="value">${escapeHtml(data.subject)}</div>
    </div>

    <div class="row">
      <div class="label">Message / Requirements</div>
      <div class="message-box">${escapeHtml(data.message)}</div>
    </div>

    <div class="footer">
      <div>Submitted At: ${timestamp}</div>
      <div>Source: JM/CZ Portfolio Website • Recipient: ${recipientEmail}</div>
    </div>
  </div>
</body>
</html>
  `.trim();
}

export async function processContactSubmission(
  data: ProjectSubmissionPayload,
  clientIp: string = ''
): Promise<EmailDispatchResult> {
  const timestamp = new Date().toISOString();
  const recipientEmail = RECIPIENT_EMAIL;
  const fromAddress = FROM_EMAIL;
  const emailApiKey = (process.env.EMAIL_API_KEY || '').trim();

  // 1. Anti-spam honeypot check
  if (data.website && String(data.website).trim().length > 0) {
    console.warn(`[Anti-Spam] Bot submission blocked from IP: ${clientIp}`);
    return {
      statusCode: 400,
      body: {
        success: false,
        configured: true,
        error: 'Invalid submission.',
      },
    };
  }

  // 2. Rate limiting check
  if (!checkRateLimit(clientIp)) {
    return {
      statusCode: 429,
      body: {
        success: false,
        configured: true,
        error: 'Too many submissions. Please wait a minute and try again.',
      },
    };
  }

  // 3. Server-side validation
  if (!data.name || !data.name.trim() || data.name.trim().length < 2) {
    return {
      statusCode: 400,
      body: { success: false, configured: true, error: 'Full name is required (minimum 2 characters).' },
    };
  }

  if (data.name.trim().length > 120) {
    return {
      statusCode: 400,
      body: { success: false, configured: true, error: 'Name is too long (maximum 120 characters).' },
    };
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!data.email || !data.email.trim() || !emailRegex.test(data.email.trim()) || data.email.length > 254) {
    return {
      statusCode: 400,
      body: { success: false, configured: true, error: 'A valid email address is required.' },
    };
  }

  if (!data.subject || !data.subject.trim() || data.subject.trim().length < 2) {
    return {
      statusCode: 400,
      body: { success: false, configured: true, error: 'Subject is required (minimum 2 characters).' },
    };
  }

  if (!data.projectType || !data.projectType.trim()) {
    return {
      statusCode: 400,
      body: { success: false, configured: true, error: 'Project type is required.' },
    };
  }

  if (!data.message || !data.message.trim() || data.message.trim().length < 10) {
    return {
      statusCode: 400,
      body: { success: false, configured: true, error: 'Message must be at least 10 characters.' },
    };
  }

  if (data.message.trim().length > 10000) {
    return {
      statusCode: 400,
      body: { success: false, configured: true, error: 'Message is too long (maximum 10,000 characters).' },
    };
  }

  const emailText = formatTextEmail(data, timestamp);
  const emailHtml = formatHtmlEmail(data, recipientEmail, timestamp);
  const emailSubject = `[JM/CZ PROJECT REQUEST] ${data.projectType}: ${data.subject}`;

  console.log(`[JM/CZ Contact] Valid submission from: ${data.name} <${data.email}> at ${timestamp}`);
  console.log(`[JM/CZ Contact] Forwarding to: ${recipientEmail}`);

  // 4. Check if EMAIL_API_KEY is configured
  if (!emailApiKey) {
    console.warn('[JM/CZ Contact] EMAIL_API_KEY is not set in environment.');
    return {
      statusCode: 200,
      body: {
        success: false,
        configured: false,
        error: 'EMAIL_API_KEY has not been configured in the server environment yet.',
        recipient: recipientEmail,
        timestamp,
      },
    };
  }

  // Detect accidental entry of email address in EMAIL_API_KEY
  if (emailApiKey.includes('@')) {
    console.warn(`[JM/CZ Contact] EMAIL_API_KEY is set to an email address ('${emailApiKey}') instead of an API key.`);
    return {
      statusCode: 200,
      body: {
        success: false,
        configured: false,
        error: `EMAIL_API_KEY is currently set to an email address (${emailApiKey}). It must be set to your private Resend API key (starts with "re_") or SendGrid API key (starts with "SG."). Generate a free key at https://resend.com/api-keys.`,
        details: 'Invalid API key format: email address supplied instead of API key',
        recipient: recipientEmail,
        timestamp,
      },
    };
  }

  // Ensure key has a valid service prefix (re_ for Resend or SG. for SendGrid)
  if (!emailApiKey.startsWith('re_') && !emailApiKey.startsWith('SG.')) {
    console.warn('[JM/CZ Contact] EMAIL_API_KEY format is unrecognized.');
    return {
      statusCode: 200,
      body: {
        success: false,
        configured: false,
        error: 'Invalid API key format in EMAIL_API_KEY. Resend API keys must start with "re_" and SendGrid keys with "SG.". Generate a free key at https://resend.com/api-keys.',
        details: 'Invalid API key prefix',
        recipient: recipientEmail,
        timestamp,
      },
    };
  }

  // 5. Dispatch via Email Provider (Resend or SendGrid)
  try {
    if (emailApiKey.startsWith('SG.')) {
      // SendGrid
      const sgResponse = await fetch('https://api.sendgrid.com/v3/mail/send', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${emailApiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          personalizations: [{ to: [{ email: recipientEmail }] }],
          from: { email: fromAddress.includes('<') ? fromAddress.match(/<([^>]+)>/)?.[1] || recipientEmail : fromAddress },
          reply_to: { email: data.email, name: data.name },
          subject: emailSubject,
          content: [
            { type: 'text/plain', value: emailText },
            { type: 'text/html', value: emailHtml },
          ],
        }),
      });

      if (!sgResponse.ok) {
        const errorBody = await sgResponse.text();
        console.error('[SendGrid Error]:', errorBody);
        return {
          statusCode: 502,
          body: {
            success: false,
            configured: true,
            error: 'EMAIL SERVICE TEMPORARILY UNAVAILABLE',
            details: `SendGrid error (${sgResponse.status}): ${errorBody}`,
          },
        };
      }

      return {
        statusCode: 200,
        body: {
          success: true,
          configured: true,
          message: 'REQUEST SENT SUCCESSFULLY',
          recipient: recipientEmail,
          timestamp,
        },
      };
    } else {
      // Resend (Default)
      const resendResponse = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${emailApiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          from: fromAddress,
          to: [recipientEmail],
          reply_to: data.email,
          subject: emailSubject,
          text: emailText,
          html: emailHtml,
        }),
      });

      const resendData = await resendResponse.json().catch(() => null);

      if (!resendResponse.ok) {
        console.error('[Resend Error]:', resendData);
        const detailedError = resendData?.message || resendData?.name || `Resend error (${resendResponse.status})`;
        return {
          statusCode: resendResponse.status >= 400 && resendResponse.status < 500 ? 400 : 502,
          body: {
            success: false,
            configured: true,
            error: 'EMAIL SERVICE TEMPORARILY UNAVAILABLE',
            details: detailedError,
          },
        };
      }

      return {
        statusCode: 200,
        body: {
          success: true,
          configured: true,
          message: 'REQUEST SENT SUCCESSFULLY',
          messageId: resendData?.id,
          recipient: recipientEmail,
          timestamp,
        },
      };
    }
  } catch (err: unknown) {
    const errorMsg = err instanceof Error ? err.message : 'Unknown exception';
    console.error('[Email Dispatch Exception]:', errorMsg);
    return {
      statusCode: 500,
      body: {
        success: false,
        configured: true,
        error: 'EMAIL SERVICE TEMPORARILY UNAVAILABLE',
        details: errorMsg,
      },
    };
  }
}

// Health check endpoint
app.get('/api/health', (_req, res) => {
  const key = (process.env.EMAIL_API_KEY || '').trim();
  const isEmailConfigured = Boolean(
    key &&
    !key.includes('@') &&
    (key.startsWith('re_') || key.startsWith('SG.'))
  );
  res.json({
    status: 'ok',
    app: 'JM/CZ Portfolio',
    emailConfigured: isEmailConfigured,
    recipient: RECIPIENT_EMAIL,
    timestamp: new Date().toISOString(),
  });
});

// Secure contact submission API endpoint
app.post('/api/contact', async (req, res) => {
  const data: ProjectSubmissionPayload = req.body;
  const clientIp = (req.headers['x-forwarded-for'] as string) || req.socket.remoteAddress || '';
  
  const result = await processContactSubmission(data, clientIp);
  return res.status(result.statusCode).json(result.body);
});

// Start server and handle frontend serving (Vite in dev, dist in prod)
async function startServer() {
  const isProduction = process.env.NODE_ENV === 'production';

  if (!isProduction) {
    // Dynamic import Vite in dev mode
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: false,
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);

    // Fallback for SPA routing in dev mode
    app.use('*', async (req, res, next) => {
      const url = req.originalUrl;
      if (url.startsWith('/api')) {
        return next();
      }
      try {
        const indexPath = path.resolve(__dirname, 'index.html');
        let template = fs.readFileSync(indexPath, 'utf-8');
        template = await vite.transformIndexHtml(url, template);
        res.status(200).set({ 'Content-Type': 'text/html' }).end(template);
      } catch (e) {
        vite.ssrFixStacktrace(e as Error);
        next(e);
      }
    });
  } else {
    // Serve static files in production
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[JM/CZ Portfolio Server] Listening on http://0.0.0.0:${PORT}`);
    console.log(`[JM/CZ Portfolio Server] Target recipient: ${RECIPIENT_EMAIL}`);
  });
}

startServer().catch((err) => {
  console.error('[Server Start Failure]:', err);
  process.exit(1);
});
